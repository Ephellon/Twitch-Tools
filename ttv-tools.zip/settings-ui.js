(() => {
  var __defProp = Object.defineProperty;
  var __name = (target, value) => __defProp(target, "name", { value, configurable: true });

  // src/plugins/automation/auto-join.settings.js
  var auto_join_settings_default = {
    title: "Auto-Join",
    tr: "auto-join",
    glyph: "mod",
    flags: ["small"],
    keywords: "audiences,auto join,celebration,congregation,crowd,current,dinner,flood,flow,gallery,gathering,market,ominous,parties,public,rush,spate,stream,surge,tide,timepiece,torrent,tributary,warning,watch,wristwatch",
    rows: [
      {
        toggle: "auto_accept_mature"
      },
      {
        text: "Skip the <b warning-text>mature audiences</b> warning."
      },
      {
        text: "Also joins <a href='https://help.twitch.tv/s/article/watch-parties' top-tooltip='Watch Parties'>Watch Parties</a> for you."
      }
    ],
    settings: {
      auto_accept_mature: {
        type: "checkbox",
        default: false
      }
    }
  };

  // src/plugins/chat/auto-claim-bonuses.settings.js
  var auto_claim_bonuses_settings_default = {
    title: "Auto-Claim Bonuses",
    tr: "auto-claim-bonuses",
    glyph: "channelpoints",
    flags: ["small"],
    keywords: "claim bonuses,avenue,benefit,bonus,bonus channel points,bounty,button,carrier,channel,dividend,gift,gratuity,knob,means,medium,perk,points,premium,prize,reward,route,tunnel",
    rows: [
      {
        toggle: "auto_claim_bonuses"
      },
      {
        text: "When the <a href='https://help.twitch.tv/s/article/channel-points-guide' top-tooltip='Bonus Channel Points'><button style='background-color:var(--blue)!important'><span small black glyph='bonuschannelpoints'></span></button></a> button appears, click it for you."
      }
    ],
    settings: {
      auto_claim_bonuses: {
        type: "checkbox",
        default: true
      }
    }
  };

  // src/plugins/automation/claim-drops.settings.js
  var claim_drops_settings_default = {
    title: "Claim Drops",
    tr: "claim-drops",
    glyph: "loot",
    flags: ["small"],
    badges: {
      new: "5.32.14"
    },
    keywords: "avenue,benefit,drop,bounty,button,carrier,channel,dividend,gift,gratuity,knob,loot,means,medium,perk,points,premium,prize,reward,route,tunnel",
    rows: [
      {
        toggle: "claim_drops"
      },
      {
        text: "Claim your <a href='https://help.twitch.tv/s/article/mission-based-drops' top-tooltip='Drops'>Drops</a> every {{claim_drops__interval}} while you watch."
      }
    ],
    settings: {
      claim_drops: {
        type: "checkbox",
        default: true
      },
      claim_drops__interval: {
        type: "number",
        default: 10,
        min: 5,
        max: 60,
        step: 1,
        wrap: {
          "fix-unit": "min"
        }
      }
    }
  };

  // src/plugins/automation/claim-loot.settings.js
  var claim_loot_settings_default = {
    title: "Claim Prime Loot",
    tr: "claim-loot",
    glyph: "crown",
    flags: ["small", "gold"],
    badges: {
      new: "3.2"
    },
    keywords: "action,allegation,application,assertion,booty,call,case,claim,demand,endless,gaming,interest,loads,loot,myriad,page,petition,plea,request,requirement,spoils,suit,uncounted,untold",
    rows: [
      {
        toggle: "claim_loot"
      },
      {
        text: "Claim and close <b>Prime Gaming Loot</b> offers when the page loads."
      }
    ],
    settings: {
      claim_loot: {
        type: "checkbox",
        default: false
      }
    }
  };

  // src/plugins/automation/lurking.settings.js
  var lurking_settings_default = {
    title: "Easy Lurk",
    tr: "away-mode",
    glyph: "show",
    flags: ["small"],
    badges: {
      new: "4.12"
    },
    keywords: "button,knob,placement,agenda,amount,calendar,chart,chatter,conversation,figure,gossip,itinerary,lineup,list,number,program,quantity,record,roster,schedule,size,timetable,total,volume;sunday,monday,tuesday,wednesday,thursday,friday,saturday",
    rows: [
      {
        toggle: "away_mode"
      },
      {
        text: "Add a button to turn <b attention-text top-tooltip='Watching (one or more) streams with little to no engagement'>lurking</b> on and off."
      },
      {
        text: "You can also press <code id='key:alt-a'>Alt + A</code>."
      },
      {
        extras: {
          title: "Extras",
          tr: "extras",
          subtitle: 'Adjust settings for "Easy Lurk"'
        },
        rows: [
          {
            option: {
              title: "Button",
              tr: "placement:away-mode"
            },
            rows: [
              {
                text: "Where should the <b>Easy Lurk</b> button be shown?"
              },
              {
                select: "away_mode_placement"
              }
            ]
          },
          {
            option: {
              title: "Hide Chat",
              tr: "away-mode:hide-chat"
            },
            rows: [
              {
                toggle: "away_mode__hide_chat"
              },
              {
                text: "Keep chat hidden while <b attention-text top-tooltip='Watching (one or more) streams with little to no engagement'>lurking</b>."
              }
            ]
          },
          {
            option: {
              title: "Lurking Volume",
              tr: "away-mode:volume"
            },
            rows: [
              {
                toggle: "away_mode__volume_control"
              },
              {
                text: "Set the volume to {{away_mode__volume}} when <b attention-text top-tooltip='Watching (one or more) streams with little to no engagement'>lurking</b>."
              }
            ]
          },
          {
            option: {
              title: "Schedule",
              tr: "away-mode:schedule"
            },
            rows: [
              {
                extras: {
                  title: "Times",
                  tr: "away-mode:schedule:options",
                  subtitle: "View, or remove times"
                },
                panelAttrs: {
                  type: "list",
                  id: "away_mode_schedule"
                },
                rows: [
                  {
                    html: `<div day-of-week='0'>
                                            <h2 tr-id='day-of-week'>Sunday</h2>
                                        </div>`
                  },
                  {
                    html: `<div day-of-week='1'>
                                            <h2 tr-id='day-of-week'>Monday</h2>
                                        </div>`
                  },
                  {
                    html: `<div day-of-week='2'>
                                            <h2 tr-id='day-of-week'>Tuesday</h2>
                                        </div>`
                  },
                  {
                    html: `<div day-of-week='3'>
                                            <h2 tr-id='day-of-week'>Wednesday</h2>
                                        </div>`
                  },
                  {
                    html: `<div day-of-week='4'>
                                            <h2 tr-id='day-of-week'>Thursday</h2>
                                        </div>`
                  },
                  {
                    html: `<div day-of-week='5'>
                                            <h2 tr-id='day-of-week'>Friday</h2>
                                        </div>`
                  },
                  {
                    html: `<div day-of-week='6'>
                                            <h2 tr-id='day-of-week'>Saturday</h2>
                                        </div>`
                  },
                  {
                    html: "<div hr><button id='add-time'><span small glyph='add_to_calendar'></span> <span tr-id='new'>New</span></button></div>"
                  },
                  {
                    html: `<div hidden>
                                            <!-- BUFFER -->
                                        </div>`
                  }
                ]
              }
            ]
          }
        ]
      }
    ],
    settings: {
      away_mode: {
        type: "checkbox",
        default: true
      },
      away_mode__hide_chat: {
        type: "checkbox",
        default: false
      },
      away_mode__volume_control: {
        type: "checkbox",
        default: false
      },
      away_mode__volume: {
        type: "number",
        default: 25,
        min: 1,
        max: 25,
        unit: "%",
        scale: 0.01
        // Saved as a fraction of full volume
      },
      away_mode_schedule: {
        type: "custom"
      },
      away_mode_placement: {
        type: "select",
        options: [
          {
            default: true,
            value: "null",
            label: "Do not display",
            attrs: {
              "tr-id": "placement:away-mode:options"
            }
          },
          {
            value: "over",
            label: "Over the video",
            attrs: {
              "tr-id": ""
            }
          },
          {
            value: "under",
            label: "Under the video",
            attrs: {
              "tr-id": ""
            }
          }
        ]
      }
    }
  };

  // src/plugins/up-next/first-in-line.settings.js
  var first_in_line_settings_default = {
    title: "Up Next",
    tr: "first-in-line",
    glyph: "favorite",
    flags: ["small"],
    badges: {
      beta: "5.34.0.1"
    },
    keywords: "first in line,avenue,blink,carrier,channel,current,flood,flow,flutter,jerk,jiggle,keep,keep reminders,live,live reminders,means,medium,route,rush,shudder,spate,stream,surge,tide,torrent,tremble,tributary,tunnel,twitch",
    rows: [
      {
        text: "Go to a channel's stream when it goes live."
      },
      {
        text: "<b>Up Next</b> keeps a queue of channels to watch next."
      },
      {
        extras: {
          title: "Options",
          tr: "options",
          subtitle: 'Adjust options for "Up Next"'
        },
        rows: [
          {
            choice: "first_in_line_none",
            title: "Disabled",
            tr: "first-in-line:disabled",
            text: "Off"
          },
          {
            choice: "first_in_line_now",
            title: "Immediate",
            tr: "first-in-line:immediate",
            text: "Go to each followed channel as soon as it goes live",
            attrs: {
              beta: ""
            }
          },
          {
            choice: "first_in_line",
            title: "Notification",
            tr: "first-in-line:notification",
            text: "When Twitch notifies you that a channel went live, go to it after {{first_in_line_time_minutes}}"
          },
          {
            choice: "first_in_line_plus",
            title: "Appearance",
            tr: "first-in-line:appearance",
            text: "When a channel shows up in your Followed Channels, go to it after {{first_in_line_plus_time_minutes}}"
          },
          {
            choice: "first_in_line_all",
            title: "Automatic",
            tr: "first-in-line:smart-notifications",
            text: "Go to every followed channel that goes live, after {{first_in_line_all_time_minutes}}",
            titleAttrs: {
              bubble: "Smart Notifications"
            }
          }
        ]
      },
      {
        extras: {
          title: "Extras",
          tr: "extras",
          subtitle: 'Adjust settings for "Up Next"'
        },
        rows: [
          {
            option: {
              title: "One Instance",
              tr: "up-next:extras"
            },
            rows: [
              {
                toggle: "up_next__one_instance"
              },
              {
                text: "Only the first tab that loads <b>Up Next</b> runs it. Your other tabs don't."
              }
            ]
          },
          {
            option: {
              title: "Keep Status",
              tr: "up-next:keep-status"
            },
            rows: [
              {
                toggle: "up_next__keep_status"
              },
              {
                text: "If you pause <b>Up Next</b>, it stays paused when you go to another channel in the same tab."
              }
            ]
          },
          {
            option: {
              title: "Rushing",
              tr: "up-next:rushing"
            },
            rows: [
              {
                select: "up_next__rushing"
              },
              {
                text: "What happens to the countdown when you start or stop rushing the queue."
              }
            ]
          },
          {
            option: {
              title: "<span class='live'>LIVE</span> Reminders",
              tr: "auto-follow:live-reminders"
            },
            attrs: {
              disabled: ""
            },
            rows: [
              {
                toggle: "live_reminders"
              },
              {
                text: "Add a <b attention-text top-tooltip='A notification will display when a channel goes live'>reminder</b> button to the channel's <b>About</b> panel."
              }
            ]
          },
          {
            option: {
              title: "Keep Reminders",
              tr: "auto-follow:keep-live-reminders"
            },
            rows: [
              {
                toggle: "keep_live_reminders"
              },
              {
                text: "Don't remove <span class='live'>LIVE</span> Reminders automatically."
              }
            ]
          }
        ]
      }
    ],
    settings: {
      first_in_line_none: {
        type: "radio",
        default: true,
        group: "first-in-line"
      },
      first_in_line_now: {
        type: "radio",
        default: false,
        group: "first-in-line"
      },
      first_in_line: {
        type: "radio",
        default: false,
        group: "first-in-line"
      },
      first_in_line_time_minutes: {
        type: "number",
        default: 15,
        min: 5,
        step: 5,
        unit: "min"
      },
      first_in_line_plus: {
        type: "radio",
        default: false,
        group: "first-in-line"
      },
      first_in_line_plus_time_minutes: {
        type: "number",
        default: 15,
        min: 5,
        step: 5,
        unit: "min"
      },
      first_in_line_all: {
        type: "radio",
        default: false,
        group: "first-in-line"
      },
      first_in_line_all_time_minutes: {
        type: "number",
        default: 15,
        min: 5,
        step: 5,
        unit: "min"
      },
      up_next__one_instance: {
        type: "checkbox",
        default: false
      },
      up_next__keep_status: {
        type: "checkbox",
        default: false
      },
      up_next__rushing: {
        type: "select",
        options: [
          {
            default: true,
            value: "keep",
            label: "Keep time left",
            attrs: {
              title: "Starting lowers the countdown to 5 minutes if more is left; stopping keeps the time that is left."
            }
          },
          {
            value: "reset",
            label: "Reset",
            attrs: {
              title: "Stopping starts the full wait again."
            }
          },
          {
            value: "split",
            label: "Two timers",
            attrs: {
              title: "Stopping goes back to where the normal countdown was."
            }
          },
          {
            value: "scale",
            label: "Scale",
            attrs: {
              title: "The time left grows or shrinks by the same ratio as the wait."
            }
          },
          {
            value: "once",
            label: "Rush once",
            attrs: {
              title: "Rushing turns itself off after the next channel."
            }
          }
        ]
      },
      live_reminders: {
        type: "checkbox",
        default: true,
        attrs: {
          disabled: ""
        }
      },
      keep_live_reminders: {
        type: "checkbox",
        default: false
      }
    }
  };

  // src/plugins/automation/auto-follow.settings.js
  var auto_follow_settings_default = {
    title: "Auto-Follow",
    tr: "auto-follow",
    glyph: "favorite",
    flags: ["small"],
    keywords: "follows,avenue,board,bulletin,bureau,button,cabinet,carrier,channels,charge,collectibles,commission,current,extras,flood,flow,follow,forum,group,handling,jury,knob,management,manipulation,means,medium,notice,notification,oversight,panel,plan,policy,proclamation,reminders,route,rush,spate,strategy,streams,surge,tab,task force,tide,torrent,transaction,treatment,tribunal,tributary,tunnel,warning",
    rows: [
      {
        text: "Follow channels automatically while you watch them."
      },
      {
        html: `<div>
                    <!-- EMPTY OFFSET -->
                </div>`
      },
      {
        extras: {
          title: "Options",
          tr: "options",
          subtitle: 'Adjust options for "Auto-Follow"'
        },
        rows: [
          {
            choice: "auto_follow_none",
            title: "Disabled",
            tr: "auto-follow:none",
            text: "Off"
          },
          {
            choice: "auto_follow_raids",
            title: "Raids",
            tr: "auto-follow:raids",
            text: "When you join a raid, follow the raided channel"
          },
          {
            choice: "auto_follow_time",
            title: "Viewership",
            tr: "auto-follow:time",
            text: "After you watch a channel for {{auto_follow_time_minutes}}, follow it"
          },
          {
            choice: "auto_follow_all",
            title: "Automatic",
            tr: "auto-follow:all",
            text: "Follow every channel you watch"
          }
        ]
      }
    ],
    settings: {
      auto_follow_none: {
        type: "radio",
        default: true,
        group: "auto-follow"
      },
      auto_follow_raids: {
        type: "radio",
        default: false,
        group: "auto-follow"
      },
      auto_follow_time: {
        type: "radio",
        default: false,
        group: "auto-follow"
      },
      auto_follow_time_minutes: {
        type: "number",
        default: 15,
        min: 5,
        step: 5,
        unit: "min"
      },
      auto_follow_all: {
        type: "radio",
        default: false,
        group: "auto-follow"
      }
    }
  };

  // src/plugins/automation/kill-extensions.settings.js
  var kill_extensions_settings_default = {
    title: "Kill Extensions",
    tr: "kill-extensions",
    glyph: "extensions",
    flags: ["small", "gold"],
    keywords: "act,array,blink,current,delay,demonstration,development,display,example,exhibit,expansion,extensions,flood,flow,flutter,increase,jerk,jiggle,parade,postponement,presentation,rush,shudder,spate,stream,surge,tide,torrent,tremble,tributary,twitch",
    rows: [
      {
        toggle: "kill_extensions"
      },
      {
        text: "Hide Twitch™ extensions that cover the stream."
      }
    ],
    settings: {
      kill_extensions: {
        type: "checkbox",
        default: false
      }
    }
  };

  // src/settings/sections/next-channel.js
  var next_channel_default = {
    title: "Next Channel Pick",
    tr: "next-channel-preference",
    glyph: "favorite",
    flags: ["small"],
    badges: {
      new: "4.1.8"
    },
    keywords: "next channel,avenue,carrier,channel,current,flood,flow,means,medium,offline,route,rush,spate,stream,surge,tide,torrent,tributary,tunnel",
    rows: [
      {
        text: "When <b>Up Next</b> is empty, how should the next channel be picked?"
      },
      {
        text: "<b warning-text>This only happens when the current stream ends</b>."
      },
      {
        select: "next_channel_preference"
      }
    ],
    settings: {
      next_channel_preference: {
        type: "select",
        options: [
          {
            value: "none",
            label: "Disabled",
            attrs: {
              "tr-id": "next-channel-preference:options"
            }
          },
          {
            default: true,
            value: "random",
            label: "Go to a random channel",
            attrs: {
              "tr-id": ""
            }
          },
          {
            value: "unpopular",
            label: "Go with the least viewers",
            attrs: {
              "tr-id": ""
            }
          },
          {
            value: "popular",
            label: "Go with the most viewers",
            attrs: {
              "tr-id": ""
            }
          },
          {
            value: "poor",
            label: "Go with the least channel points",
            attrs: {
              "tr-id": ""
            }
          },
          {
            value: "rich",
            label: "Go with the most channel points",
            attrs: {
              "tr-id": ""
            }
          },
          {
            value: "closest",
            label: "Go with the closest to having all channel point rewards",
            attrs: {
              "tr-id": ""
            }
          },
          {
            value: "furthest",
            label: "Go with the furthest from having all channel point rewards",
            attrs: {
              "tr-id": ""
            }
          }
        ]
      }
    }
  };

  // src/plugins/automation/parse-commands.settings.js
  var parse_commands_settings_default = {
    title: "Parse Commands",
    tr: "parse-commands",
    glyph: "extensions",
    flags: ["small", "gold"],
    badges: {
      new: "4.30"
    },
    keywords: "angle,association,avenue,board,bulletin,bureau,button,cabinet,carrier,change,channels,charge,collectibles,commands,commission,contact,corner,current,curve,departure,direction,duty,element,extras,fairway,flood,flow,forum,group,handling,hookup,jury,knob,law,links,management,mandate,manipulation,means,medium,network,notice,notification,order,oversight,page,panel,plan,policy,proclamation,regulation,relationship,reminders,request,responsibility,reversal,round,route,rule,rush,shift,spate,spin,spiral,strategy,streams,surge,swing,tab,task force,tide,tie,torrent,transaction,treatment,trend,tribunal,tributary,tunnel,turn,twist,warning,wind,word,word",
    rows: [
      {
        toggle: "parse_commands"
      },
      {
        text: "When the page mentions a <b alert-text top-tooltip='!command'>command</b>, look up what it says."
      },
      {
        extras: {
          title: "Options",
          tr: "options",
          subtitle: 'Adjust options for "Parse Commands"'
        },
        rows: [
          {
            option: {
              title: "Create Links",
              tr: "parse-commands:options"
            },
            rows: [
              {
                toggle: "parse_commands__create_links"
              },
              {
                text: "If a command has several links, use the <b attention-text top-tooltip='Most fulfilled (missing the least number of components)'>best</b> one."
              }
            ]
          }
        ]
      }
    ],
    settings: {
      parse_commands: {
        type: "checkbox",
        default: false
      },
      parse_commands__create_links: {
        type: "checkbox",
        default: true
      }
    }
  };

  // src/plugins/automation/prevent-raiding.settings.js
  var prevent_raiding_settings_default = {
    title: "Prevent Raiding",
    tr: "prevent-raiding",
    glyph: "people",
    flags: ["small"],
    badges: {
      new: "4.12.11"
    },
    keywords: "arrest,assault,avenue,break in,capture,carrier,channels,charge,handling,incursion,invasion,management,manipulation,means,medium,onslaught,oversight,plan,policy,raiding,route,sortie,strategy,surprise attack,sweep,transaction,treatment,tunnel",
    rows: [
      {
        text: "When a channel starts a raid, go to the <b>Next Channel</b> instead."
      },
      {
        select: "prevent_raiding"
      },
      {
        extras: {
          title: "Extras",
          tr: "extras",
          subtitle: 'Adjust settings for "Prevent Raiding"'
        },
        rows: [
          {
            option: {
              title: "Greedy Raiding",
              tr: "@@greedy-raiding"
            },
            rows: [
              {
                toggle: "greedy_raiding"
              },
              {
                text: "When a <b attention-text top-tooltip='Followed channels with Channel Points'>followed channel</b> starts a raid, go to it so you join the raid. Needs <b>Experimental Features</b>."
              }
            ]
          }
        ]
      }
    ],
    settings: {
      prevent_raiding: {
        type: "select",
        options: [
          {
            default: true,
            value: "none",
            label: "Allow all channels to raid",
            attrs: {
              "tr-id": "prevent-raiding:options"
            }
          },
          {
            value: "greed",
            label: "Only raid to collect channel points",
            attrs: {
              "tr-id": ""
            }
          },
          {
            value: "all",
            label: "Prevent all channels from raiding",
            attrs: {
              "tr-id": ""
            }
          },
          {
            value: "unfollowed",
            label: "Prevent unfollowed channels from being raided",
            attrs: {
              "tr-id": ""
            }
          }
        ]
      },
      greedy_raiding: {
        type: "checkbox",
        default: false,
        attrs: {
          requires: "#prevent_raiding"
        }
      }
    }
  };

  // src/plugins/automation/claim-prime.settings.js
  var claim_prime_settings_default = {
    title: "Prime Subscription",
    tr: "claim-prime",
    glyph: "crown",
    flags: ["small", "gold"],
    badges: {
      beta: "5.28"
    },
    keywords: "age,contribution,date,day,era,future,generation,hour,life,max,moment,month,occasion,pace,past,point,present,season,second,space,stage,subscription,subscription,term,turn,week,while,year",
    rows: [
      {
        toggle: "claim_prime"
      },
      {
        text: "Renew your free <a href='https://help.twitch.tv/s/article/how-to-use-twitch-prime-subscriptions' top-tooltip='Prime Gaming Subscription'>Prime Subscription</a> each month."
      },
      {
        extras: {
          title: "Options",
          tr: "options",
          subtitle: 'Adjust options for "Prime Subscription"'
        },
        rows: [
          {
            option: {
              title: "Max Resubscriptions",
              tr: "claim-prime:max-claims"
            },
            rows: [
              {
                text: "<b>Prime Subscription</b> will resubscribe for {{claim_prime__max_claims}} months."
              }
            ]
          }
        ]
      }
    ],
    settings: {
      claim_prime: {
        type: "checkbox",
        default: false
      },
      claim_prime__max_claims: {
        type: "number",
        default: 3,
        min: 1,
        max: 48,
        step: 1,
        unit: "🔢"
      }
    }
  };

  // src/plugins/automation/stay-live.settings.js
  var stay_live_settings_default = {
    title: "Stay Live",
    tr: "stay-live",
    glyph: "stream",
    flags: ["small"],
    badges: {
      new: "4.5"
    },
    keywords: "avenue,carrier,channel,current,deadline,edge,ends,flood,flow,holiday,means,medium,offline,point,route,rush,sojourn,spate,stay,stopover,streams,surge,term,tide,top,torrent,tributary,tributary,tunnel,vacation",
    rows: [
      {
        toggle: "stay_live"
      },
      {
        text: "After the current stream ends, go to the <b>Next Channel</b>."
      },
      {
        extras: {
          title: "Extras",
          tr: "extras",
          subtitle: 'Adjust settings for "Stay Live"'
        },
        rows: [
          {
            option: {
              title: "<span class='offline'>Rerun</span> → <span class='offline'>Offline</span>"
            },
            rows: [
              {
                toggle: "stay_live__ignore_channel_reruns"
              },
              {
                tr: "stay-live:vod-is-offline",
                text: "Treat <a href='https://help.twitch.tv/s/article/video-on-demand#reruns' top-tooltip='Reruns'>reruns</a> as offline."
              }
            ]
          }
        ]
      }
    ],
    settings: {
      stay_live: {
        type: "checkbox",
        default: true
      },
      stay_live__ignore_channel_reruns: {
        type: "checkbox",
        default: false,
        attrs: {
          requires: "#stay_live"
        }
      }
    }
  };

  // src/plugins/up-next/streak-saver.settings.js
  var streak_saver_settings_default = {
    title: "Streak Saver",
    tr: "streak-saver",
    glyph: "fire",
    flags: ["small"],
    badges: {
      new: "6.1"
    },
    keywords: "chain,keep,miss,missed,recover,rescue,save,streak,streaks,watch",
    rows: [
      {
        toggle: "streak_saver"
      },
      {
        text: "Lists the <b>Watch Streaks</b> you can still save in Up Next, each with a one-click <b>Save</b>."
      },
      {
        text: "Twitch needs a clip from the last day to save a streak; without one, watch the channel live.",
        attrs: {
          "warning-text": ""
        }
      }
    ],
    settings: {
      streak_saver: {
        type: "checkbox",
        default: false
      }
    }
  };

  // src/plugins/up-next/max-watchtime.settings.js
  var max_watchtime_settings_default = {
    title: "Max Watchtime",
    tr: "max-watchtime",
    glyph: "fire",
    flags: ["small"],
    badges: {
      new: "6.1"
    },
    keywords: "max watchtime,always,channel,favorite,immediately,live,maximum,priority,tab,watch time,watchtime",
    rows: [
      {
        toggle: "max_watchtime"
      },
      {
        text: "When a marked channel goes live, one of your other Twitch tabs goes to it right away and stays until the stream ends."
      },
      {
        text: "Needs <b>Up Next</b> › <em>One Instance</em> on (the <b>Up Next</b> tab is never used), or <b>Up Next</b> off. Mark a channel with the <b>Max Watchtime</b> button on its About panel, under DVR."
      }
    ],
    settings: {
      max_watchtime: {
        type: "checkbox",
        default: true
      }
    }
  };

  // src/plugins/automation/time-zones.settings.js
  var time_zones_settings_default = {
    title: "Time Zones",
    tr: "time-zones",
    glyph: "calendar",
    flags: ["small", "gold"],
    badges: {
      new: "4.12.14"
    },
    keywords: "area,belt,ground,page,region,section,sector,territory,time zone,zones",
    rows: [
      {
        toggle: "time_zones"
      },
      {
        text: "Show times on the page in your own time zone."
      }
    ],
    settings: {
      time_zones: {
        type: "checkbox",
        default: false
      }
    }
  };

  // src/plugins/automation/view-mode.settings.js
  var view_mode_settings_default = {
    title: "View Mode",
    tr: "view-mode",
    glyph: "video",
    flags: ["small", "gold"],
    badges: {
      new: "3.1.5"
    },
    keywords: "approach,aspect,condition,fashion,form,glimpse,loading,look,mechanism,method,mode,outlook,packing,page,perspective,picture,posture,procedure,process,prospect,quality,scene,sight,situation,status,storing,style,system,technique,tone,view,vision,way",
    rows: [
      {
        text: "After a page loads, switch to:"
      },
      {
        select: "view_mode"
      }
    ],
    settings: {
      view_mode: {
        type: "select",
        options: [
          {
            default: true,
            value: "null",
            label: "Nothing (do not change)",
            attrs: {
              "tr-id": "view-mode:options"
            }
          },
          {
            value: "default",
            label: "Default Mode (banner + chat)",
            attrs: {
              "tr-id": ""
            }
          },
          {
            value: "theatre",
            label: "Theatre Mode (chat)",
            attrs: {
              "tr-id": ""
            }
          },
          {
            value: "fullwidth",
            label: "Fullwidth Mode (banner)",
            attrs: {
              "tr-id": ""
            }
          },
          {
            value: "fullscreen",
            label: "Fullscreen Mode",
            attrs: {
              "tr-id": ""
            }
          }
        ]
      }
    }
  };

  // src/plugins/chat/simplify-chat.settings.js
  var simplify_chat_settings_default = {
    title: "Simpler Chat",
    tr: "simplify-chat",
    glyph: "accessible",
    flags: ["large", "help"],
    badges: {
      new: "5.32.7",
      id: "accessibility"
    },
    keywords: "accessibility,accent,act,array,chatter,colors,conversation,demonstration,display,emphasis,example,exhibit,font,fount,gossip,homogeneous,inflection,inflexible,monotone,orderly,parade,presentation,reliable,resonance,rigid,strength,systematic,timbre,tones,uniform",
    rows: [
      {
        text: "Make Twitch™ easier to read and use."
      },
      {
        html: `<details>
                    <summary tr-id='options' subtitle='Adjust accessibility options'>Options</summary>

                    <div sect>
                        <h2><span small gold glyph='chat'></span> Chat</h2>

                        <div opt>
                            <div class='title' tr-id='simplify-chat:options'>Dual-tone Chat</div>
                            <div class='summary'>
                                <div class='toggle'>
                                    <input id='simplify_chat' type='checkbox'>
                                    <label for='simplify_chat'></label>
                                </div>
                                <p tr-id>
                                    Display the chat dual-toned to make it easier to read.
                                </p>
                            </div>
                        </div>

                        <div opt>
                            <div class='title' tr-id='simplify-chat:options'>Monotone Usernames</div>
                            <div class='summary'>
                                <div class='toggle'>
                                    <input id='simplify_chat_monotone_usernames' type='checkbox'>
                                    <label for='simplify_chat_monotone_usernames'></label>
                                </div>
                                <p tr-id>
                                    Keep username colors uniform.
                                </p>
                            </div>
                        </div>

                        <div opt>
                            <div class='title' tr-id>Chat Font</div>
                            <div class='summary'>
                                <p tr-id>
                                    Display chat in the following font:
                                </p>

                                <select id='simplify_chat_font'>
                                    <option value='Roobert' style='font-family:Roobert!important' selected>Roobert → TWITCH.tv™</option>
                                    <option value='Arial' style='font-family:Arial!important'>Arial → TWITCH.tv™</option>
                                    <option value='Calibri' style='font-family:Calibri!important'>Calibri → TWITCH.tv™</option>
                                    <option value='Dyslexie' style='font-family:Dyslexie!important'>Dyslexie → TWITCH.tv™</option>
                                    <option value='Helvetica' style='font-family:Helvetica!important'>Helvetica → TWITCH.tv™</option>
                                    <option value='Monospace' style='font-family:Monospace!important'>Monospace → TWITCH.tv™</option>
                                    <option value='System-UI' style='font-family:System-UI!important'>System-UI → TWITCH.tv™</option>
                                    <option value='Tahoma' style='font-family:Tahoma!important'>Tahoma → TWITCH.tv™</option>
                                    <option value='Verdana' style='font-family:Verdana!important'>Verdana → TWITCH.tv™</option>
                                    <option value='Inter' style='font-family:Inter!important'>Inter → TWITCH.tv™</option>
                                    <option value='04b03' style='font-family:"04b03"!important'>04b03 → TWITCH.tv™</option>
                                </select>
                            </div>
                        </div>

                        <div disabled opt>
                            <div class='title' tr-id>Reverse Emotes</div>
                            <div class='summary'>
                                <div class='toggle'>
                                    <input id='simplify_chat_reverse_emotes' type='checkbox' disabled>
                                    <label for='simplify_chat_reverse_emotes'></label>
                                </div>
                                <p tr-id>
                                    Convert emotes back into their text, and display the emote (as a <code>tooltip</code>) only when <code>hovering</code> the text.
                                </p>
                            </div>
                        </div>
                    </div>

                    <div sect>
                        <h2><span small gold glyph='video'></span> Twitch™</h2>

                        <div opt>
                            <div class='title' tr-id='simplify-look:options'>Marquee Long Text</div>

                            <div class='summary'>
                                <div class='toggle'>
                                    <input id='simplify_look_auto_marquee' type='checkbox'>
                                    <label for='simplify_look_auto_marquee'></label>
                                </div>
                                <p tr-id>
                                    Text that extends beyond a container's display will be turned into a marquee.
                                </p>
                            </div>
                        </div>

                        <div opt>
                            <div class='title' tr-id>Page Font</div>
                            <div class='summary'>
                                <p tr-id>
                                    Display Twitch™ (excluding chat) in the following font:
                                </p>

                                <select id='simplify_page_font'>
                                    <option value='Roobert' style='font-family:Roobert!important' selected>Roobert → TWITCH.tv™</option>
                                    <option value='Arial' style='font-family:Arial!important'>Arial → TWITCH.tv™</option>
                                    <option value='Calibri' style='font-family:Calibri!important'>Calibri → TWITCH.tv™</option>
                                    <option value='Dyslexie' style='font-family:Dyslexie!important'>Dyslexie → TWITCH.tv™</option>
                                    <option value='Helvetica' style='font-family:Helvetica!important'>Helvetica → TWITCH.tv™</option>
                                    <option value='Monospace' style='font-family:Monospace!important'>Monospace → TWITCH.tv™</option>
                                    <option value='System-UI' style='font-family:System-UI!important'>System-UI → TWITCH.tv™</option>
                                    <option value='Tahoma' style='font-family:Tahoma!important'>Tahoma → TWITCH.tv™</option>
                                    <option value='Verdana' style='font-family:Verdana!important'>Verdana → TWITCH.tv™</option>
                                    <option value='Inter' style='font-family:Inter!important'>Inter → TWITCH.tv™</option>
                                    <option value='04b03' style='font-family:"04b03"!important'>04b03 → TWITCH.tv™</option>
                                </select>
                            </div>
                        </div>
                    </div>
                </details>`
      }
    ],
    settings: {
      simplify_chat: {
        type: "custom"
      },
      simplify_chat_monotone_usernames: {
        type: "custom"
      },
      simplify_chat_font: {
        type: "custom"
      },
      simplify_look_auto_marquee: {
        type: "custom"
      },
      simplify_page_font: {
        type: "custom"
      },
      simplify_chat_reverse_emotes: {
        type: "custom",
        store: false
      }
    }
  };

  // src/plugins/chat/bttv-emotes.settings.js
  var bttv_emotes_settings_default = {
    title: "BetterTTV Emotes",
    tr: "bttv-emotes",
    glyph: "emotes",
    flags: ["small", "gold"],
    keywords: "amount,anxiety,area,avenue,bundle,capacity,carrier,cause,channel,consignment,content,district,document,element,emotes,explanation,fluctuation,goods,haul,idea,insecurity,instability,loading,locale,location,matter,means,medium,motivation,motive,neighborhood,origin,packing,paragraph,part,passage,payload,point,position,principle,purpose,quotation,region,root,route,scene,section,shipment,site,situation,source,spot,station,storing,text,theme,tunnel,uncertainty,venue,verse,volatility,vulnerability,weakness,weight,whereabouts,wording,words",
    rows: [
      {
        toggle: "bttv_emotes"
      },
      {
        text: "Use BetterTTV emotes in chat."
      },
      {
        text: "Loading them can make the page less stable.",
        attrs: {
          "warning-text": ""
        }
      },
      {
        extras: {
          title: "Options",
          tr: "options",
          subtitle: 'Adjust options for "BetterTTV emotes"'
        },
        rows: [
          {
            option: {
              title: "Auto-load Emotes",
              tr: "bttv-emotes:auto-load-bttv-emotes"
            },
            rows: [
              {
                toggle: "auto_load_bttv_emotes"
              },
              {
                text: "Turn emote names in chat into <b>BetterTTV</b> emotes."
              }
            ]
          },
          {
            option: {
              title: "Channel Specific Emotes",
              tr: "bttv-emotes:channel-specific-emotes"
            },
            rows: [
              {
                toggle: "bttv_emotes_channel"
              },
              {
                text: "Also load each channel's own <b>BetterTTV</b> emotes."
              }
            ]
          },
          {
            option: {
              title: "Emote Location",
              tr: "bttv-emotes:emote-location"
            },
            rows: [
              {
                text: "Load these <b>BetterTTV</b> emotes:"
              },
              {
                select: "bttv_emotes_location"
              }
            ]
          },
          {
            option: {
              title: "Extra Emotes",
              tr: "bttv-emotes:extra-emotes"
            },
            rows: [
              {
                text: "Add <b>BetterTTV</b> emotes with the words: {{bttv_emotes_extras}}"
              }
            ]
          },
          {
            option: {
              title: "Library Size",
              tr: "bttv-emotes:library-size"
            },
            rows: [
              {
                text: "Load up to {{bttv_emotes_maximum}}"
              }
            ]
          }
        ]
      }
    ],
    settings: {
      bttv_emotes: {
        type: "checkbox",
        default: false
      },
      auto_load_bttv_emotes: {
        type: "checkbox",
        default: false
      },
      bttv_emotes_channel: {
        type: "checkbox",
        default: false
      },
      bttv_emotes_location: {
        type: "select",
        options: [
          {
            default: true,
            value: "emotes/shared/trending",
            label: "Most popular (Trending)",
            attrs: {
              "tr-id": "bttv-emotes:emote-location:options"
            }
          },
          {
            value: "emotes/shared",
            label: "Most shared (Shared)",
            attrs: {
              "tr-id": ""
            }
          },
          {
            value: "emotes/shared/top",
            label: "Most used (Top)",
            attrs: {
              "tr-id": ""
            }
          },
          {
            value: "cached/emotes/global",
            label: "Most universal (Global)",
            attrs: {
              "tr-id": ""
            }
          }
        ]
      },
      bttv_emotes_extras: {
        type: "text",
        default: "",
        placeholder: "monka,flex,pls",
        attrs: {
          "left-tooltip": "Case insensitive • Comma separated"
        }
      },
      bttv_emotes_maximum: {
        type: "number",
        default: 150,
        min: 30,
        max: 3e3,
        step: 30,
        wrap: {
          set: "unit=Glyphs.utf8.emotes"
        }
      }
    }
  };

  // src/plugins/chat/filter-messages.settings.js
  var filter_messages_settings_default = {
    title: "Filter Messages",
    tr: "filter-messages",
    glyph: "mod",
    flags: ["small", "gold"],
    badges: {
      new: "5.8"
    },
    keywords: "advertisement,aid,announcements,appliance,arrest,assault,assistance,avenue,backing,benefit,block,break in,briefing,broadcast,bulletins,capture,carrier,channels,charge,clean,compensation,contribution,cooperation,device,disclosure,dispatch,drain,dribble,filter,gear,gizmo,handling,handout,help,incursion,invasion,leak,machinery,management,manipulation,means,mechanism,medium,messages,news,notice,onslaught,oversight,penetrate,percolate,permeate,pin,pinned,plan,points,policy,prediction,publication,prevent,raids,refine,release,relief,report,revelation,route,rules,service,sift,sortie,statement,stop,strategy,subscriptions,support,surprise attack,sweep,tools,transaction,treatment,trickle,tunnel,winnow,writing",
    rows: [
      {
        toggle: "filter_messages"
      },
      {
        text: "Hide messages that match your rules, in every channel."
      },
      {
        text: "Need help? See <a href='https://github.com/Ephellon/Twitch-Tools/wiki/Filter-Messages'>TTV Tools Wiki — Filter Messages</a>."
      },
      {
        tr: false,
        text: "{{filter_rules-input}}"
      },
      {
        extras: {
          title: "Rules",
          tr: "filter-messages:options",
          subtitle: "View, or remove rules"
        },
        panelAttrs: {
          type: "list",
          id: "filter_rules"
        },
        rows: [
          {
            html: `<div filter-type='channel' tr-id>
                            <h2>Channel Rules</h2>
                        </div>`
          },
          {
            html: `<div filter-type='badge' tr-id>
                            <h2>Badges</h2>
                        </div>`
          },
          {
            html: `<div filter-type='user' tr-id>
                            <h2>Users</h2>
                        </div>`
          },
          {
            html: `<div filter-type='emote' tr-id>
                            <h2>Emotes</h2>
                        </div>`
          },
          {
            html: `<div filter-type='text' tr-id>
                            <h2>Text</h2>
                        </div>`
          },
          {
            html: `<div filter-type='regexp' tr-id>
                            <h2>RegExp</h2>
                        </div>`
          },
          {
            html: `<div>
                            <h2 tr-id>
                                Get started by <a href='#filter_rules-input' target='_self'>adding</a> some rules.
                            </h2>

                            <details>
                                <summary subtitle>Examples</summary>
                                <ul>
                                    <li>
                                        Remove messages that contain certain words:
                                        <pre type='code'>merch,promo,sponsor</pre>
                                    </li>
                                    <li>
                                        Remove messages that contain certain emotes:
                                        <pre type='code'>:LUL:,:KEKW:</pre>
                                    </li>
                                    <li>
                                        Remove messages from certain users:
                                        <pre type='code'>@username,@otherUsername</pre>
                                    </li>
                                    <li>
                                        Remove messages from certain badge users:
                                        <pre type='code'>&lt;badge&gt;,&lt;another badge&gt;</pre>
                                        Only part of the badge names are required:
                                        <pre type='code'>&lt;mod&gt; → &lt;moderator&gt;; &lt;cheer&gt; = &lt;cheer100&gt; &lt;cheer500&gt; ...</pre>
                                    </li>
                                    <li>
                                        Remove messages that contain certain patterns (<a href='https://javascript.info/regular-expressions'>RegExp</a>):
                                        <pre type='code'>swears?|bad w[o0]rd</pre>
                                    </li>
                                    <li>
                                        Remove messages on certain channels:
                                        <pre type='code'>/DashDucks <em>filter-rule</em></pre>
                                    </li>
                                </ul>
                            </details>
                        </div>`
          }
        ]
      },
      {
        extras: {
          title: "Bulletins",
          tr: "filter-messages:bullets-options",
          subtitle: "Control the display of bulletins (highlighted messages)"
        },
        rows: [
          {
            option: {
              title: "Raids",
              tr: "",
              glyph: "raid",
              flags: ["small", "purple"]
            },
            rows: [
              {
                toggle: "filter_messages__bullets_raid"
              },
              {
                text: "Hide raid bulletins."
              }
            ]
          },
          {
            option: {
              title: "Channel Points",
              tr: "",
              glyph: "channelpoints",
              flags: ["small", "purple"]
            },
            rows: [
              {
                toggle: "filter_messages__bullets_coin"
              },
              {
                text: "Hide channel point bulletins."
              }
            ]
          },
          {
            option: {
              title: "Subscriptions",
              tr: "",
              glyph: "gift",
              flags: ["small", "gold"]
            },
            rows: [
              {
                toggle: "filter_messages__bullets_subs"
              },
              {
                text: "Hide subscription bulletins."
              }
            ]
          },
          {
            option: {
              title: "Announcements",
              tr: "",
              glyph: "alert",
              flags: ["small", "gold"]
            },
            rows: [
              {
                toggle: "filter_messages__bullets_note"
              },
              {
                text: "Hide announcements."
              }
            ]
          },
          {
            option: {
              title: "Pinned Messages",
              tr: "",
              glyph: "pinned",
              flags: ["small", "gold"]
            },
            rows: [
              {
                toggle: "filter_messages__bullets_paid"
              },
              {
                text: "Hide pinned messages."
              }
            ]
          }
        ]
      }
    ],
    settings: {
      filter_messages: {
        type: "checkbox",
        default: true
      },
      "filter_rules-input": {
        type: "text",
        default: "",
        placeholder: "/channel <badge> @user :emote: text reg.exp?",
        store: false,
        attrs: {
          "left-tooltip": "Case insensitive • Comma separated"
        }
      },
      filter_messages__bullets_raid: {
        type: "checkbox",
        default: false
      },
      filter_messages__bullets_coin: {
        type: "checkbox",
        default: false
      },
      filter_messages__bullets_subs: {
        type: "checkbox",
        default: false
      },
      filter_messages__bullets_note: {
        type: "checkbox",
        default: false
      },
      filter_messages__bullets_paid: {
        type: "checkbox",
        default: false
      },
      filter_rules: {
        type: "custom"
      }
    }
  };

  // src/plugins/chat/highlight-mentions.settings.js
  var highlight_mentions_settings_default = {
    title: "Highlight Mentions",
    tr: "highlight-mentions",
    glyph: "thread",
    flags: ["gold"],
    keywords: "attitude,belief,character,climax,determination,directive,feature,focal point,highlight,information,leader,letter,memorandum,message,news,note,notice,official,report,sentiment,someone,stance,stand,star,view,word",
    rows: [
      {
        toggle: "highlight_mentions"
      },
      {
        text: "Highlight messages that mention you (<code purple>@username</code>)."
      },
      {
        extras: {
          title: "Extras",
          tr: "extras",
          subtitle: 'Adjust settings for "Highlight Mentions"'
        },
        rows: [
          {
            html: "<div class='title' tr-id='highlight-mentions:options'>General Highlighting</div>"
          },
          {
            html: `<div class='summary'>
                            <div class='toggle'>
                                <input id='highlight_mentions_extra' type='checkbox'>
                                <label for='highlight_mentions_extra'></label>
                            </div>
                            <p tr-id>
                                When someone sends a general mention <code purple>@all</code> <code purple>@chat</code> <code purple>@everyone</code>, make the message stand out by highlighting it.
                            </p>
                        </div>`
          }
        ]
      }
    ],
    settings: {
      highlight_mentions: {
        type: "checkbox",
        default: true
      },
      highlight_mentions_extra: {
        type: "custom"
      }
    }
  };

  // src/plugins/chat/highlight-phrases.settings.js
  var highlight_phrases_settings_default = {
    title: "Highlight Phrases",
    tr: "highlight-phrases",
    glyph: "star",
    flags: ["gold"],
    badges: {
      new: "4.1"
    },
    keywords: "aid,appliance,assistance,attitude,backing,belief,benefit,character,climax,compensation,cooperation,determination,device,directive,expression,feature,focal point,gear,gizmo,help,highlight,idiom,information,leader,letter,machinery,means,mechanism,memorandum,message,motto,news,note,notice,official,phrases,phrasing,relief,remark,report,saying,sentiment,service,slogan,someone,stance,stand,star,support,terminology,tools,utterance,view,word,wording",
    rows: [
      {
        toggle: "highlight_phrases"
      },
      {
        text: "Highlight messages that contain any of these phrases."
      },
      {
        text: "Need help? See <a href='https://github.com/Ephellon/Twitch-Tools/wiki/Highlight-Phrases'>TTV Tools Wiki — Highlight Phrases</a>."
      },
      {
        tr: false,
        text: "{{phrase_rules-input}}"
      },
      {
        extras: {
          title: "Rules",
          tr: "highlight-phrases:options",
          subtitle: "View, or remove rules"
        },
        panelAttrs: {
          type: "list",
          id: "phrase_rules"
        },
        rows: [
          {
            html: `<div phrase-type='channel' tr-id>
                            <h2>Channel Rules</h2>
                        </div>`
          },
          {
            html: `<div phrase-type='badge' tr-id>
                            <h2>Badges</h2>
                        </div>`
          },
          {
            html: `<div phrase-type='user' tr-id>
                            <h2>Users</h2>
                        </div>`
          },
          {
            html: `<div phrase-type='emote' tr-id>
                            <h2>Emotes</h2>
                        </div>`
          },
          {
            html: `<div phrase-type='text' tr-id>
                            <h2>Text</h2>
                        </div>`
          },
          {
            html: `<div phrase-type='regexp' tr-id>
                            <h2>RegExp</h2>
                        </div>`
          },
          {
            html: `<div>
                            <h3 tr-id>
                                Get started by <a href='#phrase_rules-input' target='_self'>adding</a> some rules.
                            </h3>

                            <details>
                                <summary subtitle>Examples</summary>
                                <ul>
                                    <li>
                                        Highlight messages that contain certain words:
                                        <pre type='code'>merch,promo,sponsor</pre>
                                    </li>
                                    <li>
                                        Highlight messages that contain certain emotes:
                                        <pre type='code'>:LUL:,:KEKW:</pre>
                                    </li>
                                    <li>
                                        Highlight messages from certain users:
                                        <pre type='code'>@username,@otherUsername</pre>
                                    </li>
                                    <li>
                                        Highlight messages from certain badge users:
                                        <pre type='code'>&lt;badge&gt;,&lt;another badge&gt;</pre>
                                        Only part of the badge names are required:
                                        <pre type='code'>&lt;mod&gt; → &lt;moderator&gt;; &lt;cheer&gt; = &lt;cheer100&gt; &lt;cheer500&gt; ...</pre>
                                    </li>
                                    <li>
                                        Highlight messages that contain certain patterns (<a href='https://javascript.info/regular-expressions'>RegExp</a>):
                                        <pre type='code'>praises?|g[o0]+d w[o0]rd</pre>
                                    </li>
                                    <li>
                                        Highlight messages on certain channels:
                                        <pre type='code'>/DashDucks <em>highlight-rule</em></pre>
                                    </li>
                                </ul>
                            </details>
                        </div>`
          }
        ]
      }
    ],
    settings: {
      highlight_phrases: {
        type: "checkbox",
        default: false
      },
      "phrase_rules-input": {
        type: "text",
        default: "",
        placeholder: "/channel <badge> @user :emote: text reg.exp?",
        store: false,
        attrs: {
          "left-tooltip": "Case insensitive • Comma separated"
        }
      },
      phrase_rules: {
        type: "custom"
      }
    }
  };

  // src/plugins/chat/link-maker-chat.settings.js
  var link_maker_chat_settings_default = {
    title: "Link Maker",
    tr: "link-maker",
    glyph: "compass",
    flags: ["small", "gold"],
    badges: {
      new: "5.16"
    },
    keywords: "association,badge,builder,calendar,cards,channel,chatter,check,contact,conversation,element,examination,fairway,gossip,hookup,inventor,label,links,maker,manufacturer,network,poster,preview,producer,program,relationship,sheet,ticket,tie,viewing",
    rows: [
      {
        toggle: "link_maker__chat"
      },
      {
        text: "Turn links in chat into preview cards."
      }
    ],
    settings: {
      link_maker__chat: {
        type: "checkbox",
        default: false
      }
    }
  };

  // src/plugins/chat/auto-chat-vip.settings.js
  var auto_chat_vip_settings_default = {
    title: "Lurk Message",
    tr: "auto-chat",
    glyph: "thread",
    flags: ["white"],
    badges: {
      new: "5.32.5"
    },
    keywords: "lurking message,channels,charge,directive,handling,information,letter,management,manipulation,memo,memorandum,message,news,note,notice,oversight,plan,policy,report,strategy,transaction,treatment,vip,word",
    rows: [
      {
        text: "Send messages in chosen channels, based on your rules. If a rule has several messages, one is picked at random."
      },
      {
        text: "With this <a href='https://help.twitch.tv/s/article/twitch-chat-badges-guide' top-tooltip='Chat Badges'>badge</a>, send a <em>general message</em> for you:"
      },
      {
        html: `<div>
                        <select id='auto_chat__vip'>
                            <option value='null' set='textContent→\\Glyphs.utf8.error \\this.textContent'>Disabled (never send)</option>
                            <option value='moderator' set='textContent→\\Glyphs.utf8.sword \\this.textContent'>Moderator</option>
                            <option value='vip' set='textContent→\\Glyphs.utf8.vip \\this.textContent'>VIP</option>
                            <option value='subscriber' set='textContent→\\Glyphs.utf8.fav \\this.textContent'>Subscriber</option>
                            <option value='everyone' set='textContent→\\Glyphs.utf8.intro \\this.textContent'>Everyone (always send)</option>
                        </select>
                    </div>`
      },
      {
        tr: false,
        text: ""
      },
      {
        extras: {
          title: "Options",
          tr: "options",
          subtitle: 'Adjust options for "Lurk Message"'
        },
        rows: [
          {
            option: {
              title: "Mentions",
              tr: "auto-chat:include-mentions"
            },
            attrs: {
              disabled: ""
            },
            rows: [
              {
                text: "When someone mentions you <code purple>@username</code>:<br> {{auto_chat__mentions}}"
              }
            ]
          },
          {
            option: {
              title: "Message(s)",
              tr: "auto-chat:lurking-message"
            },
            rows: [
              {
                text: "{{lurking_rules-input}}"
              },
              {
                extras: {
                  title: "Messages",
                  tr: "lurking-message:options",
                  subtitle: "View, or remove messages"
                },
                panelAttrs: {
                  type: "list",
                  id: "lurking_rules"
                },
                rows: [
                  {
                    html: `<div lurking-type='channel' tr-id>
                                            <h2>Channel Specific Messages</h2>
                                        </div>`
                  },
                  {
                    html: `<div lurking-type='badge' tr-id>
                                            <h2>Badge Specific Messages</h2>
                                        </div>`
                  },
                  {
                    html: `<div lurking-type='text' tr-id>
                                            <h2>General Messages</h2>
                                        </div>`
                  },
                  {
                    html: `<div>
                                            <h2 tr-id>
                                                Get started by <a href='#lurking_rules-input' target='_self'>adding</a> some rules and messages.
                                            </h2>

                                            <details>
                                                <summary subtitle>Examples</summary>
                                                <ul>
                                                    <li>
                                                        Send a message on a specific channel (<em>DashDucks</em>):
                                                        <pre type='code'>/dashducks another day, another duck :D</pre>
                                                    </li>
                                                    <li>
                                                        Send a message where you have certain permissions (<em>moderator</em>):
                                                        <pre type='code'>&lt;mod&gt; modCheck I have risen modCheck</pre>
                                                    </li>
                                                    <li>
                                                        Send a message on a specific channel, where you have certain permissions (<em>DashDuck:moderator</em>):
                                                        <pre type='code'>/dashducks &lt;mod&gt; modCheck I have risen modCheck</pre>
                                                    </li>
                                                </ul>
                                            </details>
                                        </div>`
                  }
                ]
              }
            ]
          },
          {
            option: {
              title: "Wait Time",
              tr: "auto-chat:include-phrases"
            },
            rows: [
              {
                text: "Wait {{auto_chat__wait_time}} before sending the <b>message</b>."
              }
            ]
          }
        ]
      }
    ],
    settings: {
      auto_chat__mentions: {
        type: "select",
        options: [
          {
            value: "null",
            label: "Do nothing"
          }
        ]
      },
      "lurking_rules-input": {
        type: "text",
        default: "",
        placeholder: "/channel <badge> message",
        store: false,
        attrs: {
          "left-tooltip": "Case insensitive • Semicolon separated"
        }
      },
      auto_chat__wait_time: {
        type: "number",
        default: 5,
        min: 0,
        max: 30,
        step: 1,
        unit: "min"
      },
      auto_chat__vip: {
        type: "custom"
      },
      lurking_rules: {
        type: "custom"
      }
    }
  };

  // src/plugins/chat/native-twitch-reply.settings.js
  var native_twitch_reply_settings_default = {
    title: "Native Reply",
    tr: "native-reply",
    glyph: "reply",
    flags: ["small", "gold"],
    keywords: "acknowledgment,act,array,attack,attempt,bid,blink,channels,charge,demonstration,display,endeavor,example,exhibit,experiment,feedback,flutter,handling,jerk,jiggle,management,manipulation,oversight,parade,plan,policy,presentation,pursuit,reaction,rejoinder,replies,reply,response,retort,shot,shudder,strategy,struggle,transaction,treatment,tremble,try,twitch",
    rows: [
      {
        toggle: "native_twitch_reply"
      },
      {
        text: "Show Twitch™'s own replies on every channel."
      }
    ],
    settings: {
      native_twitch_reply: {
        type: "checkbox",
        default: false
      }
    }
  };

  // src/plugins/notifications/mention-audio.settings.js
  var mention_audio_settings_default = {
    title: "Notification Sounds",
    tr: "notification-sounds",
    glyph: "music",
    flags: ["small", "gold"],
    badges: {
      new: "4.1"
    },
    keywords: "accent,adoption,benefit,bulletin,buzz,character,climax,conditions,expression,feature,flawless,focal point,gossip,handling,harmony,help,highlight,hint,idiom,innuendo,intact,leader,melody,motto,murmur,music,need,noise,note,notice,notification,official,operation,phrases,phrasing,practice,proclamation,purpose,remark,robust,safe,sane,saying,service,sigh,slogan,solid,someone,sounds,stable,star,sturdy,terminology,thorough,tone,treatment,usage,uses,utterance,value,vibrant,vibration,vigorous,voice,warning,whispers,wording,wording",
    rows: [
      {
        text: "Play a sound when any of these happen."
      },
      {
        html: `<div>
                    <!-- EMPTY OFFSET -->
                </div>`
      },
      {
        extras: {
          title: "Options",
          tr: "options",
          subtitle: 'Adjust options for "Notification Sounds"'
        },
        rows: [
          {
            option: {
              title: "Mentions",
              tr: "notification-sounds:include-mentions"
            },
            rows: [
              {
                toggle: "mention_audio"
              },
              {
                text: "Someone mentions you <code purple>@username</code>."
              }
            ]
          },
          {
            option: {
              title: "Phrases",
              tr: "notification-sounds:include-phrases"
            },
            rows: [
              {
                toggle: "phrase_audio"
              },
              {
                text: "A message contains a phrase from <b>Highlight Phrases</b>."
              }
            ]
          },
          {
            option: {
              title: "Whispers",
              tr: "notification-sounds:include-whispers"
            },
            rows: [
              {
                toggle: "whisper_audio"
              },
              {
                text: "Someone whispers to you."
              }
            ]
          },
          {
            html: "<hr>"
          },
          {
            option: {
              title: "Notification Sound",
              tr: "notification-sounds:options"
            },
            rows: [
              {
                select: "whisper_audio_sound"
              },
              {
                html: "<button id='whisper_audio_sound-test'>Test notification sound</button>"
              }
            ]
          },
          {
            tr: false,
            text: ""
          },
          {
            html: `<div class='cc-container'>
                                <div class='cc-svg'><span black glyph='cc'></span></div>
                                <p class='cc-text' tr-id='cc-sound-notice'>
                                    <a id='sound-href' href='https://notificationsounds.com/notification-sounds/goes-without-saying-608' rel='nofollow'>This sound</a> is licensed under the Creative Commons Attribution license.
                                    <a id='sound-license' href='https://creativecommons.org/licenses/by/4.0/legalcode' rel='nofollow'>Find out more</a>.
                                </p>
                            </div>`
          },
          {
            tr: false,
            text: ""
          }
        ]
      }
    ],
    settings: {
      mention_audio: {
        type: "checkbox",
        default: false
      },
      phrase_audio: {
        type: "checkbox",
        default: false
      },
      whisper_audio: {
        type: "checkbox",
        default: false
      },
      whisper_audio_sound: {
        type: "select",
        options: [
          {
            value: "beyond-doubt-2-581",
            label: "Beyond doubt 2"
          },
          {
            value: "consequence-544",
            label: "Consequence"
          },
          {
            value: "definite-555",
            label: "Definite"
          },
          {
            default: true,
            value: "goes-without-saying-608",
            label: "Goes without saying"
          },
          {
            value: "point-blank-589",
            label: "Point blank"
          },
          {
            value: "slow-spring-board-570",
            label: "Slow spring board"
          },
          {
            value: "to-the-point-568",
            label: "To the point"
          }
        ]
      }
    }
  };

  // src/plugins/chat/prevent-spam.settings.js
  var prevent_spam_settings_default = {
    title: "Prevent Spam",
    tr: "prevent-spam",
    glyph: "mod",
    flags: ["small", "gold"],
    keywords: "accident,breadth,chatter,circumstance,conversation,diameter,dimension,directive,duration,episode,existence,gossip,height,impression,imprint,incidence,incident,information,instance,length,letter,limit,line,magnitude,manifestation,mark,maximum,memorandum,messages,mileage,minimal,minimum,news,note,notice,occurrences,period,piece,point,portion,quantity,radius,range,record,report,scar,score,section,segment,signature,situation,space,spam,span,spot,stain,stamp,streak,stretch,symbol,talk,term,width,words,writing,writing",
    rows: [
      {
        toggle: "prevent_spam"
      },
      {
        text: "Hide repeated messages in chat."
      },
      {
        extras: {
          title: "Options",
          tr: "options",
          subtitle: 'Adjust options for "Prevent Spam"'
        },
        rows: [
          {
            option: {
              title: "Message History",
              tr: "prevent-spam:options"
            },
            rows: [
              {
                text: "Compare each message with the last {{prevent_spam_look_back}} lines to find <b attention-text top-tooltip='This will look for messages that match word-for-word'>copies</b>."
              }
            ]
          },
          {
            option: {
              title: "Minimum Word Length",
              tr: ""
            },
            rows: [
              {
                text: "Skip messages with no word longer than {{prevent_spam_minimum_length}} characters."
              }
            ]
          },
          {
            option: {
              title: "Maximum Occurrences",
              tr: ""
            },
            rows: [
              {
                text: "Treat a message as spam when one word appears {{prevent_spam_ignore_under}} or more times."
              }
            ]
          }
        ]
      }
    ],
    settings: {
      prevent_spam: {
        type: "checkbox",
        default: true
      },
      prevent_spam_look_back: {
        type: "number",
        default: 15,
        min: 1,
        max: 250,
        step: 1,
        unit: "¶"
      },
      prevent_spam_minimum_length: {
        type: "number",
        default: 5,
        min: 3,
        max: 500,
        step: 1,
        unit: "🔣"
      },
      prevent_spam_ignore_under: {
        type: "number",
        default: 5,
        min: 1,
        max: 150,
        step: 1,
        unit: "≥"
      }
    }
  };

  // src/plugins/chat/recover-chat.settings.js
  var recover_chat_settings_default = {
    title: "Recover Chat",
    tr: "recover-chat",
    glyph: "thread",
    keywords: "attack,attempt,bid,chatter,conversation,current,endeavor,experiment,flood,flow,gossip,pursuit,resurrect,rush,shot,spate,stream,struggle,surge,tide,torrent,tributary,try",
    rows: [
      {
        toggle: "recover_chat"
      },
      {
        text: "If chat doesn't load or disappears, try to bring it back."
      }
    ],
    settings: {
      recover_chat: {
        type: "checkbox",
        default: false
      }
    }
  };

  // src/plugins/chat/recover-messages.settings.js
  var recover_messages_settings_default = {
    title: "Recover Messages",
    tr: "recover-messages",
    glyph: "thread",
    flags: ["gold"],
    badges: {
      new: "5.28"
    },
    keywords: "attack,attempt,bid,chatter,conversation,current,endeavor,experiment,flood,flow,gossip,pursuit,resurrect,rush,shot,spate,stream,struggle,surge,tide,torrent,tributary,try",
    rows: [
      {
        toggle: "recover_messages"
      },
      {
        text: "When a message is deleted, try to bring it back."
      }
    ],
    settings: {
      recover_messages: {
        type: "checkbox",
        default: false
      }
    }
  };

  // src/plugins/chat/highlight-mentions-popup.settings.js
  var highlight_mentions_popup_settings_default = {
    title: "Show Pop-ups",
    tr: "highlight-mentions-popup",
    glyph: "thread",
    flags: ["gold"],
    keywords: "arrive,attitude,belief,blooper,character,come,come out,crop up,determination,develop,directive,emerge,information,leader,letter,looper,materialize,memorandum,message,news,note,notice,occur,official,pop ups,present,report,sentiment,show,show up,someone,stance,stand,star,surface,turn out,turn up,view,word",
    rows: [
      {
        toggle: "highlight_mentions_popup"
      },
      {
        text: "Show a pop-up when someone mentions you (<code purple>@username</code>)."
      }
    ],
    settings: {
      highlight_mentions_popup: {
        type: "checkbox",
        default: true
      }
    }
  };

  // src/plugins/chat/convert-bits.settings.js
  var convert_bits_settings_default = {
    title: "Convert Bits",
    tr: "convert-bits",
    glyph: "bits",
    flags: ["small"],
    keywords: "amount,bits,bulk,chunk,detritus,dollar,extent,junk,load,lot,measure,money,number,remains,rubbish,rubble,supply,ton,trash,usd,volume,wreck,wreckage",
    rows: [
      {
        toggle: "convert_bits"
      },
      {
        text: "Show what <a href='https://www.twitch.tv/creatorcamp/en/get-rewarded/bits-and-subscriptions/#bits' top-tooltip='Bits'><button style='background-color:var(--grey)!important'><img src='bits.gif' alt='Bits' height='20' width='20' type='glyph'></button></a> are worth in <b>USD</b>."
      }
    ],
    settings: {
      convert_bits: {
        type: "checkbox",
        default: true
      }
    }
  };

  // src/plugins/currencies/points-receipt.channel-points-receipt.settings.js
  var points_receipt_channel_points_receipt_settings_default = {
    title: "Channel Points Receipt",
    tr: "channel-points-receipt",
    glyph: "channelpoints",
    flags: ["small"],
    keywords: "act,array,assemblage,assortment,avenue,carrier,certificate,channel,collection,compilation,demonstration,display,example,exhibit,lot,means,medium,number,parade,points,presentation,receipt,route,selection,set,store,tunnel,voucher",
    rows: [
      {
        text: "How should the receipt show the <a href='https://help.twitch.tv/s/article/channel-points-guide' top-tooltip='Channel Points'><button style='background-color:var(--grey)!important'><span small purple glyph='channelpoints'></span></button></a> you collected?"
      },
      {
        select: "channelpoints_receipt_display"
      }
    ],
    settings: {
      channelpoints_receipt_display: {
        type: "select",
        options: [
          {
            default: true,
            value: "null",
            label: "Display the exact amount collected",
            attrs: {
              "tr-id": "channel-points-receipt:options"
            }
          },
          {
            value: "round100",
            label: "Round to the nearest 100",
            attrs: {
              "tr-id": ""
            }
          },
          {
            value: "round50",
            label: "Round to the nearest 50",
            attrs: {
              "tr-id": ""
            }
          },
          {
            value: "round25",
            label: "Round to the nearest 25",
            attrs: {
              "tr-id": ""
            }
          }
        ]
      }
    }
  };

  // src/plugins/chat/rewards-calculator.settings.js
  var rewards_calculator_settings_default = {
    title: "Rewards Calculator",
    tr: "rewards-calculator",
    glyph: "channelpoints",
    flags: ["small"],
    keywords: "accolade,appraisal,assessment,award,benefit,bonus,bounty,calculator,compensation,conclusion,current,dividend,estimates,estimation,evaluation,flood,flow,guess,honor,measurement,needs,opinion,premium,profit,projection,punishment,rating,remuneration,rewards,rush,spate,stream,surge,survey,tide,torrent,tributary,valuation",
    rows: [
      {
        toggle: "rewards_calculator"
      },
      {
        text: "Estimate how long you need to watch to afford <a href='https://help.twitch.tv/s/article/channel-points-guide' top-tooltip='Channel Points'><button style='background-color:var(--grey)!important'><span small purple glyph='channelpoints'></span></button></a> rewards."
      }
    ],
    settings: {
      rewards_calculator: {
        type: "checkbox",
        default: false
      }
    }
  };

  // src/settings/sections/accent-color.js
  var accent_color_default = {
    title: "Accent Color",
    tr: "accent-color",
    glyph: "latest",
    flags: ["small"],
    badges: {
      new: "4.2.0"
    },
    keywords: "accent,color,glow,hue,intensity,paint",
    rows: [
      {
        text: "TTV Tools' accent color:"
      },
      {
        select: "accent_color"
      }
    ],
    settings: {
      accent_color: {
        type: "select",
        options: [
          {
            value: "colored/contrast",
            label: "Auto",
            attrs: {
              "tr-id": "color:auto"
            }
          },
          {
            value: "blue/12",
            label: "Blue",
            attrs: {
              "tr-id": "color:blue"
            }
          },
          {
            default: true,
            value: "twitch-purple/12",
            label: "Purple",
            attrs: {
              "tr-id": "color:purple"
            }
          },
          {
            value: "red/15",
            label: "Red",
            attrs: {
              "tr-id": "color:red"
            }
          }
        ]
      }
    }
  };

  // src/plugins/customization/block-banners.settings.js
  var block_banners_settings_default = {
    title: "Block Banners",
    tr: "block-banners",
    glyph: "hide",
    flags: ["small"],
    badges: {
      new: "5.33.4.8"
    },
    keywords: "ads,advertisement,banners,block,hide,remove",
    rows: [
      {
        toggle: "block_banners"
      },
      {
        text: "Remove ad banners for <em>Bits</em>, <em>SUBtember</em>, <em>Turbo</em> and more."
      }
    ],
    settings: {
      block_banners: {
        type: "checkbox",
        default: false
      }
    }
  };

  // src/settings/sections/context-menu-override.js
  var context_menu_override_default = {
    title: "Context Menu Override",
    tr: "context-menu-override",
    glyph: "latest",
    flags: ["small"],
    badges: {
      new: "5.34"
    },
    keywords: "click,context,custom,menu,right,over,popup,ride",
    rows: [
      {
        toggle: "context_menu_override"
      },
      {
        text: "Use TTV Tools' own right-click menu on some Twitch pages."
      }
    ],
    settings: {
      context_menu_override: {
        type: "checkbox",
        default: false
      }
    }
  };

  // src/plugins/player/hide-blank-ads.settings.js
  var hide_blank_ads_settings_default = {
    title: "Hide Blank Ads",
    tr: "hide-blank-ads",
    glyph: "hide",
    flags: ["small", "gold"],
    badges: {
      new: "4.15"
    },
    keywords: "act,ad,ads,array,blink,demonstration,displays,example,exhibit,flutter,jerk,jiggle,parade,presentation,shudder,tremble,twitch",
    rows: [
      {
        toggle: "hide_blank_ads"
      },
      {
        text: "Hide Twitch™'s <b attention-text top-tooltip='Purple Screen'>Blank Ads</b> while they play."
      }
    ],
    settings: {
      hide_blank_ads: {
        type: "checkbox",
        default: false
      }
    }
  };

  // src/plugins/currencies/points-receipt.settings.js
  var points_receipt_settings_default = {
    title: "Points Receipt &amp; Rank",
    tr: "placement:points-receipt",
    glyph: "channelpoints",
    flags: ["small", "gold"],
    keywords: "certificate,content,document,idea,musty,noxious,paragraph,passage,points,putrid,quotation,ranking,receipt,text,theme,verse,voucher,wording",
    rows: [
      {
        text: "Where should the <b>Points Receipt &amp; Rank</b> be shown?"
      },
      {
        select: "points_receipt_placement"
      }
    ],
    settings: {
      points_receipt_placement: {
        type: "select",
        options: [
          {
            default: true,
            value: "null",
            label: "Do not display",
            attrs: {
              "tr-id": "placement:points-receipt:options"
            }
          },
          {
            value: "under",
            label: "Under the video",
            attrs: {
              "tr-id": ""
            }
          }
        ]
      }
    }
  };

  // src/plugins/customization/point-watcher.settings.js
  var point_watcher_settings_default = {
    title: "Point Watcher",
    tr: "placement:point-watcher",
    glyph: "channelpoints",
    flags: ["small", "gold"],
    keywords: "content,document,idea,paragraph,passage,quotation,text,theme,verse,watcher,wording",
    rows: [
      {
        text: "Where should <b>Point Watcher</b> be shown?"
      },
      {
        select: "point_watcher_placement"
      }
    ],
    settings: {
      point_watcher_placement: {
        type: "select",
        options: [
          {
            default: true,
            value: "null",
            label: "Do not display",
            attrs: {
              "tr-id": "placement:point-watcher:options"
            }
          },
          {
            value: "on",
            label: "On the tooltip",
            attrs: {
              "tr-id": ""
            }
          }
        ]
      }
    }
  };

  // src/plugins/customization/stream-preview.settings.js
  var stream_preview_settings_default = {
    title: "Stream Preview",
    tr: "stream-preview",
    glyph: "video",
    flags: ["small", "gold"],
    badges: {
      new: "5.15"
    },
    keywords: "act,advertisement,amount,announcement,array,breadth,broadcasts,capacity,channels,charge,content,current,demonstration,diameter,display,examination,example,exhibit,extent,extras,flawless,flood,flow,handling,height,intact,intensity,length,magnitude,management,manipulation,newscast,oversight,parade,performance,plan,policy,pop-ups,pop ups,presentation,preview,program,proportion,publication,range,robust,rush,safe,sane,scope,show,simulcast,size,solid,sound,spate,stable,stature,strategy,stream,sturdy,surge,thorough,tide,torrent,transaction,transmission,treatment,tributary,vibrant,viewing,vigorous,volume,width",
    rows: [
      {
        toggle: "stream_preview"
      },
      {
        text: "Show a preview of the stream when you hover over a streamer's picture."
      },
      {
        extras: {
          title: "Extras",
          tr: "extras",
          subtitle: 'Adjust settings for "Stream Preview"'
        },
        rows: [
          {
            option: {
              title: "Preview Position",
              tr: "stream-preview:position"
            },
            rows: [
              {
                text: "Choose whether the preview sits <b attention-text top-tooltip='In front of, or behind'>in front of or behind</b> the page."
              },
              {
                select: "stream_preview_position"
              }
            ]
          },
          {
            option: {
              title: "Preview Size",
              tr: "stream-preview:size"
            },
            rows: [
              {
                text: "How big should the preview be?"
              },
              {
                select: "stream_preview_scale"
              }
            ]
          },
          {
            option: {
              title: "Preview Sound",
              tr: "stream-preview:sound"
            },
            rows: [
              {
                text: "Play the preview's sound?"
              },
              {
                text: "This mutes the current stream for a moment.",
                attrs: {
                  "warning-text": ""
                }
              },
              {
                toggle: "stream_preview_sound"
              }
            ]
          }
        ]
      }
    ],
    settings: {
      stream_preview: {
        type: "checkbox",
        default: false
      },
      stream_preview_position: {
        type: "select",
        options: [
          {
            default: true,
            value: "3",
            label: "Always in front (on top)",
            attrs: {
              "tr-id": "stream-preview:position-options"
            }
          },
          {
            value: "2",
            label: "Normal",
            attrs: {
              "tr-id": ""
            }
          },
          {
            value: "1",
            label: "Always behind (on bottom)",
            attrs: {
              "tr-id": ""
            }
          }
        ]
      },
      stream_preview_scale: {
        type: "select",
        options: [
          {
            default: true,
            value: "1",
            label: "Normal (×1)",
            attrs: {
              "tr-id": "stream-preview:size-options"
            }
          },
          {
            value: "2",
            label: "Large (×2)",
            attrs: {
              "tr-id": ""
            }
          },
          {
            value: "3",
            label: "Extra-Large (×3)",
            attrs: {
              "tr-id": ""
            }
          }
        ]
      },
      stream_preview_sound: {
        type: "checkbox",
        default: false
      }
    }
  };

  // src/plugins/customization/watch-time.settings.js
  var watch_time_settings_default = {
    title: "Watch Time",
    tr: "placement:watch-time",
    glyph: "latest",
    flags: ["small"],
    keywords: "timepiece,watch,wristwatch",
    rows: [
      {
        text: "Where should <b>Watch Time</b> be shown?"
      },
      {
        select: "watch_time_placement"
      }
    ],
    settings: {
      watch_time_placement: {
        type: "select",
        options: [
          {
            default: true,
            value: "null",
            label: "Do not display",
            attrs: {
              "tr-id": "placement:watch-time:options"
            }
          },
          {
            value: "over",
            label: "Over the video",
            attrs: {
              "tr-id": ""
            }
          },
          {
            value: "under",
            label: "Under the video",
            attrs: {
              "tr-id": ""
            }
          }
        ]
      }
    }
  };

  // src/settings/sections/export-settings.js
  var export_settings_default = {
    title: "Sync &amp; Backup",
    tr: "networking:sync-settings",
    glyph: "export",
    flags: ["small"],
    badges: {
      new: "5.32"
    },
    keywords: "export settings,sync settings,cloud,download,dump,export,id,load,log in,network,settings,ship,smuggle,transport,upload",
    summaryAttrs: {
      style: "width:fit-content"
    },
    rows: [
      {
        text: "To <b attention-text top-tooltip='Save settings from somewhere else to this device'>download settings</b>, enter their <b attention-text top-tooltip='6 or more letters, numbers and/or dashes'>Upload ID</b>."
      },
      {
        tr: false,
        text: "{{sync-token}}"
      },
      {
        html: "<div id='sync-status' class='subtitle' style='margin-left:0.5rem; transition: all .5s;;'>&nbsp;</div>"
      },
      {
        tr: false,
        text: ""
      },
      {
        html: `<button id='sync-settings--upload' style='margin-right:0.5rem' top-tooltip='Save settings from this device to another device'>
                    <span small glyph='upload'></span>
                    <span tr-id='networking:sync-settings:upload'>Upload</span>
                </button>`
      },
      {
        html: `<button id='sync-settings--download' top-tooltip='Save settings from somewhere else to this device'>
                    <span small glyph='download'></span>
                    <span tr-id='networking:sync-settings:download'>Download</span>
                </button>`
      },
      {
        html: `<button id='sync-settings--share' class='edit'>
                    <span small glyph='bolt'></span>
                    <span tr-id='networking:sync-settings:copy'>Copy</span>
                </button>`
      },
      {
        html: "<hr>"
      },
      {
        html: "<input id='sync-settings--upload-json-input' type='file' accept='.json, application/json' style='display:none!important'>"
      },
      {
        html: `<label id='sync-settings--upload-json-label' for='sync-settings--upload-json-input' type='button' style='margin-right:0.5rem' top-tooltip='Restore settings from a file (JSON)'>
                    <span small glyph='rewind'></span>
                    <span tr-id='networking:sync-settings:upload-json'>Restore file</span>
                    <span small gold glyph='verified'></span>
                </label>`
      },
      {
        html: `<button id='sync-settings--download-json' top-tooltip='Save settings to a file (JSON)'>
                    <span small glyph='download'></span>
                    <span tr-id='networking:sync-settings:download-json'>Export file</span>
                    <span small gold glyph='verified'></span>
                </button>`
      }
    ],
    settings: {
      "sync-token": {
        type: "text",
        default: "TTV-TOOL",
        placeholder: "ABC123",
        attrs: {
          style: "width:-webkit-fill-available; width:-moz-available; font-family: monospace; letter-spacing:1em; text-align:center; --text-transform:uppercase; text-overflow:clip",
          pattern: "[\\w\\-]{6,}"
        }
      },
      "sync-settings--upload-json-input": {
        type: "custom",
        store: false
      }
    }
  };

  // src/settings/sections/site-access.js
  var site_access_default = {
    title: "Site Access",
    tr: "site-access",
    glyph: "globe",
    flags: ["small"],
    badges: {
      new: "6.0"
    },
    keywords: "cors,proxy,permission,permissions,sites,network,statistics,store,steam,playstation,epic,xbox,tinyurl,twitchmetrics,twitchtracker",
    rows: [
      {
        text: "Let TTV Tools read stream stats, store prices and sync links straight from their sites. Without it, a public proxy is used, which can be slow or down."
      },
      {
        html: "<div id='site-access-manager'></div>"
      }
    ],
    settings: {}
  };

  // src/plugins/customization/store-integration.settings.js
  var store_integration_settings_default = {
    title: "Game Store Links",
    tr: "store-integration",
    glyph: "gift",
    flags: ["small", "gold"],
    badges: {
      new: "5.29"
    },
    keywords: "store integration,acquisition,advance,asset,assimilation,association,boy,buy,channel,contact,cube,current,dsi,element,epic,examination,exploration,flood,flow,game,hookup,hunt,inquiry,inspection,integration,investigation,investment,link,network,nintendo,play,playstation,purchase,pursuit,quest,relationship,research,rush,search,spate,station,stock,store,steam,stream,surge,switch,tide,tie,torrent,tributary,wii,xbox",
    rows: [
      {
        toggle: "store_integration"
      },
      {
        text: "Show where to buy the game being streamed."
      },
      {
        extras: {
          title: "Options",
          tr: "options",
          subtitle: 'Adjust options for "Game Store Links"'
        },
        rows: [
          {
            option: {
              title: "Steam®",
              tr: "store-integration:steam"
            },
            rows: [
              {
                text: "Show Steam® links."
              },
              {
                toggle: "store_integration__steam"
              }
            ]
          },
          {
            option: {
              title: "PlayStation®",
              tr: "store-integration:playstation"
            },
            rows: [
              {
                text: "Show PlayStation® links."
              },
              {
                toggle: "store_integration__playstation"
              }
            ]
          },
          {
            option: {
              title: "Xbox®",
              tr: "store-integration:xbox"
            },
            rows: [
              {
                text: "Show Xbox® links."
              },
              {
                toggle: "store_integration__xbox"
              }
            ]
          },
          {
            option: {
              title: "Nintendo®",
              tr: "store-integration:nintendo"
            },
            rows: [
              {
                text: "Show Nintendo® links."
              },
              {
                toggle: "store_integration__nintendo"
              }
            ]
          },
          {
            option: {
              title: "Epic Games®",
              tr: "store-integration:epic"
            },
            rows: [
              {
                text: "Show Epic Games® links."
              },
              {
                toggle: "store_integration__epic"
              }
            ]
          }
        ]
      }
    ],
    settings: {
      store_integration: {
        type: "checkbox",
        default: true
      },
      store_integration__steam: {
        type: "checkbox",
        default: true
      },
      store_integration__playstation: {
        type: "checkbox",
        default: true
      },
      store_integration__xbox: {
        type: "checkbox",
        default: true
      },
      store_integration__nintendo: {
        type: "checkbox",
        default: true
      },
      store_integration__epic: {
        type: "checkbox",
        default: true
      }
    }
  };

  // src/plugins/networking/auto-dvr.settings.js
  var auto_dvr_settings_default = {
    title: "Clips &amp; DVR",
    tr: "networking:video-clips",
    glyph: "download",
    flags: ["small"],
    badges: {
      new: "5.32.4",
      beta: "5.28"
    },
    keywords: "video clips,allocation,alt,avenue,bar,beginning,block,book,break,breathing space,carrier,case,channels,charge,chunk,citation,clips,collectibles,conclusion,crown,cup,current,data,dawn,decoration,default,delinquency,directory,dossier,dvr,excerpt,file,flood,flow,folder,fraction,fragment,gold,halt,handling,hesitation,hiatus,hitch,information,interlude,intermission,interruption,interval,keepsake,kickoff,lapse,layoff,letup,list,lot,lull,management,manipulation,means,medal,medium,memento,mow,nonpayment,notebook,opening,outset,oversight,part,pause,piece,plan,policy,portions,prize,prune,quantity,queue,recess,record,recording,respite,route,rush,section,segment,serving,shave,shear,snip,souvenir,spate,start,stoppage,strategy,streams,surge,suspension,televised,tide,torrent,transaction,treatment,tributary,trim,trophies,trophy,tunnel,video",
    rows: [
      {
        text: "Record parts of a stream; press <code id='key:alt-z'>Alt + Z</code> to start or stop."
      },
      {
        extras: {
          title: "Options",
          tr: "options",
          subtitle: 'Adjust settings for "Clips & DVR"'
        },
        rows: [
          {
            option: {
              title: "File Type",
              tr: "video-clips:file-type"
            },
            rows: [
              {
                text: "File type for <b>clips</b>:"
              },
              {
                select: "video_clips__file_type"
              }
            ]
          },
          {
            option: {
              title: "Quality",
              tr: "video-clips:quality"
            },
            rows: [
              {
                text: "Quality for <b>clips</b>:"
              },
              {
                select: "video_clips__quality"
              }
            ]
          },
          {
            option: {
              title: "Default Length",
              tr: "video-clips:length"
            },
            rows: [
              {
                text: "Clips are {{video_clips__length}} long by default."
              }
            ]
          },
          {
            option: {
              title: "DVR",
              tr: "video-clips:dvr"
            },
            rows: [
              {
                toggle: "video_clips__dvr"
              },
              {
                text: "Record and save streams from channels you mark as <b>DVR</b>. These channels pause the <b>Up Next</b> queue."
              }
            ]
          },
          {
            option: {
              title: "Trophies",
              tr: "video-clips:trophy"
            },
            attrs: {
              "group-start": ""
            },
            rows: [
              {
                toggle: "video_clips__trophy"
              },
              {
                text: "Record a {{video_clips__trophy_length}} clip when you redeem a channel point reward."
              }
            ]
          },
          {
            option: {
              title: "Record Other Redemptions",
              tr: "video-clips:foreign-trophy"
            },
            attrs: {
              "group-end": ""
            },
            rows: [
              {
                toggle: "record_foreign_rewards"
              },
              {
                text: 'Record it when someone else redeems a reward on your "Buy Later" list.'
              }
            ]
          }
        ]
      }
    ],
    settings: {
      video_clips__file_type: {
        type: "select",
        options: [
          {
            default: true,
            value: "x-matroska",
            label: "Easiest to share (MKV)",
            attrs: {
              "tr-id": "video-clips:file-type-options"
            }
          },
          {
            value: "webm;codecs=h264",
            label: "Most compatible (MP4)",
            attrs: {
              "tr-id": ""
            }
          },
          {
            value: "webm;codecs=vp8,vp9",
            label: "Most supported (AVI)",
            attrs: {
              "tr-id": ""
            }
          },
          {
            value: "webm;codecs=opus",
            label: "Easiest to edit (OGV)",
            attrs: {
              "tr-id": ""
            }
          },
          {
            value: "webm;codecs=3gpp",
            label: "Most mobile-friendly (3GP)",
            attrs: {
              "tr-id": ""
            }
          },
          {
            value: "webm",
            label: "Most efficient (WebM)",
            attrs: {
              "tr-id": ""
            }
          },
          {
            value: "mpeg",
            label: "Most dynamic (MPEG)",
            attrs: {
              "tr-id": ""
            }
          }
        ]
      },
      video_clips__quality: {
        type: "select",
        options: [
          {
            default: true,
            value: "auto",
            label: "Auto",
            attrs: {
              "tr-id": "video-clips:quality-options"
            }
          },
          {
            value: "source",
            label: "Source",
            attrs: {
              "tr-id": ""
            }
          },
          {
            value: "1080p",
            label: "1080p",
            attrs: {
              "tr-id": ""
            }
          },
          {
            value: "720p",
            label: "720p",
            attrs: {
              "tr-id": ""
            }
          },
          {
            value: "480p",
            label: "480p",
            attrs: {
              "tr-id": ""
            }
          },
          {
            value: "360p",
            label: "360p",
            attrs: {
              "tr-id": ""
            }
          },
          {
            value: "160p",
            label: "160p",
            attrs: {
              "tr-id": ""
            }
          }
        ]
      },
      video_clips__length: {
        type: "number",
        default: 60,
        min: 15,
        max: 300,
        step: 15,
        wrap: {
          "fix-unit": "sec"
        }
      },
      video_clips__dvr: {
        type: "checkbox",
        default: false
      },
      video_clips__trophy: {
        type: "checkbox",
        default: false
      },
      video_clips__trophy_length: {
        type: "number",
        default: 60,
        min: 15,
        max: 1800,
        step: 15,
        wrap: {
          "fix-unit": "sec"
        }
      },
      record_foreign_rewards: {
        type: "checkbox",
        default: false
      }
    }
  };

  // src/settings/sections/keep-pop-outs.js
  var keep_pop_outs_default = {
    title: "Keep Pop-outs",
    tr: "keep-popout",
    glyph: "video",
    flags: ["small", "gold"],
    keywords: "another,current,delay,development,expansion,extension,flood,flow,increase,other,page,postponement,rush,spate,stream,surge,televised,that,tide,torrent,tributary,video",
    rows: [
      {
        toggle: "keep_popout"
      },
      {
        text: "Keep small stream videos (pop-outs) open when you move to another page."
      }
    ],
    settings: {
      keep_popout: {
        type: "checkbox",
        default: false
      }
    }
  };

  // src/settings/sections/ram-alarms.js
  var ram_alarms_default = {
    title: "RAM Alarms",
    tr: "ram-alarms",
    glyph: "flag",
    flags: ["small", "gold"],
    badges: {
      new: "5.35.1"
    },
    rows: [
      {
        text: "What should TTV Tools do when a page uses a lot of memory? (The browser's Task Manager shows a bigger number: it counts the whole tab.)"
      },
      {
        extras: {
          title: "Alarms",
          tr: "alarms",
          subtitle: 'Adjust settings for "RAM Alarms"'
        },
        rows: [
          {
            html: `<div opt>
                            <div tr-id='ram-alarms:low'>When above <span unit='MB'><input id='ram_low' type='number' min='100' step='any' value='500'></span> — LOW</div>
                            <select id='ram_onlow'>
                                <option value='ignore' tr-id set='textContent→\\Glyphs.utf8.ignore \\this.textContent'>Ignore</option>
                                <option value='notify' tr-id set='textContent→\\Glyphs.utf8.notify \\this.textContent'>Notify</option>
                                <option value='respawn' tr-id set='textContent→\\Glyphs.utf8.refresh \\this.textContent'>Respawn</option>
                            </select>
                        </div>`
          },
          {
            html: `<div opt>
                            <div tr-id='ram-alarms:medium'>When above <span unit='GB'><input id='ram_medium' type='number' min='0.25' step='any' value='1'></span> — MEDIUM</div>
                            <select id='ram_onmedium'>
                                <option value='ignore' tr-id set='textContent→\\Glyphs.utf8.ignore \\this.textContent'>Ignore</option>
                                <option value='notify' tr-id set='textContent→\\Glyphs.utf8.notify \\this.textContent'>Notify</option>
                                <option value='respawn' tr-id set='textContent→\\Glyphs.utf8.refresh \\this.textContent'>Respawn</option>
                            </select>
                        </div>`
          },
          {
            html: `<div opt>
                            <div tr-id='ram-alarms:high'>When above <span unit='GB'><input id='ram_high' type='number' min='0.5' step='any' value='2'></span> — HIGH</div>
                            <select id='ram_onhigh'>
                                <option value='ignore' tr-id set='textContent→\\Glyphs.utf8.ignore \\this.textContent'>Ignore</option>
                                <option value='notify' tr-id set='textContent→\\Glyphs.utf8.notify \\this.textContent'>Notify</option>
                                <option value='respawn' tr-id set='textContent→\\Glyphs.utf8.refresh \\this.textContent'>Respawn</option>
                            </select>
                        </div>`
          },
          {
            html: `<div opt>
                            <div tr-id='ram-alarms:high'>Scale RAM usage with tab age</div>
                            <div class='toggle'>
                                <input id='ram_timescale' type='checkbox'>
                                <label for='ram_timescale'></label>
                            </div>
                        </div>`
          }
        ]
      },
      {
        // What RAM Alarms did in the last day, newest first: a page that reloads over and over shows up here, even
        // after it's gone (#67)
        extras: {
          title: "Logged Alarms",
          tr: "ram-alarm-daily",
          subtitle: "RAM Alarms over the last 24 hours"
        },
        rows: [
          {
            html: `<table id='ram-alarms--log' opt><tbody><tr><td>Nothing in the last day</td></tr></tbody></table>`
          }
        ]
      }
    ],
    settings: {
      ram_onlow: {
        type: "custom"
      },
      ram_onmedium: {
        type: "custom"
      },
      ram_onhigh: {
        type: "custom"
      },
      ram_timescale: {
        type: "custom"
      },
      ram_low: {
        type: "custom",
        default: 500
      },
      ram_medium: {
        type: "custom",
        default: 1
      },
      ram_high: {
        type: "custom",
        default: 2
      }
    }
  };

  // src/plugins/video-recovery/recover-stream.recover-ads.settings.js
  var recover_stream_recover_ads_settings_default = {
    title: "Recover Ads",
    tr: "recover-ads",
    glyph: "play",
    flags: ["small"],
    keywords: "ads,advertisement,announcement,attack,attempt,bid,broadcast,commercial,display,endeavor,endorsement,exhibit,experiment,literature,notice,placard,poster,propaganda,publication,publicity,pursuit,shot,struggle,try",
    rows: [
      {
        toggle: "recover_ads"
      },
      {
        text: "If an ad <b attention-text top-tooltip='Fails to play for more than 5 seconds'>freezes</b>, try to get it playing again."
      }
    ],
    settings: {
      recover_ads: {
        type: "checkbox",
        default: false,
        attrs: {
          requires: "#recover_stream"
        }
      }
    }
  };

  // src/plugins/video-recovery/recover-frames.settings.js
  var recover_frames_settings_default = {
    title: "Recover Frames",
    tr: "recover-frames",
    glyph: "video",
    flags: ["small"],
    badges: {
      new: "4.12.4"
    },
    keywords: "abnormal,abrogate,annul,attack,attempt,bid,current,damaged,deficient,drops,endeavor,experiment,faulty,flawed,flood,flow,frames,inadequate,insufficient,nullify,override,pursuit,quash,refill,refresh,reload,restock,restore,reverse,revoke,rush,seconds,shot,spate,stream,struggle,surge,televised,tide,torrent,tributary,try,unhealthy,unsound,veto,video,video,webpage",
    rows: [
      {
        toggle: "recover_frames"
      },
      {
        text: "If the video <b attention-text top-tooltip='Fails to play for longer than 15 seconds'>freezes</b>, reload the page."
      },
      {
        extras: {
          title: "Extras",
          tr: "extras",
          subtitle: 'Adjust settings for "Recover Frames"'
        },
        rows: [
          {
            option: {
              title: "Try Embed",
              tr: "recover-frames:extras"
            },
            rows: [
              {
                toggle: "recover_frames__allow_embed"
              },
              {
                text: "Try replacing the video with an embedded stream."
              }
            ]
          }
        ]
      }
    ],
    settings: {
      recover_frames: {
        type: "checkbox",
        default: true
      },
      recover_frames__allow_embed: {
        type: "checkbox",
        default: false
      }
    }
  };

  // src/plugins/video-recovery/recover-pages.settings.js
  var recover_pages_settings_default = {
    title: "Recover Pages",
    tr: "recover-pages",
    glyph: "extensions",
    flags: ["small"],
    keywords: "act,archive,array,attack,attempt,bid,certificate,demonstration,diary,display,endeavor,evidence,example,exhibit,experiment,form,pages,paper,parade,presentation,pursuit,record,report,script,shot,struggle,testimony,try,webpage",
    rows: [
      {
        toggle: "recover_pages"
      },
      {
        text: "If the page doesn't show, try to bring it back."
      }
    ],
    settings: {
      recover_pages: {
        type: "checkbox",
        default: false
      }
    }
  };

  // src/plugins/video-recovery/recover-stream.settings.js
  var recover_stream_settings_default = {
    title: "Recover Stream",
    tr: "recover-stream",
    glyph: "video",
    flags: ["small"],
    keywords: "attack,attempt,bid,current,endeavor,experiment,flood,flow,pursuit,rush,shot,spate,stream,struggle,surge,tide,torrent,tributary,try",
    rows: [
      {
        toggle: "recover_stream"
      },
      {
        text: "If the stream <b attention-text top-tooltip='Fails to play for more than 5 seconds'>freezes</b>, try to get it playing again."
      }
    ],
    settings: {
      recover_stream: {
        type: "checkbox",
        default: false
      }
    }
  };

  // src/plugins/video-recovery/recover-video.settings.js
  var recover_video_settings_default = {
    title: "Recover Video",
    tr: "recover-video",
    glyph: "video",
    flags: ["small"],
    keywords: "cover,curtain,download,load,log in,net,refill,refresh,reload,restock,restore,screen,televised,video,webpage",
    rows: [
      {
        toggle: "recover_video"
      },
      {
        text: "If the video <b attention-text top-tooltip='Displays an error code or blank screen'>fails to load</b>, reload the page."
      }
    ],
    settings: {
      recover_video: {
        type: "checkbox",
        default: true
      }
    }
  };

  // src/settings/sections/display-console-messages.js
  var display_console_messages_default = {
    title: "Display Console Messages",
    tr: "@console",
    glyph: "stats",
    flags: ["small", "gold"],
    keywords: "act,array,assuage,console,delay,demonstration,development,display,example,exhibit,expansion,extension,increase,messages,parade,postponement,presentation,soothe,writing",
    rows: [
      {
        toggle: "display_in_console"
      },
      {
        text: "Show TTV Tools messages in the browser console."
      },
      {
        extras: {
          title: "Extras",
          tr: "extras",
          subtitle: 'Adjust settings for "Display Console Messages"'
        },
        rows: [
          {
            option: {
              title: "Allow logs",
              tr: "@console.log"
            },
            rows: [
              {
                toggle: "display_in_console__log"
              },
              {
                text: "Display <code style:log>console.log</code> messages."
              }
            ]
          },
          {
            option: {
              title: "Allow warnings",
              tr: "@console.warn"
            },
            rows: [
              {
                toggle: "display_in_console__warn"
              },
              {
                text: "Display <code style:warn>console.warn</code> messages."
              }
            ]
          },
          {
            option: {
              title: "Allow errors",
              tr: "@console.error"
            },
            rows: [
              {
                toggle: "display_in_console__error"
              },
              {
                text: "Display <code style:error>console.error</code> messages."
              }
            ]
          },
          {
            option: {
              title: "Allow remarks",
              tr: "@console.remark"
            },
            rows: [
              {
                toggle: "display_in_console__remark"
              },
              {
                text: "Display <code style:remark>console.remark</code> messages."
              }
            ]
          },
          {
            option: {
              title: "Allow notices",
              tr: "@console.notice"
            },
            rows: [
              {
                toggle: "display_in_console__notice"
              },
              {
                text: "Display <code style:notice>console.notice</code> messages."
              }
            ]
          },
          {
            option: {
              title: "Allow ignores",
              tr: "@console.ignore"
            },
            rows: [
              {
                toggle: "display_in_console__ignore"
              },
              {
                text: "Display <code style:ignore>console.ignore</code> messages."
              }
            ]
          }
        ]
      }
    ],
    settings: {
      display_in_console: {
        type: "checkbox",
        default: false
      },
      display_in_console__log: {
        type: "checkbox",
        default: true
      },
      display_in_console__warn: {
        type: "checkbox",
        default: true
      },
      display_in_console__error: {
        type: "checkbox",
        default: true
      },
      display_in_console__remark: {
        type: "checkbox",
        default: true
      },
      display_in_console__notice: {
        type: "checkbox",
        default: true
      },
      display_in_console__ignore: {
        type: "checkbox",
        default: true
      }
    }
  };

  // src/settings/sections/display-statistics.js
  var display_statistics_default = {
    title: "Display Statistics",
    tr: "@stats",
    glyph: "stats",
    flags: ["small", "gold"],
    keywords: "act,array,data,delay,demonstration,development,display,example,exhibit,expansion,extension,increase,parade,postponement,presentation,statistics,stats",
    rows: [
      {
        toggle: "show_stats"
      },
      {
        text: "Show extra details from some features, like numbers, images and errors."
      }
    ],
    settings: {
      show_stats: {
        type: "checkbox",
        default: false
      }
    }
  };

  // src/plugins/developer/debug-recording.settings.js
  var debug_recording_settings_default = {
    title: "Debug Recording",
    tr: "debug-recording",
    glyph: "stats",
    flags: ["small"],
    badges: {
      new: "6.1"
    },
    keywords: "bug,capture,debug,error,history,issue,log,problem,record,recording,replay,report,timeline,trace,troubleshoot",
    rows: [
      {
        toggle: "debug_recording"
      },
      {
        text: "Keep a log of the last {{debug_recording__minutes}} of clicks, page changes, the video's status and what the extension did. <strong warning-text>Messages are hidden.</strong>"
      },
      {
        text: "Press <code>Ctrl</code> three times quickly on a Twitch page to save it as a file you can add to an issue."
      },
      {
        html: "<hr>"
      },
      {
        text: "Saved files are signed. Check one you received before you open it: a real recording only runs TTV Tools' own code, and its log hasn't been changed."
      },
      {
        html: "<p>This browser's key: <code id='debug-recording--key'>…</code></p>"
      },
      {
        html: "<input id='debug-recording--check-input' type='file' accept='.html, text/html' style='display:none!important'>"
      },
      {
        html: `<label id='debug-recording--check-label' for='debug-recording--check-input' type='button' top-tooltip='Check a recording without opening it'>
                    <span small glyph='checkmark'></span>
                    <span tr-id='debug-recording:check'>Check a file</span>
                </label>`
      },
      {
        html: "<output id='debug-recording--check-result' aria-live='polite' style='display:block; margin-top:0.5rem'></output>"
      }
    ],
    settings: {
      debug_recording: {
        type: "checkbox",
        default: false
      },
      "debug-recording--check-input": {
        type: "custom",
        store: false
      },
      debug_recording__minutes: {
        type: "number",
        default: 5,
        min: 1,
        max: 30,
        unit: "min"
      }
    }
  };

  // src/plugins/developer/developer-features.experimental-features.settings.js
  var developer_features_experimental_features_settings_default = {
    title: "Experimental Features",
    tr: "@experimental",
    glyph: "stats",
    flags: ["small"],
    keywords: "accident,act,array,casualty,catastrophe,cause,cost,damage,data,debt,defeat,deficit,delay,demonstration,destruction,development,disaster,display,dossier,element,evidence,example,exhibit,expansion,explanation,extension,failure,fall,goods,increase,info,injury,input,knowledge,loss,markdown,matter,motivation,motive,origin,parade,picture,postponement,presentation,principle,purpose,root,source,statistics,testimony,trouble",
    rows: [
      {
        toggle: "experimental_mode"
      },
      {
        text: "Try features that are still being tested."
      },
      {
        text: "Some of them may lose data.",
        attrs: {
          "warning-text": ""
        }
      }
    ],
    settings: {
      experimental_mode: {
        type: "checkbox",
        default: false
      }
    }
  };

  // src/plugins/developer/developer-features.settings.js
  var developer_features_settings_default = {
    title: "Extra Keyboard Shortcuts",
    tr: "@keyboard-shortcuts",
    glyph: "stats",
    flags: ["small"],
    badges: {
      new: "4.12.13"
    },
    keywords: "console,delay,development,expansion,extension,increase,keyboard,manual,piano,postponement,shortcuts",
    rows: [
      {
        toggle: "extra_keyboard_shortcuts"
      },
      {
        text: "Add extra keyboard shortcuts."
      },
      {
        text: "Press <code id='key:?'>?</code> on any stream to see them."
      }
    ],
    settings: {
      extra_keyboard_shortcuts: {
        type: "checkbox",
        default: true
      }
    }
  };

  // src/settings/sections/low-data-usage.js
  var low_data_usage_default = {
    title: "Low Data Usage",
    tr: "@low-data-mode",
    glyph: "stats",
    flags: ["small"],
    badges: {
      new: "4.30"
    },
    keywords: "appraisal,assessment,conclusion,data,delay,development,dossier,estimate,estimation,evaluation,evidence,expansion,extension,freedom,goods,guess,hour,increase,info,input,knowledge,management,measurement,opinion,opportunity,picture,postponement,projection,rating,statistics,survey,testimony,usage,valuation",
    rows: [
      {
        toggle: "low_data_mode"
      },
      {
        text: "Use less data each hour."
      },
      {
        text: "Current estimate: {{est-data-usage}}"
      }
    ],
    settings: {
      low_data_mode: {
        type: "checkbox",
        default: false,
        attrs: {
          "when-off": "5",
          "when-on": "15"
        }
      },
      "est-data-usage": {
        type: "number",
        default: 0,
        store: false,
        attrs: {
          disabled: "",
          visible: "",
          controller: "#low_data_mode"
        },
        wrap: {}
      }
    }
  };

  // src/settings/sections/user-scripts.js
  var user_scripts_default = {
    title: "User Scripts",
    tr: "user-scripts",
    glyph: "extensions",
    flags: ["small"],
    badges: {
      beta: "6.0"
    },
    keywords: "dsl,script,scripts,ttv,automation,plugin,plugins,custom,bot,commands",
    rows: [
      {
        text: "Write your own chat helpers: reply to commands, greet raiders or post on a timer. Each script gets its own switch and settings below."
      },
      {
        text: "Scripts run in chat. A script that asks for permissions waits until you approve them."
      },
      {
        html: "<div id='user-scripts-manager'></div>"
      }
    ],
    settings: {}
  };

  // src/settings/sections/use-fine-details.js
  var use_fine_details_default = {
    title: "Use Fine Details",
    tr: "@fine-details",
    glyph: "stats",
    flags: ["small"],
    keywords: "accomplished,action,admirable,attractive,background,beautiful,blink,contact,cool,data,delay,details,development,dossier,elegant,evidence,exceptional,expansion,expensive,experience,exquisite,extension,fashionable,fine,first-rate,flutter,goods,great,handsome,increase,info,input,involvement,jerk,jiggle,know-how,knowledge,lovely,magnificent,maturity,minutiae,neat,outstanding,participation,patience,picture,pleasant,postponement,practice,rare,reality,refined,sense,shudder,skill,smart,solid,splendid,statistics,striking,struggle,subtle,superior,testimony,training,tremble,twitch,understanding,well-made,wisdom",
    rows: [
      {
        toggle: "fine_details"
      },
      {
        text: "Use extra data from Twitch™ to improve features."
      },
      {
        text: "Nothing new is collected; it only uses data Twitch™ already has.",
        attrs: {
          "warning-text": ""
        }
      }
    ],
    settings: {
      fine_details: {
        type: "checkbox",
        default: false
      }
    }
  };

  // src/settings/sections/automatic-tab-reloads.js
  var automatic_tab_reloads_default = {
    title: "Automatic Tab Reloads",
    tr: "@auto-tab-reloads",
    glyph: "refresh",
    flags: ["small"],
    keywords: "cause,data,extension,loss,reload,reloads,tab,tabs",
    rows: [
      {
        toggle: "auto_tab_reloads"
      },
      {
        text: "Let TTV Tools reload tabs when needed."
      },
      {
        text: "Unsaved work in those tabs may be lost.",
        attrs: {
          "warning-text": ""
        }
      }
    ],
    settings: {
      auto_tab_reloads: {
        type: "checkbox",
        default: true
      }
    }
  };

  // src/settings/sections/show-default-values.js
  var show_default_values_default = {
    title: "Show Default Values",
    tr: "@default",
    glyph: "info",
    flags: ["small"],
    badges: {
      "hide-on": "show-defaults"
    },
    keywords: "default,delinquency,nonpayment,values",
    rows: [
      {
        html: `<div>
                    <a href='?show-defaults=true' target='_self' continue-search>
                        <button tr-id>Show</button>
                    </a>
                </div>`
      },
      {
        text: "Show each setting's default value."
      }
    ],
    settings: {}
  };

  // src/plugins/automation/auto-focus.settings.js
  var auto_focus_settings_default = {
    title: "Auto-Focus",
    tr: "@@auto-focus",
    glyph: "show",
    flags: ["small"],
    keywords: "action,activity,appearance,auto focus,bar,block,break,conclusion,copy,current,detection,disclosure,drawing,election,enterprise,exercise,figure,flood,flow,focal point,focus,form,hiatus,icon,illustration,image,infinitesimal,insignificant,intermission,interruption,interval,layoff,life,likeness,lull,microscopic,minimal,minuscule,minute,model,movement,pause,photograph,picture,plebiscite,polling,portrait,precise,referendum,rush,slate,spate,spell,spotlight,statue,stop,stream,surge,tally,target,ticket,tide,timer,tiny,torrent,tributary,tributary",
    rows: [
      {
        toggle: "auto_focus"
      },
      {
        text: "Adjust <b>Up Next</b> and <b>Easy Lurk</b> based on how active the stream is."
      },
      {
        text: "This does <b>not</b> stop the <b>Up Next</b> one-minute timer.",
        attrs: {
          "warning-text": ""
        }
      },
      {
        extras: {
          title: "Options",
          tr: "options",
          subtitle: 'Adjust options for "Auto-Focus"'
        },
        rows: [
          {
            html: `<div>
                            <div class='title' tr-id='@@auto-focus:options:detection-level'>Detection Level</div>
                            <div class='summary'>
                                <p tr-id>
                                    How much activity should activate <b>Auto-Focus</b>?
                                </p>

                                <select id='auto_focus_detection_threshold'>
                                    <option value='0' selected tr-id>Automatic</option>
                                    <option value='30' tr-id>High activity — FPS / IRL / Rhythm</option>
                                    <option value='20' tr-id>Modest activity — Action / Adventure / Platformer</option>
                                    <option value='10' tr-id>Seasonal activity — Horror / Puzzle / Trivia</option>
                                    <option value='5' tr-id>Low activity — Just Chatting / Simulation / Strategy</option>
                                </select>
                            </div>
                        </div>`
          },
          {
            html: `<div>
                            <div class='title' tr-id='@@auto-focus:options:polling-interval'>Polling Interval</div>
                            <div class='summary'>
                                <p tr-id>
                                    How often should the stream be <b attention-text left-tooltip='A screenshot of the stream will be taken to detect activity'>polled</b>?
                                </p>

                                <select id='auto_focus_poll_interval'>
                                    <option value='1' tr-id>Every second — CPU intensive, great detection</option>
                                    <option value='3' selected tr-id>Every 3 seconds — CPU friendly, good detection</option>
                                    <option value='5' tr-id>Every 5 seconds — CPU friendly, fair detection</option>
                                    <option value='10' tr-id>Every 10 seconds — CPU friendly, poor detection</option>
                                </select>
                            </div>
                        </div>`
          },
          {
            html: `<div>
                            <div class='title' tr-id='@@auto-focus:options:image-type'>Image Type</div>
                            <div class='summary'>
                                <p tr-id>
                                    What image type should be used for <b attention-text left-tooltip='A screenshot of the stream will be taken to detect activity'>polling</b>?
                                </p>

                                <select id='auto_focus_poll_image_type'>
                                    <option value='webp' selected tr-id>Automatic</option>
                                    <option value='jpeg' tr-id>JPG — CPU friendly, good detection</option>
                                    <option value='png' tr-id>PNG — CPU intensive, great detection</option>
                                    <option value='webp' tr-id>WebP — CPU friendly, great detection</option>
                                </select>
                            </div>
                        </div>`
          }
        ]
      }
    ],
    settings: {
      auto_focus: {
        type: "checkbox",
        default: false
      },
      auto_focus_detection_threshold: {
        type: "custom",
        default: "0"
      },
      auto_focus_poll_interval: {
        type: "custom",
        default: "3"
      },
      auto_focus_poll_image_type: {
        type: "custom",
        default: "webp"
      }
    }
  };

  // src/plugins/chat/convert-emotes.settings.js
  var convert_emotes_settings_default = {
    title: "Convert emotes",
    tr: "@@convert-emotes",
    glyph: "emotes",
    flags: ["small", "gold"],
    keywords: "blink,contribution,current,decipher,emotes,flood,flow,flutter,jerk,jiggle,management,rush,shudder,spate,stream,subscription,surge,tide,torrent,tremble,tributary,twitch,undo,unlock,unravel,usage,viewing",
    rows: [
      {
        toggle: "convert_emotes"
      },
      {
        text: "Collect emotes from the stream you're watching, so you can use them without subscribing."
      },
      {
        text: "This does <b>not</b> unlock or save them.",
        attrs: {
          "warning-text": ""
        }
      }
    ],
    settings: {
      convert_emotes: {
        type: "checkbox",
        default: false
      }
    }
  };

  // src/plugins/chat/safe-soft-unban.settings.js
  var safe_soft_unban_settings_default = {
    title: "Soft Unban",
    tr: "@@soft-unban",
    glyph: "chat",
    flags: ["small", "gold"],
    badges: {
      new: "3.1"
    },
    keywords: "channels,charge,chatter,conversation,gossip,handling,management,manipulation,oversight,plan,policy,strategy,transaction,treatment,viewing",
    rows: [
      {
        toggle: "soft_unban"
      },
      {
        text: "Read chat in channels that banned you."
      },
      {
        text: "You still can't send messages.",
        attrs: {
          "warning-text": ""
        }
      },
      {
        extras: {
          title: "Options",
          tr: "options",
          subtitle: 'Adjust options for "Soft Unban"'
        },
        rows: [
          {
            option: {
              title: "Fade Messages",
              tr: "@@soft-unban:options:fade-messages"
            },
            rows: [
              {
                toggle: "soft_unban_fade_old_messages"
              },
              {
                text: "Messages fade after <b>30s</b>."
              }
            ]
          },
          {
            option: {
              title: "Keep Bots",
              tr: "@@soft-unban:options:keep-bots"
            },
            rows: [
              {
                toggle: "soft_unban_keep_bots"
              },
              {
                text: "Show bot messages."
              }
            ]
          },
          {
            option: {
              title: "Prevent Clips",
              tr: "@@soft-unban:options:prevent-clips"
            },
            rows: [
              {
                toggle: "soft_unban_prevent_clipping"
              },
              {
                text: "Hide Twitch™ clips."
              }
            ]
          }
        ]
      }
    ],
    settings: {
      soft_unban: {
        type: "checkbox",
        default: false
      },
      soft_unban_fade_old_messages: {
        type: "checkbox",
        default: false
      },
      soft_unban_keep_bots: {
        type: "checkbox",
        default: false
      },
      soft_unban_prevent_clipping: {
        type: "checkbox",
        default: false
      }
    }
  };

  // src/settings/sections/version.js
  var version_default = {
    title: "Version",
    tr: "version",
    glyph: "extensions",
    flags: ["small"],
    keywords: "adaptation,advice,clue,data,form,history,information,instruction,intelligence,interpretation,knowledge,material,message,rendition,report,science,story,tale,tip,translation,variant,version,word",
    rows: [
      {
        html: "<a type='button' set='subtitle=version.installed'><span small glyph='extensions'></span> Installed</a>"
      },
      {
        html: "<a type='button' set='subtitle=version.github;from-github=origin.github' href='https://github.com/ephellon/twitch-tools' github><span small glyph='github'></span> GitHub </a>"
      },
      {
        html: "<a type='button' set='subtitle=version.chrome;from-chrome=origin.chrome' href='https://chrome.google.com/webstore/detail/twitch-tools/fcfodihfdbiiogppbnhabkigcdhkhdjd' chrome><span small glyph='chrome'></span> Chrome Web Store </a>"
      }
    ],
    settings: {}
  };

  // src/settings/sections/data-usage.js
  var data_usage_default = {
    title: "Data Usage",
    tr: "data-usage--browser-storage",
    glyph: "poll",
    flags: ["small"],
    keywords: "data,dossier,evidence,goods,info,input,knowledge,management,picture,statistics,testimony,usage",
    rows: [
      {
        tr: false,
        text: ""
      },
      {
        html: `<table id='data-usage--browser-storage-itemized'>
                        <thead>
                            <tr>
                                <th colspan='999'><button id='data-usage--browser-storage-range' data-zoomed='false' visible style='margin:0;width:100%'></button></th>
                            </tr>
                        </thead>
                    </table>`
      },
      {
        tr: false,
        text: ""
      }
    ],
    settings: {}
  };

  // src/settings/sections/support.js
  var support_default = {
    title: "Support",
    tr: "support",
    glyph: "info",
    flags: ["small"],
    keywords: "backing,help,support",
    rows: [
      {
        html: `<a type='button' href='https://github.com/ephellon/twitch-tools' top-tooltip='Fastest communication method' github>
                    <span small glyph='github'></span>
                    GitHub
                </a>`
      },
      {
        html: `<a type='button' href='https://chrome.google.com/webstore/detail/twitch-tools/fcfodihfdbiiogppbnhabkigcdhkhdjd' top-tooltip='Reasonable communication method'>
                    <span small glyph='chrome'></span>
                    Chrome Web Store
                </a>`
      },
      {
        html: `<a disabled type='button' href='#mailto:minkcbos@gmail.com?subject=Twitch%20Tools' top-tooltip='Slowest communication method'>
                    <span small glyph='unread'></span>
                    e-mail
                </a>`
      }
    ],
    settings: {}
  };

  // src/settings/sections/language.js
  var language_default = {
    title: "Language",
    tr: "language",
    glyph: "translate",
    flags: ["small"],
    badges: {
      dead: "5.30"
    },
    keywords: "accent,dialect,expression,jargon,language,prose,sound,speech,style,terminology,vocabulary,voice,word,wording",
    rows: [
      {
        select: "user_language_preference"
      }
    ],
    settings: {
      user_language_preference: {
        type: "select",
        options: [
          {
            default: true,
            value: "en",
            label: "English (North American)"
          }
        ],
        attrs: {
          disabled: ""
        }
      }
    }
  };

  // src/settings/layout.js
  var layout_default = [
    {
      header: "Up Next &amp; Channel Hopping",
      tr: "header:up-next",
      headerAttrs: {
        subtitle: "Keep watching without babysitting the page."
      },
      save: true,
      sections: [
        auto_follow_settings_default,
        auto_join_settings_default,
        max_watchtime_settings_default,
        next_channel_default,
        prevent_raiding_settings_default,
        stay_live_settings_default,
        streak_saver_settings_default,
        first_in_line_settings_default
      ]
    },
    {
      header: "Lurking",
      tr: "header:lurking",
      headerAttrs: {
        subtitle: "Watch in the background."
      },
      save: true,
      sections: [
        lurking_settings_default,
        kill_extensions_settings_default,
        auto_chat_vip_settings_default
      ]
    },
    {
      header: "Free Points &amp; Loot",
      tr: "header:free-points",
      headerAttrs: {
        subtitle: "Collect everything automatically."
      },
      save: true,
      sections: [
        auto_claim_bonuses_settings_default,
        claim_drops_settings_default,
        claim_loot_settings_default,
        claim_prime_settings_default
      ]
    },
    {
      header: "Points &amp; Bits Info",
      tr: "header:points-info",
      headerAttrs: {
        subtitle: "See what you have earned, and what things cost."
      },
      save: true,
      sections: [
        points_receipt_channel_points_receipt_settings_default,
        convert_bits_settings_default,
        point_watcher_settings_default,
        points_receipt_settings_default,
        rewards_calculator_settings_default,
        watch_time_settings_default
      ]
    },
    {
      header: "Reading Chat",
      tr: "header:reading-chat",
      headerAttrs: {
        subtitle: "Except where noted, these don't apply in channels you're banned from."
      },
      save: true,
      sections: [
        bttv_emotes_settings_default,
        filter_messages_settings_default,
        highlight_mentions_settings_default,
        highlight_phrases_settings_default,
        mention_audio_settings_default,
        prevent_spam_settings_default,
        recover_chat_settings_default,
        recover_messages_settings_default,
        highlight_mentions_popup_settings_default,
        simplify_chat_settings_default
      ]
    },
    {
      header: "Talking in Chat",
      tr: "header:talking-in-chat",
      headerAttrs: {
        subtitle: "Type and reply faster."
      },
      save: true,
      sections: [
        link_maker_chat_settings_default,
        native_twitch_reply_settings_default,
        parse_commands_settings_default
      ]
    },
    {
      header: "Fix Broken Streams",
      tr: "header:fix-streams",
      headerAttrs: {
        subtitle: "Stop freezes, ads and black screens."
      },
      save: true,
      sections: [
        hide_blank_ads_settings_default,
        keep_pop_outs_default,
        ram_alarms_default,
        recover_stream_recover_ads_settings_default,
        recover_frames_settings_default,
        recover_pages_settings_default,
        recover_stream_settings_default,
        recover_video_settings_default
      ]
    },
    {
      header: "Looks &amp; Extras",
      tr: "header:looks",
      headerAttrs: {
        subtitle: "Change how Twitch looks."
      },
      save: true,
      sections: [
        accent_color_default,
        block_banners_settings_default,
        auto_dvr_settings_default,
        context_menu_override_default,
        store_integration_settings_default,
        stream_preview_settings_default,
        time_zones_settings_default,
        view_mode_settings_default
      ]
    },
    {
      header: "Data &amp; Sync",
      tr: "header:data",
      headerAttrs: {
        subtitle: "Move, back up or limit your data. Some of these use the Internet."
      },
      save: true,
      sections: [
        data_usage_default,
        language_default,
        low_data_usage_default,
        site_access_default,
        export_settings_default,
        user_scripts_default
      ],
      // The installed scripts and the permissions approved for them (kept by the User Scripts list, not a control)
      stored: ["user_scripts", "user_scripts__consent"]
    },
    {
      header: "Troubleshooting",
      tr: "header:troubleshooting",
      headerAttrs: {
        subtitle: "Help find a bug. These are advanced features."
      },
      attrs: {
        id: ":settings--developer",
        danger: ""
      },
      save: true,
      sections: [
        automatic_tab_reloads_default,
        debug_recording_settings_default,
        display_console_messages_default,
        display_statistics_default,
        developer_features_experimental_features_settings_default,
        developer_features_settings_default,
        show_default_values_default,
        use_fine_details_default
      ]
    },
    {
      header: "Experimental",
      tr: "header:experimental-features",
      headerAttrs: {
        subtitle: "Features still being tested. They may cause errors."
      },
      attrs: {
        id: ":settings--experimental",
        caution: ""
      },
      save: true,
      sections: [
        auto_focus_settings_default,
        convert_emotes_settings_default,
        safe_soft_unban_settings_default
      ]
    },
    {
      header: "About TTV Tools",
      tr: "about",
      footer: `<footer tr-id='footer'>
            <div>
                <h3>This extension is in no way affiliated with, nor endorsed by:</h3>
                <ul>
                    <li>
                        <a href='https://www.amazon.com/gp/help/customer/display.html?nodeId=G202075070' target='_blank'>Amazon.com, Inc.</a>
                        <ul>
                            <li><a href='https://twitch.tv/legal' target='_blank'>Twitch Interactive, Inc.</a></li>
                        </ul>
                    </li>
                    <li><a href='https://blerp.com/legal' target='_blank'>Blerp, Inc.</a></li>
                    <li><a href='https://policies.google.com/terms' target='_blank'>Google, LLC</a></li>
                    <li><a href='https://streamelements.com/terms' target='_blank'>Live Momentum, Ltd.</a></li>
                    <li>
                        <a href='https://microsoft.com/legal/terms-of-use' target='_blank'>Microsoft Co.</a>
                        <ul>
                            <li><a href='https://github.com/site-policy/github-terms' target='_blank'>GitHub, Inc.</a></li>
                        </ul>
                    </li>
                    <li><a href='https://nightdev.com/terms' target='_blank'>NightDev, LLC</a></li>
                    <li><a href='https://nintendo.com/terms-of-use' target='_blank'>Nintendo Co., Ltd.</a></li>
                    <li><a href='https://electronics.sony.com/terms-conditions' target='_blank'>Sony Group Co.</a></li>
                    <li><a href='https://streamloots.com/terms-and-conditions' target='_blank'>Streamloots</a></li>
                    <li><a href='https://valvesoftware.com/legal' target='_blank'>Valve Co.</a></li>
                    <li><em>...either aforementioned party's partners, affiliates, or subsidiaries.</em></li>
                </ul>
            </div>
        </footer>`,
      stored: ["clientID", "oauthToken"],
      sections: [
        support_default,
        version_default
      ]
    }
  ];

  // src/settings/render.js
  var escapeAttribute = /* @__PURE__ */ __name((value) => String(value).replace(/&/g, "&amp;").replace(/"/g, "&quot;").replace(/</g, "&lt;"), "escapeAttribute");
  function attributes(attrs = {}) {
    let html = "";
    for (const name in attrs) {
      const value = attrs[name];
      if (value === false || value == null)
        continue;
      html += value === "" || value === true ? ` ${name}` : ` ${name}="${escapeAttribute(value)}"`;
    }
    return html;
  }
  __name(attributes, "attributes");
  function control(id, setting) {
    if (setting == null)
      throw new Error(`Setting "${id}" is used but not defined`);
    if (setting.type == "select") {
      const options = setting.options.map(
        ({ label, value: value2, default: selected, attrs: attrs2 }) => `<option${attributes({ value: value2, ...attrs2, selected: selected ? "" : null })}>${label}</option>`
      ).join("");
      return `<select${attributes({ id, ...setting.attrs })}>${options}</select>`;
    }
    const { type, default: value, group: name, min, max, step, placeholder, unit, attrs, wrap = unit ? { unit } : null } = setting;
    const toggled = type == "checkbox" || type == "radio";
    const input = `<input${attributes({ id, type, name, min, max, step, placeholder, ...toggled ? {} : { value }, ...attrs, ...toggled && value ? { checked: "" } : {} })}>`;
    return wrap ? `<span${attributes(wrap)}>${input}</span>` : input;
  }
  __name(control, "control");
  function fill(text, settings) {
    return text.replace(/\{\{([\w\-:]+)\}\}/g, ($0, $1, $$, $_) => control($1, settings[$1]));
  }
  __name(fill, "fill");
  function titleBar({ title, tr, glyph, flags = [], attrs }) {
    const icon = glyph ? `<span${attributes(Object.fromEntries(flags.map((flag) => [flag, ""])))} glyph="${escapeAttribute(glyph)}"></span> ` : "";
    return `<div class="title"${attributes({ "tr-id": tr, ...attrs })}>${icon}${title}</div>`;
  }
  __name(titleBar, "titleBar");
  function renderRows(rows, settings) {
    return rows.map((row) => {
      if ("html" in row)
        return row.html;
      if ("toggle" in row) {
        const id = row.toggle;
        return `<div class="toggle">${control(id, settings[id])}<label for="${id}"></label></div>`;
      }
      if ("select" in row)
        return control(row.select, settings[row.select]);
      if ("choice" in row) {
        const id = row.choice;
        return `<div class="radio"${attributes(row.attrs)}>${control(id, settings[id])}<label${attributes({ "tr-id": row.tr, for: id })}><h2${attributes(row.titleAttrs)}>${row.title}</h2> ${fill(row.text ?? "", settings)}</label></div>`;
      }
      if ("text" in row) {
        const tr = row.tr === false ? null : row.tr ?? "";
        return `<p${attributes({ ...row.attrs, "tr-id": tr })}>${fill(row.text, settings)}</p>`;
      }
      if ("extras" in row) {
        const { title, tr, subtitle, attrs } = row.extras;
        return `<details${attributes(row.attrs)}><summary${attributes({ "tr-id": tr, subtitle, ...attrs })}>${title}</summary><div${attributes(row.panelAttrs)}>${renderRows(row.rows, settings)}</div></details>`;
      }
      if ("option" in row)
        return `<div opt${attributes(row.attrs)}>${titleBar(row.option)}<div class="summary">${renderRows(row.rows, settings)}</div></div>`;
      throw new Error(`Unknown settings row: ${JSON.stringify(row).slice(0, 80)}`);
    }).join("");
  }
  __name(renderRows, "renderRows");
  function renderSection(section) {
    if ("html" in section)
      return section.html;
    const { badges, summaryAttrs, rows, settings = {} } = section;
    return `<section${attributes(badges)}>${titleBar(section)}<div class="summary"${attributes(summaryAttrs)}>${renderRows(rows, settings)}</div></section>`;
  }
  __name(renderSection, "renderSection");
  function renderLayout(groups) {
    const jump = groups.map(({ header, tr }) => `<a href="#${groupId(tr)}"${attributes({ "tr-id": tr })}>${header}</a>`).join("");
    return `<nav id="jump-to" aria-label="Groups">${jump}</nav>` + groups.map(({ header, tr, headerAttrs, attrs, save, footer = "", sections }) => {
      const saveButton = save ? `<section save tr-id="save"><button class="ripple save">Save</button></section>` : "";
      return `<header${attributes({ id: groupId(tr), "tr-id": tr, ...headerAttrs })}>${header}</header><article${attributes(attrs)}>${sections.map(renderSection).join("")}${saveButton}${footer}</article>`;
    }).join("");
  }
  __name(renderLayout, "renderLayout");
  function groupId(tr) {
    return `group-${String(tr).replace(/^header:/, "").replace(/[^\w-]+/g, "-")}`;
  }
  __name(groupId, "groupId");
  function settingIds(groups) {
    return groups.flatMap(({ sections, stored = [] }) => [
      ...sections.flatMap(({ settings = {} }) => Object.keys(settings).filter((id) => settings[id].store !== false)),
      ...stored
    ]);
  }
  __name(settingIds, "settingIds");
  function settingDefaults(groups) {
    const defaults = {};
    for (const { sections } of groups)
      for (const { settings = {} } of sections)
        for (const id in settings) {
          const setting = settings[id];
          if (setting.store === false)
            continue;
          if (setting.type == "custom") {
            if ("default" in setting)
              defaults[id] = String(setting.default);
            continue;
          }
          if (setting.type == "select") {
            const option = setting.options.find((option2) => option2.default) ?? setting.options[0];
            defaults[id] = (option == null ? void 0 : option.value) ?? (option == null ? void 0 : option.label.replace(/<[^>]*>/g, "").trim()) ?? null;
          } else if (setting.type == "checkbox" || setting.type == "radio") {
            defaults[id] = !!setting.default;
          } else if ("default" in setting) {
            defaults[id] = setting.scale ? Number(setting.default) * setting.scale : String(setting.default);
          }
        }
    return defaults;
  }
  __name(settingDefaults, "settingDefaults");

  // src/lib/dsl-host.js
  var CHANNEL_FIELDS = Object.freeze({
    name: "name",
    id: "sole",
    live: "live",
    title: "desc",
    game: "game",
    viewers: "poll",
    uptime: "time",
    points: "coin",
    subscribed: "paid",
    following: "like",
    rerun: "redo",
    tags: "tags"
  });

  // src/lib/user-scripts.js
  var SCRIPTS_KEY = "user_scripts";
  var CONSENT_KEY = "user_scripts__consent";
  function grantsOf(permissions = []) {
    return [...new Set(permissions.flatMap(({ permissions: permissions2 }) => permissions2))].sort().join(" ");
  }
  __name(grantsOf, "grantsOf");

  // src/settings/user-scripts.js
  var RETURN_HASH = "user-scripts-manager";
  var _a, _b;
  var STORAGE = (_b = (_a = globalThis.browser ?? globalThis.chrome) == null ? void 0 : _a.storage) == null ? void 0 : _b.local;
  var TEMPLATE = [
    'plugin hello_bot -- "Hello Bot"',
    '    about "Replies when someone says !hello, waves on !bye, and remembers who it greeted last."',
    '    setting reply: text "Hi there!" -- "Reply with the following"',
    '    setting reminders: checkbox true -- "Remind chat every 15 minutes"',
    "",
    "// Chat commands",
    "await (.command is SOMETHING)",
    "    when .command is",
    '        "hello":',
    "            // `!hello @zip` greets zip; a bare `!hello` replies to whoever asked",
    "            if .argument is SOMETHING",
    "                POST `${ setting.reply } ${ .argument }`",
    "            else",
    "                REPLY setting.reply",
    "",
    "            // Remembered for `!who` below",
    "            .sender -> last_greeted",
    "",
    '        "bye":',
    "            // A different goodbye each time",
    "            REPLY any from (",
    "                `See you later!`",
    "                `Thanks for stopping by 💜`",
    "                `Take care!`",
    "            )",
    "",
    '        "who":',
    "            if last_greeted is SOMETHING",
    "                REPLY `The last person I said hi to was ${ last_greeted }.`",
    "            else",
    "                REPLY `Nobody has said !hello yet. Be the first!`",
    "",
    "// Moderators get a salute when they say hello",
    'await (.command is "hello")',
    "    using [moderator]",
    "        POST `🛡️ ${ .sender } is on duty.`",
    "",
    "// Every 15 minutes, but only while the stream is live",
    "await 15:00 with (#live is true)",
    "    if setting.reminders",
    "        POST `Type !hello and I'll say hi 🤖`",
    ""
  ].join("\n");
  var read = /* @__PURE__ */ __name((keys) => new Promise((resolve) => STORAGE.get(keys, resolve)), "read");
  var write = /* @__PURE__ */ __name((values) => new Promise((resolve) => STORAGE.set(values, resolve)), "write");
  var ask = /* @__PURE__ */ __name(async (html) => !!await confirm(`${html}<!-- ${Date.now()} -->`), "ask");
  var escape = /* @__PURE__ */ __name((text) => String(text).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;"), "escape");
  function inspectAll(scripts) {
    return scripts.map(({ file, source }) => ({ file, source, ...TTV_DSL.inspect(source, { file }) }));
  }
  __name(inspectAll, "inspectAll");
  function statusOf(script, consent) {
    const required = grantsOf(script.meta.permissions);
    if (script.diagnostics.length)
      return { label: `${script.diagnostics.length} problem${script.diagnostics.length > 1 ? "s" : ""}`, kind: "error" };
    if (required && consent[script.meta.id] !== required)
      return { label: "Needs approval", kind: "warning" };
    return { label: "Ready", kind: "ok" };
  }
  __name(statusOf, "statusOf");
  function highlighted(source) {
    return TTV_DSL.highlight(source).map(({ type, text }) => `<span class="ttv-dsl-${type}">${escape(text)}</span>`).join("") + "\n";
  }
  __name(highlighted, "highlighted");
  function openEditor({ source, file, original, taken }) {
    return new Promise((resolve) => {
      const overlay = document.createElement("div");
      overlay.id = "user-script-editor";
      overlay.innerHTML = `
            <div class="user-script-editor--dialog" role="dialog" aria-label="Script editor">
                <div class="user-script-editor--head"><strong>${escape(file)}</strong><span class="user-script-editor--meta"></span></div>
                <div class="user-script-editor--code">
                    <div class="user-script-editor--gutter" aria-hidden="true"></div>
                    <pre aria-hidden="true"></pre>
                    <textarea spellcheck="false" autocomplete="off" autocapitalize="off"></textarea>
                </div>
                <ul class="user-script-editor--problems"></ul>
                <div class="user-script-editor--actions"><button class="user-script-editor--cancel">Cancel</button><button class="user-script-editor--save">Save</button></div>
            </div>`;
      const textarea = overlay.querySelector("textarea"), pre = overlay.querySelector("pre"), gutter = overlay.querySelector(".user-script-editor--gutter"), problems = overlay.querySelector(".user-script-editor--problems"), meta = overlay.querySelector(".user-script-editor--meta"), save = overlay.querySelector(".user-script-editor--save");
      let timer = null, faulty = /* @__PURE__ */ new Set();
      const number = /* @__PURE__ */ __name(() => {
        const count = textarea.value.split("\n").length;
        gutter.innerHTML = Array.from({ length: count }, (_, index) => `<div${faulty.has(index + 1) ? " problem" : ""}>${index + 1}</div>`).join("");
        gutter.scrollTop = textarea.scrollTop;
      }, "number");
      const refresh = /* @__PURE__ */ __name(() => {
        const text = textarea.value, { meta: info } = TTV_DSL.inspect(text, { file }), found = TTV_DSL.check(text);
        pre.innerHTML = highlighted(text);
        if (info.id != original && taken.has(info.id))
          found.unshift({ message: `The id "${info.id}" is already used by another setting or script`, loc: { line: 1, column: 1 } });
        meta.textContent = ` — ${info.name} (${info.id})`;
        problems.innerHTML = found.map(({ message, loc }) => `<li><code>${(loc == null ? void 0 : loc.line) ?? "?"}:${(loc == null ? void 0 : loc.column) ?? "?"}</code> ${escape(message)}</li>`).join("");
        save.disabled = found.length > 0;
        faulty = new Set(found.map(({ loc }) => loc == null ? void 0 : loc.line).filter(Boolean));
        number();
      }, "refresh");
      textarea.value = source;
      textarea.addEventListener("input", () => {
        clearTimeout(timer);
        timer = setTimeout(refresh, 150);
        pre.innerHTML = highlighted(textarea.value);
        number();
      });
      textarea.addEventListener("scroll", () => {
        pre.scrollTop = gutter.scrollTop = textarea.scrollTop;
        pre.scrollLeft = textarea.scrollLeft;
      });
      textarea.addEventListener("keydown", (event) => {
        if (event.key != "Tab" || event.ctrlKey || event.altKey || event.metaKey)
          return;
        event.preventDefault();
        document.execCommand("insertText", false, "    ");
      });
      const close = /* @__PURE__ */ __name((result) => {
        overlay.remove();
        resolve(result);
      }, "close");
      overlay.querySelector(".user-script-editor--cancel").onclick = () => close(null);
      save.onclick = () => close({ file, source: textarea.value });
      document.body.append(overlay);
      refresh();
      textarea.focus();
    });
  }
  __name(openEditor, "openEditor");
  async function askApproval(script) {
    const rows = script.meta.permissions.map(
      ({ permissions, description, line }) => `<li><code>${permissions.map(escape).join(", ")}</code><span>${escape(description ?? "")}</span><small>line ${line}</small></li>`
    ).join("");
    return ask(`<div class="user-scripts--approval">
        <p><strong>${escape(script.meta.name)}</strong> asks for these permissions:</p>
        <ul>${rows}</ul>
        <p class="user-scripts--approval-note">Only approve scripts you trust.</p>
    </div>`);
  }
  __name(askApproval, "askApproval");
  async function renderUserScripts({ ids, defaults }) {
    var _a3;
    const manager = document.getElementById("user-scripts-manager");
    if (!manager || !STORAGE || !globalThis.TTV_DSL)
      return;
    const stored = await read([SCRIPTS_KEY, CONSENT_KEY]), scripts = inspectAll(stored[SCRIPTS_KEY] ?? []), consent = { ...stored[CONSENT_KEY] }, builtIn = new Set(ids);
    const sections = scripts.filter(({ meta }) => !builtIn.has(meta.id)).map(({ meta }) => meta.section);
    const section = manager.closest("section");
    section.insertAdjacentHTML("afterend", sections.map(renderSection).join(""));
    for (const { meta } of scripts)
      for (const key of Object.keys(meta.settings ?? {}))
        if (!ids.includes(key))
          ids.push(key);
    Object.assign(defaults, settingDefaults([{ sections }]));
    const reload = /* @__PURE__ */ __name(() => {
      location.hash = RETURN_HASH;
      location.reload();
    }, "reload");
    if (location.hash == `#${RETURN_HASH}`) {
      const settle = /* @__PURE__ */ __name(() => [600, 1500].forEach((delay) => setTimeout(() => section.scrollIntoView({ block: "start", behavior: "instant" }), delay)), "settle");
      if (document.readyState == "complete")
        settle();
      else
        window.addEventListener("load", settle, { once: true });
      history.replaceState(null, "", location.pathname + location.search);
    }
    const taken = /* @__PURE__ */ __name(() => /* @__PURE__ */ new Set([...builtIn, ...scripts.map(({ meta }) => meta.id)]), "taken");
    const store = /* @__PURE__ */ __name(async (list) => {
      await write({ [SCRIPTS_KEY]: list.map(({ file, source }) => ({ file, source })) });
      reload();
    }, "store");
    manager.innerHTML = `
        <table class="user-scripts--list">${scripts.map((script, index) => {
      const { label, kind } = statusOf(script, consent);
      return `<tr data-index="${index}">
                <td><strong>${escape(script.meta.name)}</strong> <code>${escape(script.meta.id)}</code></td>
                <td><span class="user-scripts--status" status="${kind}">${label}</span></td>
                <td>${kind == "warning" ? '<button class="approve">Approve…</button> ' : ""}<button class="edit">Edit</button> <button class="remove">Remove</button></td>
            </tr>`;
    }).join("") || "<tr><td>No scripts yet.</td></tr>"}</table>
        <div class="user-scripts--actions">
            <button class="new">New script</button>
            <input type="file" accept=".ttv,text/plain" hidden>
            <button class="import">Import .ttv…</button>
        </div>`;
    for (const row of manager.querySelectorAll("tr[data-index]")) {
      const script = scripts[+row.dataset.index];
      row.querySelector(".edit").onclick = async () => {
        const others = taken();
        others.delete(script.meta.id);
        const result = await openEditor({ source: script.source, file: script.file, original: script.meta.id, taken: others });
        if (result)
          await store(scripts.map((other) => other == script ? result : other));
      };
      row.querySelector(".remove").onclick = async () => {
        if (!await ask(`Remove <strong>${escape(script.meta.name)}</strong>? Its settings are kept until you reinstall or reset.`))
          return;
        delete consent[script.meta.id];
        await write({ [CONSENT_KEY]: consent });
        await store(scripts.filter((other) => other != script));
      };
      (_a3 = row.querySelector(".approve")) == null ? void 0 : _a3.addEventListener("click", async () => {
        if (!await askApproval(script))
          return;
        consent[script.meta.id] = grantsOf(script.meta.permissions);
        await write({ [CONSENT_KEY]: consent });
        reload();
      });
    }
    const add = /* @__PURE__ */ __name(async (source, file) => {
      const result = await openEditor({ source, file, original: null, taken: taken() });
      if (result)
        await store([...scripts, result]);
    }, "add");
    const picker = manager.querySelector('input[type="file"]');
    manager.querySelector(".new").onclick = () => add(TEMPLATE, "hello-bot.ttv");
    manager.querySelector(".import").onclick = () => picker.click();
    picker.onchange = async () => {
      const [file] = picker.files;
      if (file)
        await add(await file.text(), file.name);
    };
  }
  __name(renderUserScripts, "renderUserScripts");

  // src/settings/site-access.js
  function siteName(host) {
    return {
      "www.twitchmetrics.net": "TwitchMetrics",
      "twitchstats.net": "TwitchStats",
      "twitchtracker.com": "TwitchTracker",
      "tinyurl.com": "TinyURL",
      "preview.tinyurl.com": "TinyURL",
      "store.steampowered.com": "Steam",
      "store.playstation.com": "PlayStation",
      "store.epicgames.com": "Epic Games",
      "www.microsoft.com": "Microsoft",
      "u3b6gr4ua3-dsn.algolia.net": "Nintendo",
      "www.nintendo.com": "Nintendo"
    }[host] ?? host;
  }
  __name(siteName, "siteName");
  async function renderSiteAccess() {
    var _a3, _b3;
    const container = document.getElementById("site-access-manager");
    const api = globalThis.browser ?? globalThis.chrome;
    const origins = ((_b3 = (_a3 = api == null ? void 0 : api.runtime) == null ? void 0 : _a3.getManifest) == null ? void 0 : _b3.call(_a3).optional_host_permissions) ?? [];
    if (!container || !(api == null ? void 0 : api.permissions) || !origins.length)
      return;
    const draw = /* @__PURE__ */ __name(async () => {
      const granted = await api.permissions.contains({ origins });
      const hosts = origins.map((origin) => origin.replace(/^https:\/\/|\/\*$/g, ""));
      const sites = [...new Set(hosts.map(siteName))].join(", ");
      container.innerHTML = `
            <p class='site-access--status' granted='${granted}' title='${hosts.join(", ")}'>${granted ? "Allowed" : "Not allowed (using the proxy)"}: ${sites}</p>
            <button class='site-access--toggle' type='button'>${granted ? "Remove access" : "Allow access"}</button>
        `;
      container.querySelector(".site-access--toggle").onclick = async () => {
        try {
          if (granted)
            await api.permissions.remove({ origins });
          else
            await api.permissions.request({ origins });
        } catch (error) {
          console.warn("Site Access:", error);
        }
        draw();
      };
    }, "draw");
    await draw();
  }
  __name(renderSiteAccess, "renderSiteAccess");

  // src/lib/debug-recorder.js
  var MESSAGE_AREAS = [
    '[data-a-target="chat-line-message"i]',
    '[class*="chat-line__message"i]',
    '[data-a-target="chat-input"i]',
    '[class*="whisper"i]',
    '[data-test-selector*="notification"i]'
  ].join(",");
  function recordingTitle(meta = {}) {
    return `TTV Tools debug recording${meta.channel ? ` — ${meta.channel}` : ""}`.replace(/[<>&"]/g, (c) => `&#${c.charCodeAt(0)};`);
  }
  __name(recordingTitle, "recordingTitle");
  function buildRecording({ meta = {}, events = [] }, signature = "") {
    const data = JSON.stringify({ meta, events }).replace(/</g, "\\u003c").replace(/\u2028/g, "\\u2028").replace(/\u2029/g, "\\u2029");
    const title = recordingTitle(meta);
    return `<!doctype html>
<html lang=en>
<head>
<meta charset=utf-8>
<meta name=viewport content="width=device-width, initial-scale=1">
<title>${title}</title>
<style>
:root { --bg:#fff; --fg:#1f1f23; --dim:#6b6b76; --line:#e4e4ea; --row:#f6f6f9; --accent:#9147ff;
    --live:#2e9d4d; --rerun:#c28b00; --offline:#7a7a85; --ad:#d6336c; --none:#d0d0d8; }
@media (prefers-color-scheme: dark) { :root { --bg:#0e0e10; --fg:#efeff1; --dim:#9a9aa5; --line:#2a2a2f; --row:#18181b; --none:#3a3a40; } }
* { box-sizing:border-box }
body { margin:0; background:var(--bg); color:var(--fg); font:14px/1.4 system-ui, sans-serif }
header { padding:16px; border-bottom:1px solid var(--line) }
h1 { font-size:18px; margin:0 0 4px }
.meta { color:var(--dim); font-size:12px; display:flex; flex-wrap:wrap; gap:4px 16px }
#strip { display:flex; height:14px; margin:12px 16px 0; border-radius:4px; overflow:hidden; background:var(--none) }
#strip span { height:100% }
.legend { margin:4px 16px 0; font-size:12px; color:var(--dim); display:flex; gap:12px; flex-wrap:wrap }
.legend i { display:inline-block; width:10px; height:10px; border-radius:2px; margin-right:4px; vertical-align:-1px }
#controls { position:sticky; top:0; background:var(--bg); padding:8px 16px; border-bottom:1px solid var(--line); display:flex; flex-wrap:wrap; gap:6px 12px; align-items:center; z-index:1 }
#controls label { font-size:13px; white-space:nowrap }
#search { flex:1 1 200px; min-width:0; padding:4px 8px; border:1px solid var(--line); border-radius:4px; background:var(--row); color:inherit }
table { width:100%; border-collapse:collapse; font-size:13px }
td { padding:3px 8px; border-bottom:1px solid var(--line); vertical-align:top }
tr:nth-child(even) td { background:var(--row) }
td.t { white-space:nowrap; color:var(--dim); font-variant-numeric:tabular-nums }
td.k { white-space:nowrap; font-weight:600 }
td.d { word-break:break-word; font-family:ui-monospace, monospace; font-size:12px }
tr[data-type=error] td.k, tr[data-level=error] td.k { color:var(--ad) }
tr[data-level=warn] td.k { color:var(--rerun) }
tr[data-type=load] td, tr[data-type=unload] td, tr[data-type=respawn] td { font-weight:600 }
.masked { filter:blur(3px); user-select:none }
.wrap { overflow-x:auto }
</style>
</head>
<body>
<header>
<h1>${title}</h1>
<div class=meta id=meta></div>
<div class=meta>To check that this is a real TTV Tools recording: TTV Tools Settings → Troubleshooting → Debug Recording → Check a file.</div>
</header>
<div id=strip title="Video status over time"></div>
<div class=legend><span><i style="background:var(--live)"></i>live</span><span><i style="background:var(--rerun)"></i>rerun</span><span><i style="background:var(--offline)"></i>offline</span><span><i style="background:var(--ad)"></i>ad</span><span><i style="background:var(--none)"></i>no video</span></div>
<div id=controls><input id=search type=search placeholder="Filter (text)"><span id=types></span></div>
<div class=wrap><table><tbody id=rows></tbody></table></div>
<script type="application/json" id=data>${data}<\/script>
<script type="application/json" id=signature>${String(signature).replace(/</g, "")}<\/script>
<script>
(() => {
    const { meta, events } = JSON.parse(document.getElementById('data').textContent);
    const first = events[0]?.t ?? meta.started ?? 0, last = events.at(-1)?.t ?? first;
    const pad = (n, s = 2) => String(n).padStart(s, '0');
    const offset = t => { const ms = Math.max(0, t - first); return pad(Math.floor(ms / 60000)) + ':' + pad(Math.floor(ms / 1000) % 60) + '.' + pad(ms % 1000, 3); };
    const clock = t => new Date(t).toLocaleTimeString([], { hour12: false }) + '.' + pad(new Date(t).getMilliseconds(), 3);
    const esc = s => String(s ?? '').replace(/[&<>"]/g, c => '&#' + c.charCodeAt(0) + ';');
    const masked = s => esc(s).replace(/█+/g, m => '<span class=masked>' + m + '</span>');

    const summary = e => {
        switch(e.type) {
            case 'click': return (e.trusted ? 'user' : 'script') + ' click on ' + esc(e.path) + (e.label ? ' — "' + masked(e.label) + '"' : '') + ' @' + e.x + ',' + e.y;
            case 'nav': return esc(e.from) + ' → ' + esc(e.to);
            case 'load': return 'page ' + esc(e.how) + ': ' + esc(e.path) + (e.reason ? ' (reason: ' + esc(e.reason) + ')' : '') + (e.reports?.length ? ' reports: ' + esc(e.reports.join(', ')) : '');
            case 'unload': return 'leaving ' + esc(e.path);
            case 'respawn': return 'the tab was replaced by a new one (respawned by TTV' + (e.forced ? ', forced' : '') + ')';
            case 'video': return esc(e.status) + (e.paused ? ', paused' : '') + ', ready ' + e.ready + ', at ' + e.time + 's, buffered to ' + e.buffered + 's' + (e.height ? ', ' + e.height + 'p' : '') + (e.muted ? ', muted' : ', volume ' + e.volume);
            case 'stall': return 'video stuck at ' + e.time + 's for ' + e.seconds + 's (' + esc(e.status) + ')';
            case 'job': return esc(e.name) + ' ' + esc(e.state);
            case 'log': return masked(e.text);
            case 'error': return esc(e.message) + (e.source ? ' (' + esc(e.source) + ')' : '');
            case 'upnext': return e.queue.length ? e.queue.map(esc).join(' → ') : '(empty)';
            case 'setting': return esc(e.key) + ' = ' + masked(JSON.stringify(e.value));
            case 'lag': return 'page busy for ' + e.ms + ' ms';
            case 'memory': return e.mb + ' MB in use';
            case 'visibility': return esc(e.state);
            case 'chat': return 'chat ' + esc(e.state);
            default: return masked(JSON.stringify(e));
        }
    };

    const metaParts = [
        ['TTV Tools', meta.version], ['Browser', meta.browser], ['Channel', meta.channel],
        ['From', meta.started && new Date(meta.started).toLocaleString()], ['Saved', meta.saved && new Date(meta.saved).toLocaleString()],
        ['Events', events.length],
    ].filter(([, v]) => v != null && v !== '');
    document.getElementById('meta').innerHTML = metaParts.map(([k, v]) => '<span>' + k + ': <b>' + esc(v) + '</b></span>').join('');

    // The video's status over time
    const strip = document.getElementById('strip'), span = Math.max(1, last - first);
    let status = 'none', since = first;
    const segment = (from, to, s) => strip.insertAdjacentHTML('beforeend', '<span style="width:' + ((to - from) / span * 100) + '%;background:var(--' + s + ')" title="' + s + ' ' + offset(from) + '–' + offset(to) + '"></span>');
    for(const e of events)
        if(e.type == 'video' && e.status != status) { segment(since, e.t, status); status = e.status; since = e.t; }
        else if(e.type == 'load' || e.type == 'unload' || e.type == 'respawn') { segment(since, e.t, status); status = 'none'; since = e.t; }
    segment(since, last, status);

    // Filters
    const counts = {};
    for(const e of events) counts[e.type] = (counts[e.type] ?? 0) + 1;
    const shown = new Set(Object.keys(counts));
    document.getElementById('types').innerHTML = Object.entries(counts).sort().map(([type, n]) => '<label><input type=checkbox checked value="' + esc(type) + '"> ' + esc(type) + ' (' + n + ')</label>').join(' ');

    const rows = document.getElementById('rows');
    rows.innerHTML = events.map((e, i) => '<tr data-i=' + i + ' data-type="' + esc(e.type) + '"' + (e.level ? ' data-level="' + esc(e.level) + '"' : '') + '><td class=t title="+' + offset(e.t) + ' from the start">' + clock(e.t) + '</td><td class=k>' + esc(e.level ?? e.type) + '</td><td class=d>' + summary(e) + '</td></tr>').join('');

    const search = document.getElementById('search');
    const filter = () => {
        const term = search.value.trim().toLowerCase();
        for(const row of rows.children)
            row.hidden = !shown.has(row.dataset.type) || (term && !row.textContent.toLowerCase().includes(term));
    };
    document.getElementById('types').addEventListener('change', ({ target }) => { target.checked ? shown.add(target.value) : shown.delete(target.value); filter(); });
    search.addEventListener('input', filter);
})();
<\/script>
</body>
</html>
`;
  }
  __name(buildRecording, "buildRecording");
  var SIGNATURE_VERSION = 1;
  var KNOWN_PAGES = [
    // Before signing (v5 5.35.5.51 – 5.35.6.14; v6 6.1 test builds)
    "392751c21bf2c68d3f947369a997e8e5185c6594cd562f279bc09d7ea5ccb8ca",
    "4456a60163520bb39e4c49b6dede067c011795ac9aeadb7fda22ca0072f2e0ac",
    "74879b200b360435cc0c6ce3eee1873600358568ac4a6b87abc182f3237cf0cc"
  ];
  var DATA_OPEN = '<script type="application/json" id=data>';
  var SIGNATURE_OPEN = '<script type="application/json" id=signature>';
  var SCRIPT_CLOSE = "<\/script>";
  async function sha256(text = "") {
    const digest = await crypto.subtle.digest("SHA-256", new TextEncoder().encode(text));
    return [...new Uint8Array(digest)].map((byte) => byte.toString(16).padStart(2, "0")).join("");
  }
  __name(sha256, "sha256");
  function recordingPage(html = "") {
    const cut = /* @__PURE__ */ __name((text, open) => {
      const start = text.indexOf(open);
      if (start < 0)
        return null;
      const end = text.indexOf(SCRIPT_CLOSE, start + open.length);
      if (end < 0)
        return null;
      return { inner: text.slice(start + open.length, end), rest: text.slice(0, start + open.length) + text.slice(end) };
    }, "cut");
    const data = cut(String(html), DATA_OPEN);
    if (!data)
      return null;
    const signature = cut(data.rest, SIGNATURE_OPEN);
    if (/</.test(data.inner) || /</.test((signature == null ? void 0 : signature.inner) ?? ""))
      return null;
    let meta;
    try {
      ({ meta } = JSON.parse(data.inner));
    } catch {
      return null;
    }
    const title = recordingTitle(meta ?? {}), page = ((signature == null ? void 0 : signature.rest) ?? data.rest).replace(`<title>${title}</title>`, "<title></title>").replace(`<h1>${title}</h1>`, "<h1></h1>").split("\n").map((line) => line.trim()).filter((line) => line.length).join("\n");
    return { data: data.inner, signature: (signature == null ? void 0 : signature.inner) ?? "", page, meta: meta ?? {} };
  }
  __name(recordingPage, "recordingPage");
  async function signedText({ data, page }) {
    return `ttv-recording/${SIGNATURE_VERSION}
${await sha256(page)}
${await sha256(data)}`;
  }
  __name(signedText, "signedText");
  async function keyId(key = {}) {
    const hash = (await sha256(`${key.x}.${key.y}`)).slice(0, 8).toUpperCase();
    return `${hash.slice(0, 4)}-${hash.slice(4)}`;
  }
  __name(keyId, "keyId");
  async function checkRecording(html = "") {
    const parts = recordingPage(html), result = { page: false, signed: false, valid: false, key: null, meta: (parts == null ? void 0 : parts.meta) ?? null, reason: null };
    if (!parts)
      return { ...result, reason: "not a TTV Tools recording" };
    const known = /* @__PURE__ */ new Set([...KNOWN_PAGES, await sha256(recordingPage(buildRecording({ meta: {}, events: [] })).page)]);
    result.page = known.has(await sha256(parts.page));
    if (!result.page)
      return { ...result, reason: "its page was changed, or made by a newer TTV Tools" };
    if (!parts.signature.trim())
      return { ...result, reason: "not signed (saved before signing was added, or signing failed)" };
    try {
      const { v, alg, key, sig } = JSON.parse(parts.signature);
      result.signed = true;
      if (v != SIGNATURE_VERSION || alg != "ES256" || !(key == null ? void 0 : key.x) || !(key == null ? void 0 : key.y) || typeof sig != "string")
        return { ...result, reason: "unknown signature format" };
      result.key = await keyId(key);
      const publicKey = await crypto.subtle.importKey("jwk", { kty: "EC", crv: "P-256", x: key.x, y: key.y, ext: true }, { name: "ECDSA", namedCurve: "P-256" }, false, ["verify"]), bytes = Uint8Array.from(atob(sig), (char) => char.charCodeAt(0));
      result.valid = await crypto.subtle.verify({ name: "ECDSA", hash: "SHA-256" }, publicKey, bytes, new TextEncoder().encode(await signedText(parts)));
      if (!result.valid)
        result.reason = "the log was changed after it was saved";
    } catch (error) {
      result.reason = `the signature can't be read (${(error == null ? void 0 : error.message) ?? error})`;
    }
    return result;
  }
  __name(checkRecording, "checkRecording");

  // src/settings/index.js
  document.getElementById("search-container").insertAdjacentHTML("beforebegin", renderLayout(layout_default));
  document.addEventListener("click", (event) => {
    var _a3, _b3;
    const link = event.target.closest('a[href^="#group-"]');
    if (!link)
      return;
    event.preventDefault();
    event.stopImmediatePropagation();
    (_b3 = (_a3 = document.querySelector(link.getAttribute("href"))) == null ? void 0 : _a3.nextElementSibling) == null ? void 0 : _b3.scrollIntoView({ behavior: "smooth", block: "start" });
  }, { capture: true });
  var _a2, _b2, _c;
  {
    const runtime = (_a2 = globalThis.browser ?? globalThis.chrome) == null ? void 0 : _a2.runtime;
    let ownKey = null;
    try {
      (_b2 = runtime == null ? void 0 : runtime.sendMessage) == null ? void 0 : _b2.call(runtime, { action: "DEBUG_RECORDING_KEY" }, async (answer) => {
        void runtime.lastError;
        if (!(answer == null ? void 0 : answer.key))
          return;
        ownKey = await keyId(answer.key);
        const shown = document.getElementById("debug-recording--key");
        if (shown)
          shown.textContent = ownKey;
      });
    } catch {
    }
    (_c = document.getElementById("debug-recording--check-input")) == null ? void 0 : _c.addEventListener("change", async (event) => {
      const input = event.currentTarget, [file] = input.files ?? [], shown = document.getElementById("debug-recording--check-result");
      if (!file || !shown)
        return;
      shown.textContent = `Checking "${file.name}"...`;
      const result = await checkRecording(await file.text()), { version = "?", browser = "?", channel = "" } = result.meta ?? {}, about = `TTV Tools ${version}, ${browser}${channel ? `, ${channel}` : ""}`, whose = result.key && result.key == ownKey ? " (this browser)" : "";
      shown.textContent = result.page && result.valid && `✔ "${file.name}" is a real TTV Tools recording (${about}), signed with key ${result.key}${whose}. Its log hasn't been changed. It's safe to open.` || result.page && result.signed && `✖ "${file.name}" runs only TTV Tools' own code (safe to open), but ${result.reason}.` || result.page && `⚠ "${file.name}" runs only TTV Tools' own code (${about}), so it's safe to open, but it's ${result.reason}: its log can't be confirmed.` || `✖ "${file.name}": ${result.reason}. Don't open it.`;
      input.value = "";
    });
  }
  window.SETTINGS_LAYOUT = layout_default;
  window.SETTINGS_IDS = settingIds(layout_default);
  window.SETTINGS_DEFAULTS = settingDefaults(layout_default);
  window.SETTINGS_EXTRA = renderUserScripts({ ids: window.SETTINGS_IDS, defaults: window.SETTINGS_DEFAULTS }).catch((error) => console.error("User Scripts:", error));
  renderSiteAccess().catch((error) => console.error("Site Access:", error));
})();
