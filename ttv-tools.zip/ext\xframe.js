/*** https://github.com/niutech/x-frame-bypass
 *     __   __     ______                               ____
 *     \ \ / /    |  ____|                             |  _ \
 *      \ V /_____| |__ _ __ __ _ _ __ ___   ___ ______| |_) |_   _ _ __   __ _ ___ ___
 *       > <______|  __| '__/ _` | '_ ` _ \ / _ \______|  _ <| | | | '_ \ / _` / __/ __|
 *      / . \     | |  | | | (_| | | | | | |  __/      | |_) | |_| | |_) | (_| \__ \__ \
 *     /_/ \_\    |_|  |_|  \__,_|_| |_| |_|\___|      |____/ \__, | .__/ \__,_|___/___/
 *                                                             __/ | |
 *                                                            |___/|_|
 */

class XFrame {
    static frames = new Map;

	constructor(url, attributes = {}) {
		let iframe = this.iframe = document.createElement('iframe');
        let xframe = this.xframe = this;

        let proxy = new Proxy(iframe, {
            get(target, property, proxy) {
                return target[property];
            },

            set(target, property, value, proxy) {
                switch(property) {
                    case 'src': {
                        target.xframe.load(value);

                        return value;
                    } break;
                }

                return target[property] = value;
            },
        });

        Object.assign(proxy, this);

        attributes.sandbox ??= 'allow-forms allow-modals allow-pointer-lock allow-popups allow-popups-to-escape-sandbox allow-presentation allow-same-origin allow-scripts allow-top-navigation-by-user-activation';
        XFrame.frames.set(attributes.id = (new UUID).value, iframe);

        for(let key in attributes)
            iframe.setAttribute(key, iframe[key] = attributes[key]);
        proxy.src = url;

        return this;
	}

	load(url, options) {
		if(!url?.startsWith('http'))
			throw new Error(`X-Frame attribute "src" ("${ url }") does not start with "http(s)://"`);

		this.iframe.srcdoc = `
		<html>
		<head>
			<style>
			.loader {
				position: absolute;
				top: calc(50% - 25px);
				left: calc(50% - 25px);
				width: 50px;
				height: 50px;
				background-color: #333;
				border-radius: 50%;
				animation: loader 1s infinite ease-in-out;
			}
			@keyframes loader {
				0% {
					transform: scale(0);
				}
				100% {
					transform: scale(1);
					opacity: 0;
				}
			}
			</style>
		</head>
		<body>
			<div class="loader"></div>
		</body>
		</html>`;

		this.fetchProxy(url, options, 0).then(response => response.text()).then(data => {
			if(data)
				this.iframe.srcdoc = data.replace(/<head([^>]*)>/i, `
				<head$1>
					<base href="${ url }">
					<script>
					// X-Frame navigation event handlers
					document.addEventListener('click', e => {
						if(frameElement && document.activeElement && document.activeElement.href) {
							e.preventDefault();
							frameElement.load(document.activeElement.href);
						}
					});

					document.addEventListener('submit', e => {
						if(frameElement && document.activeElement && document.activeElement.form && document.activeElement.form.action) {
							e.preventDefault();
							if(document.activeElement.form.method === 'post')
								frameElement.load(document.activeElement.form.action, { method: 'post', body: new FormData(document.activeElement.form) });
							else
								frameElement.load(document.activeElement.form.action + '?' + new URLSearchParams(new FormData(document.activeElement.form)));
						}
					});
					</script>`);
		}).catch(console.error);
	}

	fetchProxy(url, options = {}, proxy = 0) {
		let proxies = options.proxies || [
			'https://api.codetabs.com/v1/proxy/?quest=',
			'https://api.allorigins.win/raw?url=',
			'https://cors-anywhere.herokuapp.com/',
		];

		return fetch(proxies[proxy] + url, options).then(response => {
			if(!response.ok)
				throw new Error(`${ response.status } ${ response.statusText }`);
			return response;
		}).catch(error => {
			if(proxy === proxies.length - 1)
				throw error;
			return this.fetchProxy(url, options, proxy + 1);
		});
	}
}

HTMLIFrameElement.prototype.load = XFrame.prototype.load;
HTMLIFrameElement.prototype.fetchProxy = XFrame.prototype.fetchProxy;
