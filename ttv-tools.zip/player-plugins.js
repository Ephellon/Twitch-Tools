globalThis.SETTINGS_DEFAULTS ??= Object.freeze({"auto_accept_mature":false,"auto_claim_bonuses":true,"claim_drops":true,"claim_drops__interval":"10","claim_loot":false,"away_mode":true,"away_mode__hide_chat":false,"away_mode__volume_control":false,"away_mode__volume":0.25,"first_in_line_none":true,"first_in_line_now":false,"first_in_line":false,"first_in_line_time_minutes":"15","first_in_line_plus":false,"first_in_line_plus_time_minutes":"15","first_in_line_all":false,"first_in_line_all_time_minutes":"15","up_next__one_instance":false,"up_next__keep_status":false,"up_next__rushing":"keep","live_reminders":true,"keep_live_reminders":false,"auto_follow_none":true,"auto_follow_raids":false,"auto_follow_time":false,"auto_follow_time_minutes":"15","auto_follow_all":false,"kill_extensions":false,"next_channel_preference":"random","parse_commands":false,"parse_commands__create_links":true,"prevent_raiding":"none","greedy_raiding":false,"claim_prime":false,"claim_prime__max_claims":"3","stay_live":true,"stay_live__ignore_channel_reruns":false,"time_zones":false,"view_mode":"null","bttv_emotes":false,"auto_load_bttv_emotes":false,"bttv_emotes_channel":false,"bttv_emotes_location":"emotes/shared/trending","bttv_emotes_extras":"","bttv_emotes_maximum":"150","filter_messages":true,"filter_messages__bullets_raid":false,"filter_messages__bullets_coin":false,"filter_messages__bullets_subs":false,"filter_messages__bullets_note":false,"filter_messages__bullets_paid":false,"highlight_mentions":true,"highlight_phrases":false,"link_maker__chat":false,"auto_chat__mentions":"null","auto_chat__wait_time":"5","native_twitch_reply":false,"mention_audio":false,"phrase_audio":false,"whisper_audio":false,"whisper_audio_sound":"goes-without-saying-608","prevent_spam":true,"prevent_spam_look_back":"15","prevent_spam_minimum_length":"5","prevent_spam_ignore_under":"5","recover_chat":false,"recover_messages":false,"highlight_mentions_popup":true,"convert_bits":true,"channelpoints_receipt_display":"null","rewards_calculator":false,"accent_color":"twitch-purple/12","block_banners":false,"context_menu_override":false,"away_mode_placement":"null","hide_blank_ads":false,"points_receipt_placement":"null","point_watcher_placement":"null","stream_preview":false,"stream_preview_position":"3","stream_preview_scale":"1","stream_preview_sound":false,"watch_time_placement":"null","sync-token":"TTV-TOOL","store_integration":true,"store_integration__steam":true,"store_integration__playstation":true,"store_integration__xbox":true,"store_integration__nintendo":true,"store_integration__epic":true,"video_clips__file_type":"x-matroska","video_clips__quality":"auto","video_clips__length":"60","video_clips__dvr":false,"video_clips__trophy":false,"video_clips__trophy_length":"60","record_foreign_rewards":false,"keep_popout":false,"recover_ads":false,"recover_frames":true,"recover_frames__allow_embed":false,"recover_pages":false,"recover_stream":false,"recover_video":true,"display_in_console":false,"display_in_console__log":true,"display_in_console__warn":true,"display_in_console__error":true,"display_in_console__remark":true,"display_in_console__notice":true,"display_in_console__ignore":true,"show_stats":false,"experimental_mode":false,"extra_keyboard_shortcuts":true,"low_data_mode":false,"fine_details":false,"auto_tab_reloads":true,"auto_focus":false,"auto_focus_detection_threshold":"0","auto_focus_poll_interval":"3","auto_focus_poll_image_type":"webp","convert_emotes":false,"soft_unban":false,"soft_unban_fade_old_messages":false,"soft_unban_keep_bots":false,"soft_unban_prevent_clipping":false,"user_language_preference":"en"});
(() => {
  var __defProp = Object.defineProperty;
  var __typeError = (msg) => {
    throw TypeError(msg);
  };
  var __defNormalProp = (obj, key, value) => key in obj ? __defProp(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
  var __name = (target, value) => __defProp(target, "name", { value, configurable: true });
  var __publicField = (obj, key, value) => __defNormalProp(obj, typeof key !== "symbol" ? key + "" : key, value);
  var __accessCheck = (obj, member, msg) => member.has(obj) || __typeError("Cannot " + msg);
  var __privateGet = (obj, member, getter) => (__accessCheck(obj, member, "read from private field"), getter ? getter.call(obj) : member.get(obj));
  var __privateAdd = (obj, member, value) => member.has(obj) ? __typeError("Cannot add the same private member more than once") : member instanceof WeakSet ? member.add(obj) : member.set(obj, value);
  var __privateSet = (obj, member, value, setter) => (__accessCheck(obj, member, "write to private field"), setter ? setter.call(obj, value) : member.set(obj, value), value);
  var __privateMethod = (obj, member, method) => (__accessCheck(obj, member, "access private method"), method);
  var __privateWrapper = (obj, member, setter, getter) => ({
    set _(value) {
      __privateSet(obj, member, value, setter);
    },
    get _() {
      return __privateGet(obj, member, getter);
    }
  });

  // src/lib/plugins.js
  var PLUGINS = globalThis.__TTV_PLUGINS__ ??= /* @__PURE__ */ new Map();
  function plugin(definition) {
    const { id } = definition;
    if (PLUGINS.has(id))
      throw new Error(`Plugin "${id}" is already registered`);
    const job = definition.job ?? id;
    PLUGINS.set(id, {
      frames: ["main"],
      /**
       * Determines if the feature is enabled based on the provided settings.
       * @param {Object} settings - The current configuration settings
       * @returns {boolean} True if the feature is enabled
       */
      enabled: /* @__PURE__ */ __name((settings) => parseBool(settings[job]), "enabled"),
      ...definition,
      job
    });
  }
  __name(plugin, "plugin");
  async function start(frame, context = {}) {
    for (const [id, feature] of PLUGINS)
      if (feature.frames.includes(frame) && !feature.started)
        await run(id, context);
  }
  __name(start, "start");
  async function run(id, context = {}) {
    var _a, _b;
    const feature = PLUGINS.get(id);
    if (!feature)
      throw new Error(`No plugin "${id}"`);
    feature.started = true;
    if (feature.install)
      return await feature.install(context);
    const { job } = feature;
    await ((_a = feature.init) == null ? void 0 : _a.call(feature, context));
    Handlers[job] = (...args) => feature.handler(context, ...args);
    if ("timer" in feature)
      Timers[job] = feature.timer;
    if (feature.unhandler)
      Unhandlers[job] = (...args) => feature.unhandler(context, ...args);
    if (await feature.enabled(Settings, context)) {
      await ((_b = feature.setup) == null ? void 0 : _b.call(feature, context));
      if (feature.register !== false)
        RegisterJob(job);
    }
  }
  __name(run, "run");

  // src/lib/recording.js
  var DIRECTORY = "tt-recordings";
  var FLUSH_MS = 5e3;
  var FLUSH_BYTES = 8 * 1024 * 1024;
  var ACTIVE = /* @__PURE__ */ new Set(["starting", "recording", "paused"]);
  var FALLBACK_TYPES = ["video/webm;codecs=vp9,opus", "video/webm;codecs=vp8,opus", "video/webm", "video/mp4"];
  var registry = /* @__PURE__ */ new WeakMap();
  var everything = /* @__PURE__ */ new Set();
  var later = /* @__PURE__ */ __name((ms, fn) => setTimeout(fn, ms), "later");
  var newID = /* @__PURE__ */ __name(() => {
    var _a, _b;
    return ((_b = (_a = globalThis.crypto) == null ? void 0 : _a.randomUUID) == null ? void 0 : _b.call(_a)) ?? `${Date.now().toString(36)}-${Math.random().toString(36).slice(2)}`;
  }, "newID");
  var _MemoryStore = class _MemoryStore {
    kind = "memory";
    chunks = [];
    size = 0;
    async append(blob) {
      this.chunks.push(blob);
      this.size += blob.size;
    }
    async flush() {
    }
    async blob(type) {
      return new Blob(this.chunks, { type });
    }
    async discard() {
      this.chunks.length = this.size = 0;
    }
    async describe() {
    }
  };
  __name(_MemoryStore, "MemoryStore");
  var MemoryStore = _MemoryStore;
  var _dir, _root, _id, _pending, _pendingSize, _lastFlush, _segments, _queue, _failed;
  var _DiskStore = class _DiskStore {
    constructor() {
      __publicField(this, "kind", "disk");
      __publicField(this, "size", 0);
      __privateAdd(this, _dir);
      __privateAdd(this, _root);
      __privateAdd(this, _id);
      __privateAdd(this, _pending, []);
      __privateAdd(this, _pendingSize, 0);
      __privateAdd(this, _lastFlush, Date.now());
      __privateAdd(this, _segments, 0);
      __privateAdd(this, _queue, Promise.resolve());
      __privateAdd(this, _failed, false);
    }
    /**
     * @param {string} id - The recording's ID (its folder name)
     * @returns {Promise<DiskStore>}
     */
    static async open(id) {
      const store = new _DiskStore();
      const root = await (await navigator.storage.getDirectory()).getDirectoryHandle(DIRECTORY, { create: true });
      __privateSet(store, _root, root);
      __privateSet(store, _id, id);
      __privateSet(store, _dir, await root.getDirectoryHandle(id, { create: true }));
      return store;
    }
    async append(blob) {
      __privateGet(this, _pending).push(blob);
      __privateSet(this, _pendingSize, __privateGet(this, _pendingSize) + blob.size);
      this.size += blob.size;
      if (__privateGet(this, _pendingSize) >= FLUSH_BYTES || Date.now() - __privateGet(this, _lastFlush) >= FLUSH_MS)
        return this.flush();
    }
    flush() {
      return __privateSet(this, _queue, __privateGet(this, _queue).then(async () => {
        if (__privateGet(this, _failed) || !__privateGet(this, _pending).length)
          return;
        const parts = __privateGet(this, _pending).splice(0), size = __privateGet(this, _pendingSize);
        __privateSet(this, _pendingSize, 0);
        __privateSet(this, _lastFlush, Date.now());
        try {
          await write(__privateGet(this, _dir), `${String(__privateGet(this, _segments)).padStart(6, "0")}.part`, new Blob(parts));
          ++__privateWrapper(this, _segments)._;
        } catch (error) {
          __privateSet(this, _failed, true);
          __privateGet(this, _pending).unshift(...parts);
          __privateSet(this, _pendingSize, __privateGet(this, _pendingSize) + size);
          console.warn("[recording] Disk write failed; keeping the rest in memory", error);
        }
      }));
    }
    async blob(type) {
      await this.flush();
      return new Blob([...await segments(__privateGet(this, _dir)), ...__privateGet(this, _pending)], { type });
    }
    async describe(meta) {
      await __privateGet(this, _queue);
      await write(__privateGet(this, _dir), "meta.json", JSON.stringify(meta)).catch(() => {
      });
    }
    async discard() {
      await __privateGet(this, _queue).catch(() => {
      });
      __privateGet(this, _pending).length = __privateSet(this, _pendingSize, this.size = 0);
      await __privateGet(this, _root).removeEntry(__privateGet(this, _id), { recursive: true }).catch(() => {
      });
    }
  };
  _dir = new WeakMap();
  _root = new WeakMap();
  _id = new WeakMap();
  _pending = new WeakMap();
  _pendingSize = new WeakMap();
  _lastFlush = new WeakMap();
  _segments = new WeakMap();
  _queue = new WeakMap();
  _failed = new WeakMap();
  __name(_DiskStore, "DiskStore");
  var DiskStore = _DiskStore;
  async function write(dir, name, data) {
    const file = await dir.getFileHandle(name, { create: true });
    const stream = await file.createWritable();
    await stream.write(data);
    await stream.close();
  }
  __name(write, "write");
  async function segments(dir) {
    const files = [];
    for await (const [name, handle] of dir.entries())
      if (handle.kind == "file" && name.endsWith(".part"))
        files.push([name, await handle.getFile()]);
    return files.sort(([a], [b]) => a.localeCompare(b)).map(([, file]) => file);
  }
  __name(segments, "segments");
  function ticker(ms, tick) {
    try {
      const url = URL.createObjectURL(new Blob([`setInterval(() => postMessage(0), ${ms | 0})`], { type: "text/javascript" }));
      const worker = new Worker(url);
      let fallback = null;
      worker.onmessage = tick;
      worker.onerror = () => {
        worker.terminate();
        fallback ??= setInterval(tick, ms);
      };
      return () => {
        worker.terminate();
        clearInterval(fallback);
        URL.revokeObjectURL(url);
      };
    } catch (error) {
      const id = setInterval(tick, ms);
      return () => clearInterval(id);
    }
  }
  __name(ticker, "ticker");
  var captures = /* @__PURE__ */ new WeakMap();
  function captureAudio(element, event = null) {
    let entry = captures.get(element);
    if (!entry || event && entry.event !== event || !entry.stream.getAudioTracks().some((track) => track.readyState == "live"))
      captures.set(element, entry = { stream: element.captureStream(), event });
    return entry.stream.getAudioTracks().map((track) => track.clone());
  }
  __name(captureAudio, "captureAudio");
  var _source, _context, _stop, _audio, _input, _inputTracks, _output, _listen, _FrameProxy_instances, draw_fn, audioTracks_fn, route_fn, connectAudio_fn;
  var _FrameProxy = class _FrameProxy {
    constructor(source, { fps = 30, canvas } = {}) {
      __privateAdd(this, _FrameProxy_instances);
      __publicField(this, "canvas");
      __publicField(this, "stream");
      /** Resolves once the audio route is chosen (the recorder waits for it, so its track set never changes) */
      __publicField(this, "ready");
      __privateAdd(this, _source);
      __privateAdd(this, _context);
      __privateAdd(this, _stop);
      __privateAdd(this, _audio, null);
      __privateAdd(this, _input, null);
      __privateAdd(this, _inputTracks, []);
      __privateAdd(this, _output, null);
      __privateAdd(this, _listen);
      this.canvas = canvas ?? document.createElement("canvas");
      __privateSet(this, _context, this.canvas.getContext("2d"));
      this.stream = this.canvas.captureStream(fps);
      __privateSet(this, _listen, (event) => __privateMethod(this, _FrameProxy_instances, connectAudio_fn).call(this, event));
      __privateSet(this, _source, source);
      __privateGet(this, _source).addEventListener("loadedmetadata", __privateGet(this, _listen));
      __privateMethod(this, _FrameProxy_instances, draw_fn).call(this);
      __privateSet(this, _stop, ticker(1e3 / fps, () => __privateMethod(this, _FrameProxy_instances, draw_fn).call(this)));
      this.ready = __privateMethod(this, _FrameProxy_instances, route_fn).call(this);
    }
    get source() {
      return __privateGet(this, _source);
    }
    retarget(source) {
      var _a;
      (_a = __privateGet(this, _source)) == null ? void 0 : _a.removeEventListener("loadedmetadata", __privateGet(this, _listen));
      __privateSet(this, _source, source);
      source.addEventListener("loadedmetadata", __privateGet(this, _listen));
      __privateMethod(this, _FrameProxy_instances, draw_fn).call(this);
      __privateMethod(this, _FrameProxy_instances, connectAudio_fn).call(this);
    }
    stop() {
      var _a, _b, _c, _d;
      (_a = __privateGet(this, _stop)) == null ? void 0 : _a.call(this);
      (_b = __privateGet(this, _source)) == null ? void 0 : _b.removeEventListener("loadedmetadata", __privateGet(this, _listen));
      (_c = __privateGet(this, _input)) == null ? void 0 : _c.disconnect();
      (_d = __privateGet(this, _audio)) == null ? void 0 : _d.close().catch(() => {
      });
      for (const track of [...this.stream.getTracks(), ...__privateGet(this, _inputTracks)])
        track.stop();
    }
  };
  _source = new WeakMap();
  _context = new WeakMap();
  _stop = new WeakMap();
  _audio = new WeakMap();
  _input = new WeakMap();
  _inputTracks = new WeakMap();
  _output = new WeakMap();
  _listen = new WeakMap();
  _FrameProxy_instances = new WeakSet();
  draw_fn = /* @__PURE__ */ __name(function() {
    const video = __privateGet(this, _source), canvas = this.canvas;
    if (!video || video.readyState < 2)
      return;
    const width = video.videoWidth || video.clientWidth, height = video.videoHeight || video.clientHeight;
    if (width && height && (canvas.width != width || canvas.height != height)) {
      canvas.width = width;
      canvas.height = height;
    }
    try {
      __privateGet(this, _context).drawImage(video, 0, 0, canvas.width, canvas.height);
    } catch (error) {
    }
  }, "#draw");
  audioTracks_fn = /* @__PURE__ */ __name(function(event = null) {
    try {
      return captureAudio(__privateGet(this, _source), event);
    } catch (error) {
      return [];
    }
  }, "#audioTracks");
  route_fn = /* @__PURE__ */ __name(async function() {
    try {
      const context = new AudioContext();
      if (context.state != "running")
        await Promise.race([context.resume(), new Promise((resolve) => later(500, resolve))]);
      if (context.state != "running") {
        context.close().catch(() => {
        });
        throw new Error("AudioContext not allowed to start");
      }
      __privateSet(this, _audio, context);
      __privateSet(this, _output, context.createMediaStreamDestination());
      for (const track of __privateGet(this, _output).stream.getAudioTracks())
        this.stream.addTrack(track);
    } catch (error) {
      for (const track of __privateMethod(this, _FrameProxy_instances, audioTracks_fn).call(this))
        this.stream.addTrack(track);
      return;
    }
    __privateMethod(this, _FrameProxy_instances, connectAudio_fn).call(this);
  }, "#route");
  connectAudio_fn = /* @__PURE__ */ __name(function(event = null) {
    var _a;
    if (!__privateGet(this, _audio))
      return;
    const tracks = __privateMethod(this, _FrameProxy_instances, audioTracks_fn).call(this, event);
    if (!tracks.length)
      return;
    (_a = __privateGet(this, _input)) == null ? void 0 : _a.disconnect();
    for (const track of __privateGet(this, _inputTracks))
      track.stop();
    __privateSet(this, _inputTracks, tracks);
    __privateSet(this, _input, __privateGet(this, _audio).createMediaStreamSource(new MediaStream(tracks)));
    __privateGet(this, _input).connect(__privateGet(this, _output));
  }, "#connectAudio");
  __name(_FrameProxy, "FrameProxy");
  var FrameProxy = _FrameProxy;
  async function download(blob, as) {
    const link = document.createElement("a");
    link.href = URL.createObjectURL(blob);
    link.download = `${as}.${await Recording2.guessMIMEType(blob)}`;
    link.dataset.saveName = as;
    link.textContent = as;
    link.click();
    document.head.append(link.cloneNode(true));
    return link;
  }
  __name(download, "download");
  function updateStatus() {
    var _a, _b, _c;
    let active = false;
    for (const recording of everything)
      if (active = !recording.hidden && ["recording", "paused"].includes(recording.state))
        break;
    (_c = (_b = (_a = globalThis.document) == null ? void 0 : _a.querySelector) == null ? void 0 : _b.call(_a, "[data-a-player-state]")) == null ? void 0 : _c.setAttribute("data-recording-status", active);
  }
  __name(updateStatus, "updateStatus");
  function supportedType(mimeType) {
    const supported = /* @__PURE__ */ __name((type) => {
      var _a, _b;
      return ((_b = (_a = globalThis.MediaRecorder) == null ? void 0 : _a.isTypeSupported) == null ? void 0 : _b.call(_a, type)) ?? true;
    }, "supported");
    return [mimeType, ...FALLBACK_TYPES].find((type) => type && supported(type)) ?? "";
  }
  __name(supportedType, "supportedType");
  var _recorder, _store, _storeReady, _proxy, _resolve, _reject, _timer, _recorded, _since, _writes, _link, _linkSize, _saving, _count, _Recording_instances, openStore_fn, _Recording_static, lock_fn, meta_fn, setState_fn, finish_fn, fail_fn, account_fn;
  var _Recording = class _Recording extends EventTarget {
    /**
     * Starts recording.
     * @param {HTMLMediaElement|HTMLCanvasElement} source - The element to record (and to file the recording under)
     * @param {Object} [options]
     * @param {string} [options.name='DEFAULT_RECORDING'] - Key for `Recording.of(source).get(name)`
     * @param {string} [options.as] - File name used by `save()` (no extension)
     * @param {number} [options.maxTime=Infinity] - Stops by itself after this many ms
     * @param {string} [options.mimeType='video/webm'] - Falls back to a supported type
     * @param {boolean} [options.hidden=false] - Don't show the player's recording indicator
     * @param {number} [options.chunksPerSecond=1]
     * @param {MediaStream} [options.stream] - Record this stream instead of `source.captureStream()`
     * @param {FrameProxy} [options.proxy] - Internal: set by `Recording.proxy()`
     */
    constructor(source, { name = "DEFAULT_RECORDING", as, maxTime = Infinity, mimeType = "video/webm", hidden = false, chunksPerSecond = 1, stream, proxy, ...options } = {}) {
      var _a, _b;
      super();
      __privateAdd(this, _Recording_instances);
      __publicField(this, "id", newID());
      __publicField(this, "name");
      __publicField(this, "as");
      __publicField(this, "source");
      __publicField(this, "element");
      __publicField(this, "mimeType");
      __publicField(this, "hidden");
      __publicField(this, "maxTime");
      __publicField(this, "creationTime", Date.now());
      __publicField(this, "completionTime", null);
      __publicField(this, "state", "starting");
      /** Resolves `{ type: 'stop', target }` once the last chunk is stored; rejects on `abort()` or a recorder error */
      __publicField(this, "done");
      __privateAdd(this, _recorder, null);
      __privateAdd(this, _store, null);
      __privateAdd(this, _storeReady);
      __privateAdd(this, _proxy, null);
      __privateAdd(this, _resolve);
      __privateAdd(this, _reject);
      __privateAdd(this, _timer, null);
      __privateAdd(this, _recorded, 0);
      __privateAdd(this, _since, null);
      __privateAdd(this, _writes, Promise.resolve());
      __privateAdd(this, _link, null);
      __privateAdd(this, _linkSize, -1);
      __privateAdd(this, _saving, Promise.resolve());
      __privateAdd(this, _count, 0);
      if (!stream && !proxy && typeof (source == null ? void 0 : source.captureStream) != "function")
        throw new TypeError(`new Recording(source) needs a <video>, <audio> or <canvas> that can be captured; not <${(_a = source == null ? void 0 : source.constructor) == null ? void 0 : _a.name}>`);
      this.name = String(name);
      this.as = String(as ?? (globalThis.ClipName ? new globalThis.ClipName() : this.name));
      this.source = source;
      this.element = (proxy == null ? void 0 : proxy.canvas) ?? source;
      this.maxTime = Number(maxTime) > 0 ? Number(maxTime) : Infinity;
      this.hidden = !!hidden;
      this.mimeType = supportedType(mimeType);
      __privateSet(this, _proxy, proxy ?? null);
      this.done = new Promise((resolve, reject) => {
        __privateSet(this, _resolve, resolve);
        __privateSet(this, _reject, reject);
      });
      this.done.catch(() => {
      });
      const own = _Recording.of(source);
      if ((_b = own.get(this.name)) == null ? void 0 : _b.active)
        own.get(this.name).stop();
      own.set(this.name, this);
      everything.add(this);
      __privateSet(this, _storeReady, __privateMethod(this, _Recording_instances, openStore_fn).call(this));
      try {
        stream ??= (proxy == null ? void 0 : proxy.stream) ?? source.captureStream();
        __privateSet(this, _recorder, new MediaRecorder(stream, { ...options, mimeType: this.mimeType }));
      } catch (error) {
        __privateMethod(this, _Recording_instances, fail_fn).call(this, error);
        return;
      }
      const recorder = __privateGet(this, _recorder);
      recorder.ondataavailable = ({ data }) => {
        if (!(data == null ? void 0 : data.size))
          return;
        ++__privateWrapper(this, _count)._;
        __privateSet(this, _writes, __privateGet(this, _writes).then(() => __privateGet(this, _storeReady)).then((store) => store.append(data)).catch((error) => console.warn("[recording]", error)));
        this.dispatchEvent(Object.assign(new Event("data"), { data }));
      };
      recorder.onerror = ({ error }) => __privateMethod(this, _Recording_instances, fail_fn).call(this, error ?? new Error("MediaRecorder error"));
      recorder.onstop = () => __privateMethod(this, _Recording_instances, finish_fn).call(this);
      const begin = /* @__PURE__ */ __name((tries = 0) => {
        if (this.state != "starting")
          return;
        const waiting = proxy ? proxy.source.readyState < 2 : !stream.getVideoTracks().length && !stream.getAudioTracks().length;
        if (waiting && tries < 100)
          return void later(100, () => begin(tries + 1));
        try {
          recorder.start(Math.min(Math.max(Math.round(1e3 / chunksPerSecond), 1), 1e3));
        } catch (error) {
          return __privateMethod(this, _Recording_instances, fail_fn).call(this, error);
        }
        this.mimeType = recorder.mimeType || this.mimeType;
        __privateMethod(this, _Recording_instances, setState_fn).call(this, "recording");
        __privateSet(this, _since, Date.now());
        this.dispatchEvent(new Event("start"));
        if (Number.isFinite(this.maxTime))
          __privateSet(this, _timer, later(this.maxTime, () => this.stop()));
      }, "begin");
      if (proxy)
        proxy.ready.then(() => begin());
      else
        begin();
    }
    /** Recording or paused (not yet stopped) */
    get active() {
      return ACTIVE.has(this.state);
    }
    /** Bytes recorded so far */
    get size() {
      var _a;
      return ((_a = __privateGet(this, _store)) == null ? void 0 : _a.size) ?? 0;
    }
    /** Number of chunks received */
    get count() {
      return __privateGet(this, _count);
    }
    /** Time recorded, in ms, not counting pauses */
    get duration() {
      return __privateGet(this, _recorded) + (__privateGet(this, _since) != null ? Date.now() - __privateGet(this, _since) : 0);
    }
    /** Average bits per second so far */
    get bitrate() {
      return this.duration > 0 ? Math.round(this.size * 8e3 / this.duration) : 0;
    }
    /** Where the chunks are kept: 'disk' or 'memory' (null until known) */
    get storage() {
      var _a;
      return ((_a = __privateGet(this, _store)) == null ? void 0 : _a.kind) ?? null;
    }
    /**
     * Pauses; resumes by itself after `resumeAfter` ms when given.
     * @param {number} [resumeAfter=Infinity]
     * @returns {Recording}
     */
    pause(resumeAfter = Infinity) {
      if (this.state == "recording") {
        __privateGet(this, _recorder).pause();
        __privateMethod(this, _Recording_instances, account_fn).call(this);
        __privateMethod(this, _Recording_instances, setState_fn).call(this, "paused");
        this.dispatchEvent(new Event("pause"));
        if (Number.isFinite(resumeAfter))
          later(resumeAfter, () => this.resume());
      }
      return this;
    }
    /** @returns {Recording} */
    resume() {
      if (this.state == "paused") {
        __privateGet(this, _recorder).resume();
        __privateSet(this, _since, Date.now());
        __privateMethod(this, _Recording_instances, setState_fn).call(this, "recording");
        this.dispatchEvent(new Event("resume"));
      }
      return this;
    }
    /**
     * Stops recording. Chainable (`recording.stop().save()`); `await recording.done` (or `save()`) waits for the last
     * chunk.
     * @returns {Recording}
     */
    stop() {
      if (this.state == "starting") {
        this.state = "stopping";
        __privateMethod(this, _Recording_instances, finish_fn).call(this);
      } else if (this.state == "recording" || this.state == "paused") {
        __privateMethod(this, _Recording_instances, account_fn).call(this);
        this.state = "stopping";
        try {
          __privateGet(this, _recorder).stop();
        } catch (error) {
          __privateMethod(this, _Recording_instances, finish_fn).call(this);
        }
      }
      return this;
    }
    /**
     * Stops and rejects `done` with `reason`. The data is kept (salvageable with `save()`) until `discard()`.
     * @param {*} [reason]
     * @returns {Recording}
     */
    abort(reason = "Recording has been canceled") {
      __privateMethod(this, _Recording_instances, fail_fn).call(this, reason);
      return this;
    }
    /**
     * Everything recorded so far, as one Blob. While recording, asks the recorder for its latest chunk first.
     * @returns {Promise<Blob>}
     */
    async blob() {
      if (this.state == "stopping")
        await this.done.catch(() => {
        });
      if (this.state == "recording" || this.state == "paused") {
        await new Promise((resolve) => {
          __privateGet(this, _recorder).addEventListener("dataavailable", resolve, { once: true });
          __privateGet(this, _recorder).requestData();
          later(1e3, resolve);
        });
      }
      await __privateGet(this, _writes);
      return (await __privateGet(this, _storeReady)).blob(this.mimeType.split(";")[0]);
    }
    /**
     * Downloads what was recorded (stop first for the whole clip; while recording it saves what's there so far).
     * Saving again without new data returns the same link.
     * @param {string} [as] - File name, without extension
     * @returns {Promise<HTMLAnchorElement>}
     */
    save(as = null) {
      return __privateSet(this, _saving, __privateGet(this, _saving).catch(() => {
      }).then(async () => {
        var _a;
        const blob = await this.blob();
        if (!blob.size)
          throw `Unable to save clip. No recording data available.`;
        as = String(as ?? this.as);
        if (__privateGet(this, _link) && __privateGet(this, _linkSize) == blob.size && __privateGet(this, _link).dataset.saveName == as)
          return __privateGet(this, _link);
        const link = await download(blob, as);
        __privateSet(this, _link, link);
        __privateSet(this, _linkSize, blob.size);
        (_a = __privateGet(this, _store)) == null ? void 0 : _a.describe(__privateMethod(this, _Recording_instances, meta_fn).call(this, { saved: true }));
        return link;
      }));
    }
    /**
     * Stops (if needed), deletes the data, and forgets the recording. A saved recording's files stay until the next
     * page load, so a download in progress can finish.
     */
    async discard() {
      var _a;
      if (this.active)
        this.abort("Recording discarded");
      everything.delete(this);
      const own = _Recording.of(this.source);
      if (own.get(this.name) === this)
        own.delete(this.name);
      updateStatus();
      if (!__privateGet(this, _link))
        await ((_a = await __privateGet(this, _storeReady)) == null ? void 0 : _a.discard());
    }
    /**
     * Records from another element from now on, in the same file (proxied recordings only).
     * @param {HTMLVideoElement} source
     * @returns {Recording}
     */
    retarget(source) {
      if (!__privateGet(this, _proxy))
        throw new TypeError("Only a proxied recording (Recording.proxy) can change its source");
      __privateGet(this, _proxy).retarget(source);
      return this;
    }
    /**
     * The recordings filed under an element (by name).
     * @param {Element} element
     * @returns {Map<string, Recording>}
     */
    static of(element) {
      let own = registry.get(element);
      if (!own)
        registry.set(element, own = /* @__PURE__ */ new Map());
      return own;
    }
    /**
     * Every recording not yet discarded, oldest first.
     * @param {Object} [filter]
     * @param {boolean} [filter.active] - Only running (or only finished) ones
     * @returns {Recording[]}
     */
    static list({ active } = {}) {
      return [...everything].filter((recording) => active === void 0 || recording.active === active);
    }
    /**
     * Finds a recording by name, or the first running one (`Recording.ANY`).
     * @param {string|symbol} name
     * @param {Element} [element] - Only look under this element
     * @returns {Recording|undefined}
     */
    static find(name, element = null) {
      const pool = element ? [..._Recording.of(element).values()] : _Recording.list();
      if (name === _Recording.ANY)
        return pool.find((recording) => recording.active);
      return [...pool].reverse().find((recording) => recording.name == name);
    }
    /**
     * Records a copy of a video drawn onto a canvas (see the file header).
     * @param {HTMLVideoElement} from
     * @param {Object} [options] - As for `new Recording`, plus `fps` (30)
     * @returns {Recording}
     */
    static proxy(from, { fps = 30, canvas, ...options } = {}) {
      var _a;
      if (typeof (from == null ? void 0 : from.captureStream) != "function")
        throw new TypeError(`Recording.proxy(from) needs a <video> that can be captured; not <${(_a = from == null ? void 0 : from.constructor) == null ? void 0 : _a.name}>`);
      return new _Recording(from, { ...options, proxy: new FrameProxy(from, { fps, canvas }) });
    }
    /**
     * Recordings left on disk by a closed or crashed tab (not held by any open tab).
     * @returns {Promise<Array<{ id: string, name: string, as: string, mimeType: string, creationTime: number, saved: boolean, size: number, blob: function(): Promise<Blob>, save: function(string=): Promise<HTMLAnchorElement>, discard: function(): Promise<void> }>>}
     */
    static async leftovers() {
      var _a, _b, _c;
      if (!((_b = (_a = globalThis.navigator) == null ? void 0 : _a.storage) == null ? void 0 : _b.getDirectory))
        return [];
      const root = await (await navigator.storage.getDirectory()).getDirectoryHandle(DIRECTORY, { create: true });
      const found = [];
      for await (const [id, dir] of root.entries()) {
        if (dir.kind != "directory" || [...everything].some((recording) => recording.id == id))
          continue;
        if ((_c = globalThis.navigator) == null ? void 0 : _c.locks) {
          const held = await navigator.locks.request(`${DIRECTORY}:${id}`, { ifAvailable: true }, (lock) => !lock);
          if (held)
            continue;
        }
        let meta = {};
        try {
          meta = JSON.parse(await (await (await dir.getFileHandle("meta.json")).getFile()).text());
        } catch (error) {
        }
        const files = await segments(dir);
        const type = String(meta.mimeType ?? "video/webm").split(";")[0];
        const blob = /* @__PURE__ */ __name(() => new Blob(files, { type }), "blob");
        found.push({
          id,
          saved: false,
          ...meta,
          size: files.reduce((total, file) => total + file.size, 0),
          blob: /* @__PURE__ */ __name(async () => blob(), "blob"),
          async save(as = meta.as ?? id) {
            const link = await download(blob(), as);
            await write(dir, "meta.json", JSON.stringify({ ...meta, saved: true })).catch(() => {
            });
            return link;
          },
          discard: /* @__PURE__ */ __name(() => root.removeEntry(id, { recursive: true }).catch(() => {
          }), "discard")
        });
      }
      return found;
    }
    /**
     * Deletes leftovers that were already saved, and empty ones.
     * @returns {Promise<number>} How many were deleted
     */
    static async cleanup() {
      let count = 0;
      for (const leftover of await _Recording.leftovers().catch(() => []))
        if (leftover.saved || !leftover.size)
          await leftover.discard(), ++count;
      return count;
    }
    /**
     * The file extension for a recording, from its declared type or its first bytes.
     * @param {Blob} blob
     * @returns {Promise<string>}
     */
    static async guessMIMEType(blob) {
      const find = /* @__PURE__ */ __name((type2) => {
        var _a, _b;
        return ((_b = (_a = globalThis.MIME_Types) == null ? void 0 : _a.find) == null ? void 0 : _b.call(_a, type2)) ?? { "video/webm": "webm", "video/x-matroska": "mkv", "video/mp4": "mp4", "video/quicktime": "mov", "video/ogg": "ogv", "audio/wav": "wav", "video/x-msvideo": "avi" }[type2] ?? "bin";
      }, "find");
      const declared = String((blob == null ? void 0 : blob.type) ?? "").toLowerCase().split(";")[0];
      if (declared)
        return find(declared);
      const bytes = new Uint8Array(await blob.slice(0, 64).arrayBuffer());
      const ascii = /* @__PURE__ */ __name((from, to) => String.fromCharCode(...bytes.slice(from, to)), "ascii");
      let type = "application/octet-stream";
      if (bytes[0] == 26 && bytes[1] == 69 && bytes[2] == 223 && bytes[3] == 163)
        type = ascii(0, 64).includes("webm") ? "video/webm" : "video/x-matroska";
      else if (ascii(4, 8) == "ftyp")
        type = ascii(8, 10) == "qt" ? "video/quicktime" : "video/mp4";
      else if (ascii(0, 4) == "OggS")
        type = "video/ogg";
      else if (ascii(0, 4) == "RIFF")
        type = { "WAVE": "audio/wav", "AVI ": "video/x-msvideo" }[ascii(8, 12)] ?? type;
      return find(type);
    }
  };
  _recorder = new WeakMap();
  _store = new WeakMap();
  _storeReady = new WeakMap();
  _proxy = new WeakMap();
  _resolve = new WeakMap();
  _reject = new WeakMap();
  _timer = new WeakMap();
  _recorded = new WeakMap();
  _since = new WeakMap();
  _writes = new WeakMap();
  _link = new WeakMap();
  _linkSize = new WeakMap();
  _saving = new WeakMap();
  _count = new WeakMap();
  _Recording_instances = new WeakSet();
  openStore_fn = /* @__PURE__ */ __name(async function() {
    var _a, _b, _c;
    try {
      if (_Recording.storage)
        return __privateSet(this, _store, await _Recording.storage(this.id));
      if ((_b = (_a = globalThis.navigator) == null ? void 0 : _a.storage) == null ? void 0 : _b.getDirectory) {
        await __privateMethod(_c = _Recording, _Recording_static, lock_fn).call(_c, this.id, this.done);
        const store = await DiskStore.open(this.id);
        await store.describe(__privateMethod(this, _Recording_instances, meta_fn).call(this));
        return __privateSet(this, _store, store);
      }
    } catch (error) {
      console.warn("[recording] No disk storage; recording to memory", error);
    }
    return __privateSet(this, _store, new MemoryStore());
  }, "#openStore");
  _Recording_static = new WeakSet();
  lock_fn = /* @__PURE__ */ __name(async function(id, until) {
    var _a;
    if (!((_a = globalThis.navigator) == null ? void 0 : _a.locks))
      return;
    await new Promise(
      (acquired) => navigator.locks.request(`${DIRECTORY}:${id}`, () => {
        acquired();
        return until.catch(() => {
        });
      })
    );
  }, "#lock");
  meta_fn = /* @__PURE__ */ __name(function(extra = {}) {
    return { id: this.id, name: this.name, as: this.as, mimeType: this.mimeType, creationTime: this.creationTime, completionTime: this.completionTime, saved: false, ...extra };
  }, "#meta");
  setState_fn = /* @__PURE__ */ __name(function(state) {
    this.state = state;
    updateStatus();
  }, "#setState");
  finish_fn = /* @__PURE__ */ __name(async function() {
    var _a;
    if (!ACTIVE.has(this.state) && this.state != "stopping")
      return;
    clearTimeout(__privateGet(this, _timer));
    __privateMethod(this, _Recording_instances, account_fn).call(this);
    (_a = __privateGet(this, _proxy)) == null ? void 0 : _a.stop();
    this.completionTime ??= Date.now();
    try {
      await __privateGet(this, _writes);
      const store = await __privateGet(this, _storeReady);
      await store.flush();
      await store.describe(__privateMethod(this, _Recording_instances, meta_fn).call(this));
    } catch (error) {
    }
    __privateMethod(this, _Recording_instances, setState_fn).call(this, "stopped");
    const event = new Event("stop");
    this.dispatchEvent(event);
    __privateGet(this, _resolve).call(this, { type: "stop", target: this });
  }, "#finish");
  fail_fn = /* @__PURE__ */ __name(function(error, state = "aborted") {
    var _a, _b, _c;
    if (!ACTIVE.has(this.state) && this.state != "stopping")
      return;
    clearTimeout(__privateGet(this, _timer));
    __privateMethod(this, _Recording_instances, account_fn).call(this);
    (_a = __privateGet(this, _proxy)) == null ? void 0 : _a.stop();
    this.completionTime ??= Date.now();
    try {
      if (((_b = __privateGet(this, _recorder)) == null ? void 0 : _b.state) != "inactive")
        (_c = __privateGet(this, _recorder)) == null ? void 0 : _c.stop();
    } catch (error2) {
    }
    __privateMethod(this, _Recording_instances, setState_fn).call(this, state);
    this.dispatchEvent(Object.assign(new Event("error"), { error }));
    __privateGet(this, _reject).call(this, error);
  }, "#fail");
  account_fn = /* @__PURE__ */ __name(function() {
    if (__privateGet(this, _since) != null)
      __privateSet(this, _recorded, __privateGet(this, _recorded) + (Date.now() - __privateGet(this, _since)));
    __privateSet(this, _since, null);
  }, "#account");
  __privateAdd(_Recording, _Recording_static);
  __name(_Recording, "Recording");
  __publicField(_Recording, "ANY", /* @__PURE__ */ Symbol("Any"));
  __publicField(_Recording, "ALL", /* @__PURE__ */ Symbol("All"));
  /** Used by tests to replace the storage (`(id) => store`); defaults to disk, else memory */
  __publicField(_Recording, "storage", null);
  var Recording2 = _Recording;
  function installVideoMethods(Video = globalThis.HTMLVideoElement) {
    if (!Video)
      return;
    const pick = /* @__PURE__ */ __name((element, key) => key === Recording2.ALL ? [...Recording2.of(element).values()].filter((recording) => recording.active) : [Recording2.find(key, element)].filter(Boolean), "pick");
    Object.assign(Video.prototype, {
      startRecording(options = {}) {
        return new Recording2(this, options);
      },
      getRecording(key = "DEFAULT_RECORDING") {
        return key === Recording2.ALL ? Recording2.of(this) : Recording2.find(key, this);
      },
      // Running (or paused) only, as before: a stopped recording no longer counts
      hasRecording(key = "DEFAULT_RECORDING") {
        var _a;
        return !!((_a = Recording2.find(key, this)) == null ? void 0 : _a.active);
      },
      removeRecording(key = "DEFAULT_RECORDING") {
        for (const recording of key === Recording2.ALL ? [...Recording2.of(this).values()] : pick(this, key))
          recording.discard();
        return this;
      },
      pauseRecording(key = "DEFAULT_RECORDING") {
        pick(this, key).forEach((recording) => recording.pause());
        return this;
      },
      resumeRecording(key = "DEFAULT_RECORDING") {
        pick(this, key).forEach((recording) => recording.resume());
        return this;
      },
      cancelRecording(key = "DEFAULT_RECORDING", reason = "Recording has been canceled") {
        pick(this, key).forEach((recording) => recording.abort(reason));
        return this;
      },
      stopRecording(key = "DEFAULT_RECORDING") {
        pick(this, key).forEach((recording) => recording.stop());
        return this;
      },
      saveRecording(key = "DEFAULT_RECORDING", name = null) {
        var _a;
        if (key === Recording2.ALL)
          return [...Recording2.of(this).values()].map((recording, index) => recording.save(index && name ? `${name} (${index + 1})` : name));
        return (_a = Recording2.find(key, this)) == null ? void 0 : _a.save(name);
      }
    });
  }
  __name(installVideoMethods, "installVideoMethods");

  // src/plugins/player/auto-accept-mature.js
  plugin({
    id: "player.auto_accept_mature",
    job: "auto_accept_mature",
    timer: -1e3,
    /**
     * Runs every tick: Automatically clicks confirmation buttons for mature content overlays or similar dismissible notices.
     */
    handler: /* @__PURE__ */ __name(() => {
      $.all(':is([data-a-target*="overlay"i], [data-a-target*="watchparty"i]) button, .home [data-a-target^="home"i], [data-test-selector*="mute"i][data-test-selector*="dismiss"i]').map((button) => button.click());
    }, "handler")
  });

  // src/plugins/player/recover-video.js
  var RECOVERING_VIDEO;
  plugin({
    id: "player.recover_video",
    job: "recover_video",
    timer: 5e3,
    /**
     * Initializes the video recovery state.
     */
    init() {
      RECOVERING_VIDEO = false;
    },
    /**
     * Runs every tick: Detects player errors and recovers by moving to the next streamer for restricted content or clicking the error button.
     * @param {Object} context - Contains the StopWatch utility
     */
    handler: /* @__PURE__ */ __name(async ({ StopWatch }) => {
      var _a, _b;
      new StopWatch("recover_video");
      const errorMessage = $('[data-a-target*="player"i]:is([data-a-target*="content"i], [data-a-target*="gate"i]) [data-a-target*="text"i]');
      if (nullish(errorMessage))
        return StopWatch.stop("recover_video");
      if (RECOVERING_VIDEO)
        return StopWatch.stop("recover_video");
      RECOVERING_VIDEO = true;
      $error("The stream ran into an error:", errorMessage.textContent, /* @__PURE__ */ new Date());
      if (/\b(subscribe|mature)\b/i.test(errorMessage.textContent)) {
        const next = await ((_a = window.GetNextStreamer) == null ? void 0 : _a.call(window));
        if (defined(next))
          goto(parseURL(next.href).addSearch({ tool: "video-recovery--non-subscriber" }).href);
      } else {
        (_b = $("button", errorMessage) ?? errorMessage.closest("button")) == null ? void 0 : _b.click();
        addToSearch({ "tt-err-vid": "video-recovery--player-error" });
        RECOVERING_VIDEO = false;
      }
      StopWatch.stop("recover_video");
    }, "handler")
  });

  // src/plugins/player/hide-blank-ads.js
  var BLANK_AD_PRESENCE;
  plugin({
    id: "player.hide_blank_ads",
    job: "hide_blank_ads",
    timer: 500,
    /**
     * Initializes the blank ad detection state.
     */
    init() {
      BLANK_AD_PRESENCE = false;
    },
    /**
     * Runs every tick: Detects blank advertisements by comparing the current video frame against a known blank-ad banner.
     */
    handler: /* @__PURE__ */ __name(() => {
      if ($.defined('[data-a-target*="ad-countdown"i]'))
        return window.postMessage({ action: "report-blank-ad", from: "player.js", purple: true }, "*");
      const video = $("video");
      if (nullish(video))
        return;
      const capture = video.captureFrame(), banner = Runtime.getURL("twitch-banner.png");
      resemble(capture).compareTo(banner).ignoreColors().scaleToSameSize().onComplete(async (data) => {
        let { analysisTime, misMatchPercentage } = data;
        analysisTime = parseInt(analysisTime);
        misMatchPercentage = parseFloat(misMatchPercentage);
        const matchPercentage = 100 - misMatchPercentage, isBlankAd = matchPercentage > 80;
        if (BLANK_AD_PRESENCE == isBlankAd)
          return;
        BLANK_AD_PRESENCE = isBlankAd;
        window.postMessage({ action: "report-blank-ad", from: "player.js", purple: isBlankAd }, "*");
      });
    }, "handler")
  });

  // src/plugins/player/auto-dvr.js
  plugin({
    id: "player.auto_dvr",
    job: "auto_dvr",
    timer: 500,
    /**
     * Runs every tick: Automatically records a live stream if requested via URL and downloads the recording once the stream ends.
     */
    handler: /* @__PURE__ */ __name(() => {
      const { action = "", channel, autosave, controls, filetype, quality, slug, volume } = parseURL(window.location).searchParameters;
      if (action.unlike("dvr"))
        return;
      const video = $("video");
      const live = $.nullish('[class*="channel-status"i][class*="offline"i]');
      const recording = Recording.find("PLAYER_DVR");
      if (nullish(video) || !live)
        return void (parseBool(autosave) && (recording == null ? void 0 : recording.stop()));
      if (recording == null ? void 0 : recording.active)
        return;
      Recording.proxy(video, { name: "PLAYER_DVR", as: slug, mimeType: `video/${filetype}` }).done.then(({ target }) => target.save(slug)).catch($warn).finally(() => window.postMessage({ action: "report-offline-dvr", from: "player.js", slug }, "*"));
    }, "handler"),
    /**
     * Determines if the auto-DVR feature should be enabled based on settings.
     * @returns {boolean} Whether the feature is enabled
     */
    enabled() {
      return true;
    }
  });

  // src/plugins/player/miscellaneous.js
  plugin({
    id: "player.miscellaneous",
    /**
     * Sets up miscellaneous player enhancements, including automatic unmuting for embeds and adding navigation links for private viewing.
     */
    async install() {
      var _a;
      Miscellaneous: {
        __UnmuteEmbed__: {
          let { channel, controls, muted, parent, quality } = parseURL(window.location).searchParameters;
          controls = parseBool(controls);
          muted = parseBool(muted);
          if (!controls && !muted)
            (_a = $('figure[tt-svg-label~="unmute"i]')) == null ? void 0 : _a.click();
          if (muted) {
            let viewerTouched = false;
            const silence = /* @__PURE__ */ __name((video) => {
              video.muted = true;
              video.addEventListener("volumechange", () => viewerTouched || (video.muted = true));
            }, "silence");
            $.on("pointerdown", ({ isTrusted }) => viewerTouched ||= isTrusted);
            $.on("keydown", ({ isTrusted }) => viewerTouched ||= isTrusted);
            when.defined(() => $("video")).then(silence);
          }
        }
        __PopinButton__: {
          let { channel, controls, muted, parent, quality, private: isPrivate = false } = parseURL(window.location).searchParameters;
          controls = parseBool(controls);
          muted = parseBool(muted);
          isPrivate = parseBool(isPrivate);
          if (isPrivate) {
            $('[data-test-selector*="video-player"i][data-test-selector*="container"]').append(
              furnish("a#player-to-top", {
                href: `//www.twitch.tv/${channel}`,
                target: "_top",
                style: `z-index:9;position:absolute;bottom:-100%;left:50%;transform:translate(-50%);text-shadow:0 0 4px #8888;transition:all 0.5s;background-color:var(--color-background-button-primary-default);padding:.25rem .5rem;border-radius:3px;color:white;text-decoration:none;`,
                innerHTML: `&swarr; Go to ${channel}`
              })
            );
            AddCustomCSSBlock("player-to-top", `[data-test-selector*="video-player"i][data-test-selector*="container"]:hover #player-to-top{bottom:0!important} #player-to-top:hover{background-color:var(--color-background-button-primary-hover)!important}`);
          }
        }
      }
    }
  });

  // src/plugins/player/index.js
  globalThis.TTV ??= { plugin, plugins: PLUGINS, run, start };
  globalThis.Recording = Recording2;
  installVideoMethods();
})();
