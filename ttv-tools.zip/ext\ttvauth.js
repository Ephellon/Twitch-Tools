/*** TTV Auth
 *      _______ _________      __                _   _
 *     |__   __|__   __\ \    / /     /\        | | | |
 *        | |     | |   \ \  / /     /  \  _   _| |_| |__
 *        | |     | |    \ \/ /     / /\ \| | | | __| '_ \
 *        | |     | |     \  /     / ____ \ |_| | |_| | | |
 *        |_|     |_|      \/     /_/    \_\__,_|\__|_| |_|
 *
 *
 */

if(location.search?.length) {
    let { code = null, scope = "", error = "", error_description = "" } = parseURL(location.href).searchParameters;

    if(!parseBool(error))
        Settings.set({ oauthToken: code });
}
